#!/bin/bash
# PRIMA — kemas paket Linux x64 (jalankan di komputer Linux, satu perintah).
# Hasil: PRIMA-linux-x64.zip di folder yang sama.
set -e
cd "$(dirname "$0")"
V=31.7.7
rm -rf dist/PRIMA-linux-x64 PRIMA-linux-x64.zip
mkdir -p dist/PRIMA-linux-x64/resources/app/data
echo "Mengunduh Electron Linux…"
curl -sL -o /tmp/electron-linux.zip "https://github.com/electron/electron/releases/download/v$V/electron-v$V-linux-x64.zip"
unzip -qo /tmp/electron-linux.zip -d dist/PRIMA-linux-x64
mv dist/PRIMA-linux-x64/electron dist/PRIMA-linux-x64/PRIMA
chmod +x dist/PRIMA-linux-x64/PRIMA
cp index.html ppdb.html style.css app.js main.js preload.js server.js cryptolib.js google-apps-script.js package.json README.md icon.ico dist/PRIMA-linux-x64/resources/app/
cp data/klasifikasi.js data/sekolah.js dist/PRIMA-linux-x64/resources/app/data/
cd dist && zip -qr9 ../PRIMA-linux-x64.zip PRIMA-linux-x64
echo "SELESAI: PRIMA-linux-x64.zip — ekstrak lalu jalankan ./PRIMA --no-sandbox"
