/* PRIMA — server statis + penerima pendaftaran PPDB jaringan lokal.
   Jalankan: npm start  →  buka http://localhost:8080

   MODE JARINGAN PPDB:
   - Pendaftar (orang tua) membuka http://ALAMAT-IP-KOMPUTER-INI:8080/ppdb.html
     dari HP/laptop mana pun yang satu jaringan (Wi-Fi sekolah).
   - Kiriman formulir masuk ke server ini (file ppdb-store.json di sebelah
     server.js), lalu ditarik oleh aplikasi PRIMA lewat tombol
     "Tarik dari Server" di menu PPDB (atau otomatis saat halaman dibuka). */
const http=require('http'),fs=require('fs'),path=require('path'),os=require('os');
const port=process.env.PORT||8080;
const STORE=path.join(__dirname,'ppdb-store.json');
const MAX_BODY=12*1024*1024; /* 12 MB — cukup untuk 2 berkas scan */
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.zip':'application/zip','.prima':'application/octet-stream'};

/* ---- penyimpanan antrean PPDB ---- */
function bacaStore(){
 try{const s=JSON.parse(fs.readFileSync(STORE,'utf8'));
  return {inbox:Array.isArray(s.inbox)?s.inbox:[],status:(s.status&&typeof s.status==='object')?s.status:{}};
 }catch(e){return {inbox:[],status:{}};}
}
function tulisStore(s){try{fs.writeFileSync(STORE,JSON.stringify(s));}catch(e){console.error('Gagal menyimpan ppdb-store:',e.message);}}

function kirimJSON(res,kode,obj){
 const b=JSON.stringify(obj);
 res.writeHead(kode,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'});
 res.end(b);
}
function bacaBody(req,cb){
 let n=0;const chunk=[];let mati=false;
 req.on('data',c=>{n+=c.length;if(n>MAX_BODY){mati=true;req.destroy();return;}chunk.push(c);});
 req.on('end',()=>{if(mati)return;try{cb(JSON.parse(Buffer.concat(chunk).toString('utf8')||'{}'));}catch(e){cb(null);}});
 req.on('error',()=>{});
}

const server=http.createServer((req,res)=>{
 const u=(req.url||'/').split('?')[0];
 res.setHeader('Access-Control-Allow-Origin','*');
 if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}

 /* --- API PPDB --- */
 if(req.method==='POST'&&u==='/ppdb'){
  bacaBody(req,e=>{
   if(!e||!e.reg)return kirimJSON(res,400,{ok:false,why:'data tidak sah'});
   const s=bacaStore();
   if(!s.inbox.some(x=>x.reg===e.reg)){e.tsKirim=Date.now();s.inbox.push(e);tulisStore(s);}
   kirimJSON(res,200,{ok:true,reg:e.reg});
  });return;
 }
 if(req.method==='GET'&&u==='/ppdb-queue'){return kirimJSON(res,200,bacaStore().inbox);}
 if(req.method==='POST'&&u==='/ppdb-ack'){
  bacaBody(req,b=>{
   const regs=(b&&Array.isArray(b.regs))?b.regs:[];
   const s=bacaStore();s.inbox=s.inbox.filter(x=>!regs.includes(x.reg));tulisStore(s);
   kirimJSON(res,200,{ok:true});
  });return;
 }
 if(req.method==='GET'&&u==='/ppdb-status'){return kirimJSON(res,200,bacaStore().status);}
 if(req.method==='POST'&&u==='/ppdb-status'){
  bacaBody(req,b=>{
   if(b&&b.reg){const s=bacaStore();
    s.status[b.reg]={s:b.s||'',ket:'diperbarui '+new Date().toLocaleDateString('id-ID',{day:'2-digit',month:'short',year:'numeric'})};
    tulisStore(s);}
   kirimJSON(res,200,{ok:true});
  });return;
 }

 /* --- berkas statis --- */
 let p=decodeURIComponent(u);
 if(p==='/'||p==='')p='/index.html';
 if(!p.startsWith('/')||p.includes('..')){res.writeHead(400);res.end();return;}
 const f=path.join(__dirname,p);
 fs.readFile(f,(e,d)=>{
  if(e){res.writeHead(404,{'Content-Type':'text/plain'});res.end('404');return;}
  res.writeHead(200,{'Content-Type':mime[path.extname(f).toLowerCase()]||'application/octet-stream'});
  res.end(d);
 });
});
server.listen(port,'0.0.0.0',()=>{
 console.log('PRIMA berjalan di http://localhost:'+port);
 try{
  const nets=os.networkInterfaces();
  for(const nm of Object.values(nets)){
   for(const ni of nm||[]){
    if(ni.family==='IPv4'&&!ni.internal){
     console.log('Formulir PPDB untuk pendaftar: http://'+ni.address+':'+port+'/ppdb.html');
    }
   }
  }
 }catch(e){}
});
