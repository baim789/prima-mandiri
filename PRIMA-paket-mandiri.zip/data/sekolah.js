/* ============================================================
   PRIMA v2 — Data pendukung
   v2: SEMUA data contoh dikosongkan — sekolah mengisi datanya
   sendiri (lewat formulir atau impor Excel). Template surat,
   SK, dan kode klasifikasi Perbup tetap tersedia.
   ============================================================ */
const C={amber:'#F5B841',coral:'#F08A5D',rose:'#F2708A',pink:'#E58BC4',lilac:'#C79BF2',peri:'#8AA6F2',sky:'#59B7E8',cyan:'#45C4E0',teal:'#45D0B8',green:'#5BD98A',lime:'#A8D957',gold:'#D9C05B',grey:'#8B93A7'};
const AVA=[C.amber,C.coral,C.rose,C.pink,C.lilac,C.peri,C.sky,C.cyan,C.teal,C.green,C.lime,C.gold];

const NAV=[
 {id:'beranda',label:'Beranda',icon:'layout-dashboard',c:C.teal},
 {id:'umum',label:'Administrasi Umum',icon:'building-2',c:C.amber,children:[
  {id:'profil',label:'Profil Sekolah',icon:'school',c:C.amber},
  {id:'pegawai',label:'Pegawai & Tata Usaha',icon:'contact',c:C.peri},
  {id:'persuratan',label:'Persuratan',icon:'mail-plus',c:C.coral},
  {id:'penomoran',label:'Penomoran Naskah Dinas',icon:'hash',c:C.gold},
  {id:'klasifikasi',label:'Kode Klasifikasi Arsip',icon:'folder-tree',c:C.lilac},
  {id:'sk',label:'SK & Keputusan',icon:'scroll-text',c:C.gold},
  {id:'mou',label:'MOU & Kerja Sama',icon:'handshake',c:C.teal},
  {id:'arsip',label:'Surat & Arsip',icon:'archive',c:C.pink},
  {id:'backup',label:'Backup & Pulihkan',icon:'save',c:C.green},
 ]},
 {id:'guru',label:'Administrasi Guru',icon:'users-round',c:C.sky,children:[
  {id:'dguru',label:'Data Guru',icon:'users',c:C.sky},
  {id:'dgurudok',label:'Dokumen Guru',icon:'folder-open',c:C.gold},
  {id:'aguru',label:'Absensi Guru',icon:'user-check',c:C.coral},
  {id:'jadwal',label:'Jadwal Mengajar',icon:'calendar-days',c:C.lilac},
 ]},
 {id:'siswa',label:'Administrasi Siswa',icon:'graduation-cap',c:C.rose,children:[
  {id:'dsiswa',label:'Data Siswa',icon:'users',c:C.rose},
  {id:'induk',label:'Buku Induk Siswa',icon:'book-marked',c:C.lime},
  {id:'naik',label:'Kenaikan Kelas',icon:'arrow-up-circle',c:C.cyan},
  {id:'ppdb',label:'PPDB',icon:'clipboard-list',c:C.teal},
  {id:'asiswa',label:'Absensi Siswa',icon:'calendar-check',c:C.amber},
  {id:'nilai',label:'Nilai & Rapor',icon:'book-open',c:C.sky},
  {id:'spp',label:'Pembayaran SPP',icon:'receipt',c:C.green},
  {id:'perpus',label:'Perpustakaan',icon:'library',c:C.pink},
 ]},
 {id:'tahun',label:'Dokumen per Tahun',icon:'archive',c:C.peri,children:(()=>{
  const a=[];for(let y=2045;y>=2010;y--){const t=y+'/'+(y+1);a.push({id:'ta-'+t,label:t,icon:'calendar-days',c:C.sky});}
  return a;
 })()},
 {id:'arsipd',label:'Arsip Digital',icon:'folder-archive',c:C.lilac,children:(()=>{
  const a=[];for(let y=2045;y>=2010;y--){a.push({id:'ad-'+y,label:'Tahun '+y,icon:'folder',c:C.lilac});}
  return a;
 })()},
 {id:'roadmap',label:'Peta Jalan',icon:'map',push:true,c:C.gold},
];

const NAVMAP={},LEAF={};
NAV.forEach(n=>{
 NAVMAP[n.id]={label:n.label,icon:n.icon};
 if(n.children) n.children.forEach(c=>LEAF[c.id]={id:c.id,label:c.label,icon:c.icon,c:c.c,parent:n.id});
 else LEAF[n.id]={id:n.id,label:n.label,icon:n.icon,c:n.id==='roadmap'?C.amber:C.teal,parent:null};
});

/* ---- Data induk: KOSONG — diisi sekolah ---- */
const GURU=[];      /* {n,nip,m,s,skp} — via formulir / impor Excel */
const SISWA=[];     /* {n,nis,nisn,k,jk,sp,ttl,ag,ak,ib,im,kr,al,tl,asal} — via formulir / impor Excel */
const PEGAWAI=[];   /* {n,j,u,s,mk} */
const PANGKAT=[];   /* {n,g,t,y,s} */
const MOUD=[];      /* MOU — diisi lewat formulir MOU Baru */
const JADWAL=[];    /* {h,j,k,m,g} */
const PPDB=[];      /* {no,n,a,v,s} */
const PERPUS=[];    /* {b,p,pin,tmp,s} */
const ABKEL=[];     /* rekap absensi per kelas */
const NILAI=[];     /* rata-rata per mapel */
const TOP=[];       /* peringkat */

/* ---- Jenis surat ---- */
const SURAT_JENIS=[
 {id:'aktif-s',t:'Surat Keterangan Aktif Siswa',icon:'user-check',c:C.green,d:'Status peserta didik aktif — keperluan bebas: bank, lomba, beasiswa, dll.',no:'421.2'},
 {id:'aktif-g',t:'Surat Keterangan Aktif Guru',icon:'badge-check',c:C.sky,d:'Status mengajar aktif tenaga pendidik untuk keperluan administrasi.',no:'800'},
 {id:'pernah',t:'Keterangan Pernah Sekolah',icon:'history',c:C.amber,d:'Keterangan alumni — pernah menempuh pendidikan dan dinyatakan lulus.',no:'421.2'},
 {id:'mutasi',t:'Surat Mutasi Siswa',icon:'move-right',c:C.coral,d:'Pemberitahuan perpindahan siswa kepada sekolah tujuan.',no:'421.2'},
 {id:'m8535',t:'Surat Keterangan Model 8535',icon:'file-diff',c:C.lilac,d:'Koreksi data peserta didik pada Dapodik sesuai format dinas.',no:'421.2'},
 {id:'ubah',t:'Keterangan Perubahan Identitas',icon:'id-card',c:C.pink,d:'Identitas lama–baru atas perubahan dokumen resmi (KK baru, adopsi).',no:'421.2'},
 {id:'rapor',t:'Undangan Pengambilan Rapor',icon:'mail-open',c:C.teal,d:'Undangan wali murid menghadiri pembagian rapor per kelas.',no:'005'},
];
/* ---- 13 template SK ---- */
const SKD=[
 {id:'keagamaan',t:'SK Kegiatan Keagamaan',icon:'moon',c:C.lilac,kode:'800.2',tujuan:'meningkatkan pembinaan keagamaan peserta didik',tentang:'Tim Pembina Kegiatan Keagamaan',
  dasar:['Undang-Undang Nomor 20 Tahun 2003 tentang Sistem Pendidikan Nasional','Permendikbud tentang Pembinaan Kegiatan Keagamaan di Satuan Pendidikan'],
  menetapkan:'menetapkan Tim Pembina Kegiatan Keagamaan yang bertugas merencanakan, melaksanakan, dan mengevaluasi seluruh kegiatan keagamaan sekolah.',
  tim:[['Pembina','(Kepala Sekolah)'],['Ketua','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Anggota','(diisi panitia)']]},
 {id:'literasi',t:'SK Literasi Sekolah',icon:'book-open',c:C.sky,kode:'800.2',tujuan:'mewujudkan Gerakan Literasi Sekolah yang berkelanjutan',tentang:'Tim Gerakan Literasi Sekolah (GLS)',
  dasar:['Permendikbud Nomor 23 Tahun 2015 tentang Penumbuhan Budi Pekerti','Program Gerakan Literasi Sekolah Kementerian Pendidikan'],
  menetapkan:'menetapkan Tim Gerakan Literasi Sekolah yang mengelola pojok baca, pembiasaan membaca 15 menit, dan festival literasi tahunan.',
  tim:[['Ketua','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Anggota','(diisi panitia)']]},
 {id:'ppdb',t:'SK Penerimaan Peserta Didik Baru',icon:'user-plus',c:C.teal,kode:'421.2',tujuan:'melaksanakan penerimaan peserta didik baru secara objektif dan akuntabel',tentang:'Panitia Penerimaan Peserta Didik Baru (PPDB)',
  dasar:['Permendikbudristek tentang Penerimaan Peserta Didik Baru','Keputusan Dinas Pendidikan tentang Jalur PPDB'],
  menetapkan:'menetapkan Panitia PPDB yang bertugas menyelenggarakan pendaftaran, seleksi, pengumuman, dan registrasi ulang peserta didik baru.',
  tim:[['Penanggung Jawab','(Kepala Sekolah)'],['Ketua Panitia','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Anggota','(diisi panitia)']]},
 {id:'mpls',t:'SK Pengenalan Lingkungan Sekolah',icon:'door-open',c:C.coral,kode:'800.2',tujuan:'mengenalkan budaya, aturan, dan lingkungan sekolah kepada peserta didik baru',tentang:'Panitia Masa Pengenalan Lingkungan Sekolah (MPLS)',
  dasar:['Permendikbud Nomor 30 Tahun 2017 tentang MPLS','Surat Edaran Dinas Pendidikan tentang Larangan Pungutan & Kekerasan'],
  menetapkan:'menetapkan Panitia MPLS yang melaksanakan kegiatan pengenalan lingkungan sekolah secara positif, tanpa kekerasan, dan tanpa pungutan.',
  tim:[['Ketua Panitia','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Pendamping','(diisi panitia)']]},
 {id:'asesmen',t:'SK Penyelenggara Asesmen Nasional',icon:'target',c:C.peri,kode:'800.2',tujuan:'menyelenggarakan Asesmen Nasional secara tertib dan akuntabel',tentang:'Tim Penyelenggara Asesmen Nasional',
  dasar:['Permendikbudristek Nomor 5 Tahun 2022 tentang Asesmen Nasional','Juknis PAN dari BSKAP Kemendikbudristek'],
  menetapkan:'menetapkan Tim Penyelenggara Asesmen Nasional yang meliputi ketua pengawas, proktor, proktor pembantu, dan pengawas ruang sesuai ketentuan yang berlaku.',
  tim:[['Ketua Pengawas','(diisi panitia)'],['Proktor','(diisi panitia)'],['Pengawas Ruang','(diisi panitia)']]},
 {id:'komite',t:'SK Penyelenggara Komite Sekolah',icon:'users-round',c:C.green,kode:'800.2',tujuan:'menyelenggarakan musyawarah pemilihan dan penguatan peran komite sekolah',tentang:'Panitia Penyelenggaraan Musyawarah Komite Sekolah',
  dasar:['Permendiknas Nomor 8 Tahun 2016 tentang Komite Sekolah','AD/ART Komite Sekolah'],
  menetapkan:'menetapkan Panitia Musyawarah Komite Sekolah yang bertugas menyelenggarakan rapat kerja, pemilihan pengurus, dan penyusunan program kerja komite.',
  tim:[['Ketua Panitia','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Anggota','(diisi panitia)']]},
 {id:'ujian',t:'SK Penyelenggaraan Ujian',icon:'clipboard-check',c:C.amber,kode:'800.2',tujuan:'menyelenggarakan ujian akhir dan ujian sekolah secara tertib',tentang:'Panitia Penyelenggaraan Ujian Sekolah',
  dasar:['Permendikbudristek tentang Penilaian & Ujian','Kalender Pendidikan Tahun Berjalan'],
  menetapkan:'menetapkan Panitia Ujian yang melaksanakan persiapan, pelaksanaan, pengawasan, dan pengolahan hasil ujian seluruh jenjang kelas.',
  tim:[['Ketua Panitia','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Pengawas','(diisi panitia)']]},
 {id:'timbos',t:'SK Tim BOS Sekolah',icon:'landmark',c:C.green,kode:'821.2',tujuan:'mengelola dan mempertanggungjawabkan penggunaan Dana BOS',tentang:'Tim Pengelola Dana Bantuan Operasional Sekolah',
  dasar:['Permendikbudristek Nomor 4 Tahun 2022 tentang BOS','Panduan Pengelolaan Dana BOS Tahun Anggaran Berjalan'],
  menetapkan:'menetapkan Tim Pengelola Dana BOS yang bertugas menyusun RKAS, melaksanakan pengeluaran, melakukan pencatatan, dan menyusun laporan penggunaan dana.',
  tim:[['Penanggung Jawab','(Kepala Sekolah)'],['Ketua Tim','(diisi panitia)'],['Bendahara','(diisi panitia)']]},
 {id:'bendbos',t:'SK Bendahara BOS Sekolah',icon:'banknote',c:C.gold,kode:'821.2',tujuan:'menetapkan pejabat bendahara dana BOS',tentang:'Penetapan Bendahara Dana BOS',
  dasar:['Permendikbudristek Nomor 4 Tahun 2022 tentang BOS','Peraturan Bendahara Sekolah Dinas Pendidikan'],
  menetapkan:'menetapkan Bendahara BOS yang berwenang menerima, menyimpan, mengeluarkan, dan mempertanggungjawabkan Dana BOS sesuai RKAS yang disahkan.',
  tim:[['Bendahara BOS','(diisi panitia)'],['Pengawas Internal','(diisi panitia)']]},
 {id:'rkas',t:'SK Pengesahan RKAS BOS',icon:'file-check',c:C.cyan,kode:'821.2',tujuan:'mengesahkan Rencana Kerja Anggaran Sekolah',tentang:'Pengesahan Rencana Kerja Anggaran Sekolah (RKAS)',
  dasar:['Permendikbudristek Nomor 4 Tahun 2022 tentang BOS','Rancangan RKAS Tahun Anggaran Berjalan'],
  menetapkan:'mengesahkan RKAS Tahun Anggaran berjalan sebagaimana terlampir, sehingga dapat digunakan sebagai dasar pelaksanaan anggaran sepanjang tahun berjalan.',
  tim:[['Kepala Sekolah','(Kepala Sekolah)'],['Bendahara','(diisi panitia)'],['Ketua Komite','(diisi komite)']]},
 {id:'tppk',t:'SK Tim Pencegahan & Penanganan Kekerasan',icon:'shield-alert',c:C.rose,kode:'800.2',tujuan:'mencegah dan menangani segala bentuk kekerasan di lingkungan satuan pendidikan',tentang:'Tim Pencegahan dan Penanganan Kekerasan (TPPK) Lingkungan Sekolah',
  dasar:['Permendikbudristek Nomor 46 Tahun 2023 tentang PPKSP','Surat Edaran Dinas Pendidikan tentang TPPK'],
  menetapkan:'menetapkan TPPK yang bertugas menyusun kebijakan pencegahan, melakukan edukasi, menerima laporan, melakukan pemeriksaan, dan menindaklanjuti kasus kekerasan sesuai prosedur.',
  tim:[['Ketua','(diisi panitia)'],['Sekretaris','(diisi panitia)'],['Anggota','(diisi panitia)']]},
 {id:'pendataan',t:'SK Tim Pendataan Sekolah',icon:'database',c:C.sky,kode:'800.2',tujuan:'melaksanakan pendataan dan pemutakhiran data secara berkala',tentang:'Tim Pendataan Sekolah (Dapodik, EMIS & Verivali)',
  dasar:['Permendikbud tentang Pengelolaan & Pemutakhiran Dapodik','Jadwal Verifikasi & Validasi Data'],
  menetapkan:'menetapkan Tim Pendataan Sekolah yang bertanggung jawab atas akurasi, pemutakhiran berkala, dan verifikasi data pendidik, peserta didik, serta sarana prasarana pada seluruh aplikasi pendataan.',
  tim:[['Penanggung Jawab','(Kepala Sekolah)'],['Operator Dapodik','(diisi panitia)'],['Verifikator Data','(diisi panitia)']]},
 {id:'honor',t:'SK Pemberian Honor Sekolah',icon:'wallet',c:C.amber,kode:'821.2',tujuan:'memberikan penghargaan berupa honor atas tugas tambahan',tentang:'Pemberian Honor Tugas Tambahan & Tenaga Pendukung Kegiatan',
  dasar:['Permendikbudristek Nomor 4 Tahun 2022 tentang BOS (beban pembinaan)','Keputusan Kepala Sekolah tentang Tugas Tambahan'],
  menetapkan:'menetapkan pemberian honor kepada pihak-pihak berikut, dibayarkan setiap bulan dengan sumber dana BOS komponen kegiatan pembelajaran dan kegiatan sekolah:',
  honor:[['(Nama penerima)','(Uraian tugas)','(nominal)']]},
];

/* ---- Penomoran naskah dinas (format Perbup) ---- */
const ROMAWI=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
const BULAN=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const KEAMANAN=[
 ['B','Biasa','Tidak mengakibatkan kerugian bagi instansi'],
 ['T','Terbatas','Mengakibatkan kerugian terbatas bagi instansi'],
 ['R','Rahasia','Mengakibatkan kerugian serius bagi instansi'],
 ['SR','Sangat Rahasia','Mengakibatkan kerugian sangat serius bagi instansi'],
];

/* ---- Pengguna (PIN dikelola aplikasi, bisa diganti & dipulihkan) ---- */
const USERS=[
 {id:'tu',name:'Rina Kartika',role:'Tata Usaha',ini:'TU',c:'#E58BC4'},
 {id:'kepsek',name:'Kepala Sekolah',role:'Kepala Sekolah',ini:'KS',c:'#5BD98A'},
 {id:'guru',name:'Perwakilan Guru',role:'Guru',ini:'GR',c:'#59B7E8'},
];
const KODE_PERBUP={'aktif-s':'400.3.8','aktif-g':'400.3.10','pernah':'400.3.8','mutasi':'400.3.12.1','m8535':'400.3.12.1','ubah':'400.3.12.1','rapor':'400.3.11'};

/* ---- Peta jalan pengembangan ---- */
const PHASES=[
 {id:'f1',t:'Riset & Perencanaan',w:'Nov — Des 2024',st:'selesai',
  d:'Menjajaki kebutuhan tata usaha: wawancara, audit dokumen, dan pemetaan alur administrasi harian sekolah.',
  c:[['r11','Wawancara & observasi tata usaha'],['r12','Audit dokumen & alur kerja'],['r13','Spesifikasi fungsional v1']]},
 {id:'f2',t:'Fondasi & Desain Sistem',w:'Jan — Mar 2025',st:'selesai',
  d:'Arsitektur data lokal, autentikasi peran, dan bahasa visual aplikasi — ditutup dengan purwarupa interaktif.',
  c:[['r21','Arsitektur & skema basis data'],['r22','Bahasa visual & kerangka navigasi'],['r23','Autentikasi & peran pengguna'],['r24','Purwarupa interaktif']]},
 {id:'f3',t:'Modul Administrasi Inti',w:'Apr — Agu 2025',st:'selesai',
  d:'Tiga pilar administrasi — umum, guru, dan siswa — dari data induk, persuratan, rapor berkelanjutan, hingga dokumen digital.',
  c:[['r31','Profil sekolah & kepegawaian'],['r32','Data induk guru & siswa (impor Excel)'],['r33','Generator surat, SK & penomoran Perbup'],['r34','Rapor berkelanjutan kelas 1–6'],['r35','Transkrip & buku induk'],['r36','Ekspor laporan & cetak dokumen']]},
 {id:'f4',t:'Data Jangka Panjang & Keamanan',w:'2026',st:'berjalan',
  d:'Tahun ajaran berlapis (data 5+ tahun), cadangan .prima, kode pemulihan akun, dan edit data di semua modul.',
  c:[['r41','Tahun ajaran & arsip lintas tahun'],['r42','Cadangan & pulihkan .prima'],['r43','Kode pemulihan PIN'],['r44','Edit/hapus data semua modul']]},
 {id:'f5',t:'Portal Wali & Layanan',w:'2026 — 2027',st:'mendatang',
  d:'Memperluas layanan ke wali murid: portal pemantauan, notifikasi pengingat, dan kios PPDB saat penerimaan baru.',
  c:[['r51','Portal wali murid'],['r52','Notifikasi & pengingat'],['r53','Mode kios PPDB']]},
];
const PRINSIP=[
 ['compass','Data milik sekolah','Semua data contoh dikosongkan — sekolah mengisi datanya sendiri.'],
 ['wifi-off','Offline-first','Data tersimpan di komputer sekolah; tidak bergantung internet.'],
 ['keyboard','Keyboard-first','Ctrl K, pintasan cepat, alur kerja tanpa mouse.'],
 ['file-down','Ekspor & cetak bawaan','Excel, PDF, dan dokumen resmi dari setiap modul.'],
];
const REL=[['platform','Aplikasi Windows (.exe) · Electron'],['basis data','Penyimpanan lokal + cadangan .prima'],['distribusi','USB & unduhan sekolah'],['pembaruan','Berkas rilis berkala']];
