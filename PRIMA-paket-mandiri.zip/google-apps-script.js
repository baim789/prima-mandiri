/* ============================================================
   PRIMA PPDB — Google Apps Script (mode internet)
   ============================================================
   CARA PASANG (± 10 menit):
   1. Buka https://sheets.new → buat Google Spreadsheet baru,
      beri nama misal "PPDB SD Negeri Pamengger 01".
   2. Menu: Extensions → Apps Script.
   3. Hapus isi editor, tempel SELURUH kode ini, lalu Simpan.
   4. Klik Deploy → New deployment → type "Web app":
        - Execute as      : Me
        - Who has access  : Anyone
      Klik Deploy, izinkan akses, lalu SALIN "Web app URL"
      (bentuknya https://script.google.com/macros/s/..../exec).
   5. Tempel URL itu di:
        - ppdb.html   → konstanta ENDPOINT_URL (agar pendaftar
          dari rumah terkirim ke Google), dan
        - aplikasi PRIMA → menu PPDB, kolom "Alamat Google Apps
          Script" (agar pendaftaran bisa ditarik dari cloud).
   6. Jika mengubah kode ini, Deploy ulang: Deploy → Manage
      deployments → ✏️ → Version: New version.

   Cara kerja:
   - Formulir publik mengirim POST berisi JSON pendaftaran →
     tersimpan di sheet "PENDAFTAR" (kolom JSON).
   - PRIMA memanggil ?action=queue untuk mengambil pendaftaran
     yang belum ditarik, lalu mengirim action=ack supaya ditandai.
   - Status (Baru/Lulus/…) dikirim PRIMA dengan action=status dan
     disimpan di sheet "STATUS" — bisa dicek pendaftar dari mana saja.
   ============================================================ */

const SHEET_DATA='PENDAFTAR';
const SHEET_STATUS='STATUS';

function doGet(e){
 const p=(e&&e.parameter)||{};
 const ss=SpreadsheetApp.getActiveSpreadsheet();
 if(p.action==='queue'){
  const sh=ss.getSheetByName(SHEET_DATA);
  const out=[];
  if(sh){
   const v=sh.getDataRange().getValues();
   for(let i=1;i<v.length;i++){
    if(String(v[i][2])==='YA')continue;           /* sudah ditarik PRIMA */
    try{out.push(JSON.parse(v[i][3]));}catch(err){}
   }
  }
  return keluar(out);
 }
 if(p.action==='status'){
  const sh=ss.getSheetByName(SHEET_STATUS);
  const m={};
  /* ikut sertakan data pendaftaran agar formulir bisa mencetak
     bukti/pengumuman dari perangkat mana pun (bukan hanya HP pendaftar) */
  const sd=ss.getSheetByName(SHEET_DATA); const regMap={};
  if(sd){
   const vd=sd.getDataRange().getValues();
   for(let i=1;i<vd.length;i++){try{regMap[String(vd[i][1])]=JSON.parse(vd[i][3]);}catch(err){}}
  }
  if(sh){
   const v=sh.getDataRange().getValues();
   for(let i=1;i<v.length;i++){
    const r=String(v[i][0]);
    m[r]={s:String(v[i][1]),ket:String(v[i][2])};
    if(regMap[r]) m[r].d=regMap[r];
   }
  }
  return keluar(m);
 }
 return keluar({ok:true,app:'PRIMA PPDB Gateway'});
}

function doPost(e){
 let b={};
 try{b=JSON.parse(e.postData.contents);}catch(err){return keluar({ok:false,why:'bukan JSON'});}
 const ss=SpreadsheetApp.getActiveSpreadsheet();

 /* PRIMA menandai pendaftaran yang sudah ditarik */
 if(b.action==='ack'){
  const sh=ss.getSheetByName(SHEET_DATA);
  if(sh){
   const v=sh.getDataRange().getValues();
   const regs=(b.regs||[]).map(String);
   for(let i=1;i<v.length;i++){
    if(regs.indexOf(String(v[i][1]))>=0) sh.getRange(i+1,3).setValue('YA');
   }
  }
  return keluar({ok:true});
 }

 /* PRIMA memperbarui status pendaftar */
 if(b.action==='status'){
  let sh=ss.getSheetByName(SHEET_STATUS);
  if(!sh){sh=ss.insertSheet(SHEET_STATUS);sh.appendRow(['REG','STATUS','KET']);}
  const v=sh.getDataRange().getValues();
  let row=-1;
  for(let i=1;i<v.length;i++){ if(String(v[i][0])===String(b.reg)){row=i+1;break;} }
  const ket='diperbarui '+Utilities.formatDate(new Date(),'Asia/Jakarta','dd MMM yyyy');
  if(row<0) sh.appendRow([String(b.reg),String(b.s||''),ket]);
  else{ sh.getRange(row,2).setValue(String(b.s||'')); sh.getRange(row,3).setValue(ket); }
  return keluar({ok:true});
 }

 /* Kiriman pendaftaran baru dari formulir publik */
 if(b.reg){
  let sh=ss.getSheetByName(SHEET_DATA);
  if(!sh){sh=ss.insertSheet(SHEET_DATA);sh.appendRow(['WAKTU','REG','DITARIK','JSON']);}
  const v=sh.getDataRange().getValues();
  let ada=false;
  for(let i=1;i<v.length;i++){ if(String(v[i][1])===String(b.reg)){ada=true;break;} }
  if(!ada){
   const bersih=JSON.parse(JSON.stringify(b));
   /* buang isi berkas (base64) — terlalu besar untuk sel Google Sheets;
      nama berkas tetap tercatat sebagai bukti */
   if(bersih.berkas){
    if(bersih.berkas.akte) delete bersih.berkas.akte.data;
    if(bersih.berkas.kk) delete bersih.berkas.kk.data;
   }
   sh.appendRow([new Date(),String(b.reg),'',JSON.stringify(bersih)]);
  }
  return keluar({ok:true,reg:String(b.reg)});
 }
 return keluar({ok:false,why:'tidak dikenal'});
}

function keluar(o){
 return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
