/* PRIMA — mesin enkripsi berkas data (AES-256-GCM + scrypt).
   Dipakai oleh main.js; dapat diuji langsung dengan node. */
'use strict';
const crypto = require('crypto');
const MAG = 'PRIMAENC1';

function deriveKey(pass, salt){ return crypto.scryptSync(String(pass), salt, 32); }

function encryptJSON(obj, pass){
 const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
 const key = deriveKey(pass, salt);
 const c = crypto.createCipheriv('aes-256-gcm', key, iv);
 const buf = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
 return JSON.stringify({
  enc: MAG,
  salt: salt.toString('base64'),
  iv: iv.toString('base64'),
  tag: c.getAuthTag().toString('base64'),
  data: buf.toString('base64'),
 });
}

function isEncrypted(text){
 try{ const o = JSON.parse(text); return !!(o && o.enc === MAG); }catch(e){ return false; }
}

function decryptJSON(text, pass){
 const o = JSON.parse(text);
 if(!o || o.enc !== MAG) throw new Error('Berkas tidak terenkripsi.');
 const key = deriveKey(pass, Buffer.from(o.salt, 'base64'));
 const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(o.iv, 'base64'));
 d.setAuthTag(Buffer.from(o.tag, 'base64'));
 const plain = Buffer.concat([d.update(Buffer.from(o.data, 'base64')), d.final()]).toString('utf8');
 return JSON.parse(plain);
}

/* ---------- Envelope v2 (PRIMAENC2): kunci data + kunci pemulihan ---------- */
const MAG2='PRIMAENC2';
const ABC='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function buatRecovery(){
 let g=[]; for(let i=0;i<4;i++){ let s=''; for(let j=0;j<5;j++) s+=ABC[Math.floor(Math.random()*ABC.length)]; g.push(s); }
 return 'PRIMA-'+g.join('-');
}
function normSecret(x){ return String(x||'').toUpperCase().replace(/[^A-Z0-9]/g,''); }
function wrapKey(dk,secret){
 const salt=crypto.randomBytes(16),iv=crypto.randomBytes(12);
 const k=deriveKey(secret,salt);
 const c=crypto.createCipheriv('aes-256-gcm',k,iv);
 const ct=Buffer.concat([c.update(dk),c.final()]);
 return {salt:salt.toString('base64'),iv:iv.toString('base64'),tag:c.getAuthTag().toString('base64'),ct:ct.toString('base64')};
}
function unwrapKey(w,secret){
 const k=deriveKey(secret,Buffer.from(w.salt,'base64'));
 const d=crypto.createDecipheriv('aes-256-gcm',k,Buffer.from(w.iv,'base64'));
 d.setAuthTag(Buffer.from(w.tag,'base64'));
 return Buffer.concat([d.update(Buffer.from(w.ct,'base64')),d.final()]);
}
function createEnvelope(obj,pass){
 const dk=crypto.randomBytes(32);
 const rec=buatRecovery();
 const env={enc:MAG2,keys:[Object.assign({t:'p'},wrapKey(dk,normSecret(pass))),Object.assign({t:'r'},wrapKey(dk,normSecret(rec)))],data:null};
 env.data=segelData(obj,dk);
 return {text:JSON.stringify(env),recovery:rec,dk};
}
function segelData(obj,dk){
 const iv=crypto.randomBytes(12);
 const c=crypto.createCipheriv('aes-256-gcm',dk,iv);
 const ct=Buffer.concat([c.update(JSON.stringify(obj),'utf8'),c.final()]);
 return {iv:iv.toString('base64'),tag:c.getAuthTag().toString('base64'),ct:ct.toString('base64')};
}
function bukaData(d,dk){
 const dd=crypto.createDecipheriv('aes-256-gcm',dk,Buffer.from(d.iv,'base64'));
 dd.setAuthTag(Buffer.from(d.tag,'base64'));
 return JSON.parse(Buffer.concat([dd.update(Buffer.from(d.ct,'base64')),dd.final()]).toString('utf8'));
}
function isEncrypted2(text){ try{const o=JSON.parse(text);return !!(o&&o.enc===MAG2);}catch(e){return false;} }
/* buka dengan frasa sandi ATAU kunci pemulihan; kembalikan {data,dk} */
function decryptJSON2(text,secret){
 const o=JSON.parse(text); const s=normSecret(secret);
 for(const w of (o.keys||[])){
  try{ const dk=unwrapKey(w,s); return {data:bukaData(o.data,dk),dk}; }catch(e){}
 }
 throw new Error('Frasa sandi / kunci pemulihan salah.');
}
/* simpan ulang data dengan dk yang sama (kunci pembungkus tidak berubah) */
function resegelJSON(text,dk){
 const o=JSON.parse(text); o.data=segelData(o.__plain||null,dk); return JSON.stringify(o);
}

if(require.main === module){
 const data = {sekolah:{nama:'SD Uji Coba'}, siswa:[1,2,3]};
 const pass = 'kopi-manis-2026';
 const enc = encryptJSON(data, pass);
 console.log('envelope ok      :', isEncrypted(enc));
 console.log('data tersamar    :', !enc.includes('SD Uji Coba'));
 const dec = decryptJSON(enc, pass);
 console.log('dekripsi cocok   :', JSON.stringify(dec) === JSON.stringify(data));
 try{ decryptJSON(enc, 'salah'); console.log('pasword salah    : false (seharusnya melempar)'); }
 catch(e){ console.log('password salah   : true (ditolak)'); }
 /* uji envelope v2 */
 const r=createEnvelope({a:1,nama:'SD Brankas'},'kopi-manis-2026');
 console.log('envelope v2      :', isEncrypted2(r.text));
 const u1=decryptJSON2(r.text,'kopi-manis-2026');
 console.log('buka via sandi   :', u1.data.nama==='SD Brankas');
 const u2=decryptJSON2(r.text,r.recovery);
 console.log('buka via recovery:', u2.data.nama==='SD Brankas');
 const segel=JSON.parse(r.text); segel.data=u1? (function(){const iv=require('crypto').randomBytes(12);const c=require('crypto').createCipheriv('aes-256-gcm',u1.dk,iv);const ct=Buffer.concat([c.update(JSON.stringify({a:2}),'utf8'),c.final()]);return {iv:iv.toString('base64'),tag:c.getAuthTag().toString('base64'),ct:ct.toString('base64')};})():null;
 const u3=decryptJSON2(JSON.stringify(segel),r.recovery);
 console.log('resegel+buka     :', u3.data.a===2);
 try{ decryptJSON2(r.text,'SALAH-SALAH'); console.log('recovery salah   : false'); }catch(e){ console.log('recovery salah   : true (ditolak)'); }
}

module.exports = { encryptJSON, decryptJSON, isEncrypted, createEnvelope, decryptJSON2, isEncrypted2, resegelJSON, segelData, bukaData };
