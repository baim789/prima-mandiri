# PRIMA — Paket Mandiri 🎓

Sistem Administrasi Sekolah + PPDB Online (offline-first, gratis, data 100% milik sekolah).
Terbukti dipakai: **SD Negeri Pamengger 01, Jatibarang, Brebes** (PPDB 2026/2027).

## Isi paket
| Berkas | Fungsi |
|---|---|
| `index.html · style.css · app.js · main.js · preload.js · server.js · cryptolib.js` | Aplikasi PRIMA (desktop & browser) |
| `data/sekolah.js · data/klasifikasi.js` | Konfigurasi menu, kode surat format Brebes |
| `ppdb.html` | Formulir PPDB publik untuk orang tua (siap ditaruh di Netlify) |
| `google-apps-script.js` | Backend gratis Google Sheets untuk mode internet |
| `package.json` | Skrip build installer/portable (Windows, Linux, Mac) |
| `icon.ico`, `README.md` | Ikon & dokumentasi lengkap |

## Jalan 1 — Paling mudah: pakai di browser dulu (0 menit)
Ekstrak, klik dua kali `index.html`. Masuk peran **Tata Usaha** (PIN tertera di kartu).
Semua fitur bisa dicoba; data tersimpan di browser.

## Jalan 2 — Aplikasi desktop Windows (± 5 menit)
Butuh Node.js (nodejs.org). Di folder ini jalankan:
```
npm run build:portable
```
Hasil di `dist-portable/PRIMA-win32-x64/` → jalankan `PRIMA.exe`.
Data otomatis tersimpan ke `D:\PRIMA`. (Ingin installer? `npm run build`.)
Linux: `npm run exe:linux` · Mac: `npm run exe:mac`.

## Jalan 3 — PPDB online untuk orang tua (± 15 menit)
1. Seret folder berisi `ppdb.html` ke **app.netlify.com/drop** → dapat link publik.
2. Buka `https://LINK-ANDA/?setup=1` → **Asisten Setup** menuntun 4 langkah:
   buat Google Script (kode tersedia di tombol salin), tes koneksi, isi identitas
   sekolah, unduh `index.html` final → seret lagi ke Netlify. Selesai!
3. Di aplikasi PRIMA: menu **PPDB → Tarik dari Cloud** → tempel URL Google Script.

## Bantuan
WA **0856-0049-7796** — atau pilih Paket Kopi: kami pasangkan sampai siap pakai ☕
