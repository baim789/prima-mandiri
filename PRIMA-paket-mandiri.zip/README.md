# PRIMA v2 — Sistem Administrasi Sekolah

Aplikasi administrasi sekolah (SD/sederajat) berbahasa Indonesia, berjalan sepenuhnya
di komputer sekolah (offline-first). Semua data contoh **dikosongkan** — sekolah
mengisi datanya sendiri lewat formulir atau impor Excel.

## Yang baru di v2
1. **Beranda rapi** — statistik nyata (siswa, guru, surat, rapor), panduan 3 langkah awal.
2. **Profil Sekolah bisa diisi** — nama sekolah, pemda/dinas, kepala sekolah, NIP, alamat,
   dll. Semua isian otomatis dipakai di **kop surat, SK, MOU, tagihan, dan tanda tangan**
   (ada pratinjau kop langsung di halaman profil).
3. **Pegawai & TU kosong bawaan** — diisi sekolah sendiri.
4. **Menu Sarana & Prasarana serta Keuangan & Anggaran dihapus.**
5. **Data guru & siswa via Excel** — tombol *Template Excel* mengunduh berkas siap isi;
   setelah diisi, unggah lewat *Impor Excel* (mendukung .xlsx asli & .csv, tanpa internet).
   Template & impor juga tersedia untuk pegawai.
6. **Tidak ada lagi data paten** — agenda surat, MOU, pangkat, rapor, semuanya mulai kosong.
7. **Tampilan baru** — permukaan terang yang lega dengan sidebar navy; kartu, formulir,
   tabel, dan tombol dirancang ulang agar nyaman dipakai seharian.
8. **Fitur edit & hapus** — siswa, guru, pegawai, MOU, agenda surat, baris buku agenda
   naskah, semuanya bisa diedit/dihapus.
9. **Cetak rapor asli** — PDF rapor yang diunggah disimpan; dari Buku Induk klik
   *Cetak Rapor Asli (PDF)* → dokumen yang keluar **persis sama dengan PDF yang diunggah**
   (data otentik siswa), selain transkrip rekap kelas 1–6.
10. **Tahun ajaran berlapis (data 5 tahun+)** — pemilih TA **2010–2045** di bilah atas;
    entri tersimpan **sesuai tahun ajaran yang dipilih saat entri** dan tidak pernah
    dihapus otomatis saat ganti tahun.
    **Menu khusus Backup & Pulihkan**: unduh cadangan `.prima` (simpan di flashdisk/drive)
    dan pulihkan kapan saja — aman untuk komputer instal ulang / ganti komputer.
11. **Pemulihan akses petugas pindah tugas** — tiap sekolah punya **Kode Pemulihan**
    (terlihat di Profil Sekolah untuk peran TU/Kepsek). Jika ada pengguna pindah tanpa
    menyerahkan PIN: layar masuk → **Lupa PIN?** → masukkan kode pemulihan → setel PIN baru.
    PIN semua akun juga bisa diganti kapan saja oleh TU/Kepsek di Profil Sekolah.
    Data tidak hilang — yang dipulihkan hanya akses masuk.

## Fitur inti (tetap)
- Login peran: Tata Usaha, Kepala Sekolah, Guru (guru hanya lihat, kecuali unggah rapor).
- Persuratan: 7 jenis surat keterangan, nomor otomatis format Perbup `B/kode/0000/romawi/tahun`.
- Penomoran Naskah Dinas + buku agenda; 2.719 Kode Klasifikasi Arsip (Perbup No. 8/2023) dapat digulir/dicari.
- 13 template SK & MOU dengan pratinjau + cetak.
- Buku Induk Siswa: foto, KK, akte; unggah rapor PDF → nilai terekstraksi otomatis,
  rekaman berkelanjutan kelas 1–6, transkrip, cetak jilid.
- Ekspor Excel/PDF dari semua tabel; cadangan `.prima`.

## Menjalankan & build (npm)
- **Tanpa npm:** klik dua kali `index.html`.
- **`npm start`** → server lokal di http://localhost:8080 (tanpa dependensi).
- **`npm run build`** (di PC Windows) → menghasilkan **installer `PRIMA Setup x.x.x.exe`**
  di folder `dist/` (klik dua kali → instal seperti aplikasi biasa, ada shortcut desktop).
  Build pertama mengunduh Electron ±110 MB sekali saja.
- **`npm run build:portable`** → versi portable `dist-portable/PRIMA-win32-x64/PRIMA.exe`
  (tanpa instalasi).
- **Sudah jadi juga:** ekstrak `PRIMA-win64.zip` → jalankan `PRIMA.exe` (Windows 10/11 64-bit).

## Penyimpanan data otomatis ke folder D:\PRIMA
Saat dijalankan sebagai aplikasi **.exe**, PRIMA membuat folder **`D:\PRIMA`** secara
otomatis pada pemakaian pertama dan menyimpan seluruh data ke
`D:\PRIMA\prima-data.json` **otomatis setiap ada perubahan** — tidak perlu diklik.
(Bila komputer tidak punya drive D, dipakai `C:\PRIMA`; bila dibuka lewat browser,
data memakai penyimpanan browser.) Lokasi selalu terlihat di menu **Backup & Pulihkan**.

## Backup & pindah komputer / instal ulang
Selain penyimpanan otomatis, cadangkan juga secara mandiri. Menu **Backup & Pulihkan** menyediakan:
- **Unduh Cadangan (.prima)** — seluruh data dalam satu berkas; simpan di flashdisk/Google Drive.
- **Pilih Berkas Cadangan** — pulihkan data kapan saja (setelah instal ulang / ganti komputer).
- Tahun ajaran aktif dapat dipilih pada rentang **2010–2045**; entri tersimpan sesuai
  tahun ajaran yang dipilih saat entri dan tidak terhapus otomatis saat ganti tahun.

## Baru di v2.19.0 (Kunci Pemulihan)
Antisipasi lupa frasa sandi kini berlapis empat:
1. "Ingat di komputer ini" (penyimpanan aman OS) — buka otomatis di PC yang sama.
2. KUNCI PEMULIHAN (PRIMA-XXXXX-XXXXX-XXXXX-XXXXX): diterbitkan sekali saat
   enkripsi diaktifkan, bisa disalin/dicetak lewat "Kartu Pemulihan", dan
   berlaku sebagai pembuka data di komputer mana pun.
3. Layar pembuka kunci kini menerima frasa sandi ATAU kunci pemulihan.
4. Cadangan .prima pra-enkripsi tetap terbaca sebagai jalan pulang terakhir.
Format enkripsi naik ke PRIMAENC2 (envelope: kunci data dibungkus terpisah
oleh frasa sandi dan kunci pemulihan).

## Baru di v2.18.0 (Perisai Lengkap)
1. ENKRIPSI DATA (opsional, menu Backup & Pulihkan): berkas D:\PRIMA
   disandikan AES-256-GCM (kunci turunan scrypt dari frasa sandi sekolah).
   Saat aplikasi dibuka, muncul layar pembuka kunci. Opsi "ingat di komputer
   ini" memakai penyimpanan aman OS (DPAPI Windows) sehingga tidak perlu
   mengetik tiap hari. Bila berkas dicuri ke komputer lain, isinya tetap
   tersamar.
2. Paket Linux & Mac: skrip satu perintah `build-linux.sh` (teruji) dan
   `build-mac.sh` — menghasilkan paket portabel seperti versi Windows.
   Linux: ekstrak lalu `./PRIMA --no-sandbox`. Mac: ekstrak,
   `xattr -cr PRIMA.app`, buka lewat klik-kanan > Open (aplikasi tanpa
   tanda tangan Apple).

## Baru di v2.17.0 (Tiga Perisai)
1. Cadangan harian OTOMATIS: setiap hari saat aplikasi dibuka, salinan data
   tersimpan sendiri ke D:\PRIMA\cadangan\prima-TANGGAL.prima (mode desktop).
2. Keamanan login: 3x PIN salah = terkunci 5 menit; semua kejadian penting
   (masuk, impor, cadangan, kirim WA) tercatat di Log Aktivitas pada menu
   Backup & Pulihkan (300 kejadian terakhir).
3. Tombol WhatsApp di setiap baris pendaftar PPDB: sekali klik membuka chat
   ke orang tua dengan pesan status yang sudah tertulis rapi.

## Baru di v2.16.0
Halaman Nilai & Rapor kini punya panel "Rekap e-Rapor": impor berkas Excel
hasil ekspor e-Rapor (atau rekap apa pun) menjadi arsip nilai per TA —
baris judul & kolom dikenali otomatis, nama siswa dicocokkan dengan Data
Siswa, anti-impor-ganda. Tiap rekap bisa dilihat, diekspor ulang ke Excel,
atau dihapus. Ada tombol "Contoh Format".

## Baru di v2.15.0
Menu PPDB punya tombol "Impor SPMB" — unggah berkas Excel/CSV daftar murid
baru dari SPMB kabupaten (atau sistem lain) dan kolom dikenali otomatis
(nama, L/P, tempat & tanggal lahir, agama, alamat, orang tua, HP, dll).
Pendaftar ganda dilewati otomatis; status awal hasil impor bisa dipilih
(Baru / Berkas Lengkap / Diterima). Ada tombol "Unduh Contoh Format" untuk
mencoba.

## Baru di v2.14.0
Tampilan dipercantik: ikon menu samping kini berwarna per bagian (kotak ikon
berwarna di menu utama & ikon berwarna di submenu), dan layar masuk dibuat
lebih elegan — kepala gradasi navy-hijau dengan logo, nama sekolah otomatis,
dan chip langkah ①③.

## Baru di v2.13.0
**Asisten Setup Sekolah Baru** — buka formulir dengan tambahan `?setup=1`
(mis. https://situs-anda.netlify.app/?setup=1) maka muncul panduan 4 langkah
untuk sekolah lain: salin kode Apps Script (tersedia di halaman), uji URL
Google, isi identitas sekolah, lalu unduh index.html yang sudah diracik —
tinggal seret ke Netlify. Sekolah awam bisa mandiri ± 15 menit tanpa
menyentuh kode.

## Baru di v2.12.9
URL Google Apps Script dipindah ke deployment baru (ber-fitur lengkap) dan
ditanamkan ulang di ppdb.html + aplikasi. Data lama tetap aman karena
spreadsheet-nya sama.

## Baru di v2.12.8
Tombol "Tes Koneksi" kembali tampil di menu PPDB (sempat hilang pada build
sebelumnya). Bila deployment Google dibuat baru (URL baru), cukup tempel URL
baru di kolom Google menu PPDB dan di ENDPOINT_URL ppdb.html.

## Baru di v2.12.7
Perbaikan cetak di HP/Android: lembar Pengumuman Lulus tidak lagi dilepas
sebelum dialog cetak selesai (PDF tidak kosong/rusak). Nomor versi tampil di
footer formulir untuk memudahkan pengecekan cache (mis. "v2.12.7").

## Baru di v2.12.6
Status Google kini ikut membawa data pendaftaran — tombol "Cetak Bukti" dan
"🎉 Cetak Pengumuman Lulus" muncul di **perangkat mana pun** (bukan hanya HP
yang dipakai mendaftar). Perlu memperbarui Apps Script: tempel ulang isi
`google-apps-script.js` lalu Deploy → New version (URL tetap sama).

## Baru di v2.12.5
**Cetak Pengumuman Kelulusan** — saat pendaftar cek status dan hasilnya
"Lulus", muncul tombol 🎉 "Cetak Pengumuman Lulus": lembar A4 resmi dengan
kop sekolah, bingkai dobel hijau-emas, pita "DINYATAKAN LULUS", stempel
LULUS miring, data siswa, dan kolom tanda tangan — siap dicetak & dibawa
daftar ulang.

## Baru di v2.12.4
Perbaikan URL Google Apps Script bawaan (menunjuk deployment asli) +
**kirim ulang otomatis**: formulir publik yang dibuka ulang otomatis mengirim
lagi pendaftaran yang sebelumnya gagal terkirim ke Google — data tidak hilang
walaupun sempat ada gangguan jaringan/URL.

## Baru di v2.12.3
Menu PPDB: tombol **"Tes Koneksi"** untuk memeriksa sambungan ke Google
Apps Script lengkap dengan keterangan penyebab bila gagal (HTTP / pesan
error), sehingga mudah membedakan masalah alamat, jaringan, atau
deployment.

## Baru di v2.12.2
Formulir publik siap **disebar online**: identitas sekolah (SD Negeri
Pamengger 01, Jatibarang, Brebes) kini tampil benar walau dibuka dari HP
pendaftar. Paket siap-hosting tersedia sebagai `PRIMA-ppdb-online.zip`
(isinya folder `ppdb-online` dengan index.html) — tinggal tarik-letakkan ke
Netlify Drop / Vercel / GitHub Pages, langsung dapat link untuk disebar.

## Baru di v2.12.1
URL Google Apps Script sekolah **sudah ditanamkan** di `ppdb.html`
(ENDPOINT_URL) dan **diprasetel** di aplikasi PRIMA (kolom "Alamat Google
Apps Script" menu PPDB sudah terisi otomatis) — formulir publik langsung
mengirim salinan pendaftaran ke Google Spreadsheet, dan PRIMA tinggal klik
"Tarik dari Cloud". URL tetap bisa diganti kapan saja dari kolom tersebut.

## Baru di v2.12.0
**PPDB Mode Internet (Google Apps Script)** — pendaftar bisa mengirim dari
rumah lewat internet, tidak harus di jaringan sekolah.
Cara pasang (± 10 menit):
1. Buat Google Spreadsheet baru → Extensions → Apps Script.
2. Salin seluruh isi file `google-apps-script.js` ke editor, simpan.
3. Deploy → New deployment → Web app → Execute as: Me →
   Who has access: **Anyone** → salin Web app URL-nya.
4. Tempel URL itu di `ppdb.html` (konstanta `ENDPOINT_URL`) dan di aplikasi
   PRIMA: menu **PPDB** → kolom **"Alamat Google Apps Script"**.
5. Klik **"Tarik dari Cloud"** (atau otomatis saat membuka menu PPDB).
Perubahan status di PRIMA tersinkron ke Google sehingga pendaftar bisa cek
status dari mana saja. Catatan: demi batas Google Sheets, isi berkas (akte/KK)
tidak ikut ke cloud — hanya datanya; berkas asli tetap tersimpan di mode
jaringan lokal / komputer tempat formulir diisi.

## Baru di v2.11.0
**PPDB Mode Jaringan Lokal** — pendaftar tidak harus memakai komputer yang
sama dengan PRIMA!
1. Jalankan `npm start` di komputer sekolah (atau pakai versi portable +
   server), komputer tampil sebagai “server PRIMA”.
2. Saat server jalan, terminal menampilkan alamat formulir, contoh:
   `http://192.168.x.x:8080/ppdb.html`.
3. Orang tua membuka alamat itu dari **HP/laptop mana pun yang satu jaringan
   Wi-Fi sekolah** → mengisi formulir → data terkirim ke server sekolah.
4. Buka menu **PPDB** di PRIMA — pendaftaran baru **ditarik otomatis**
   (ada juga tombol **“Tarik dari Server”** untuk menarik kapan saja).
   Kolom alamat server tersedia bila PRIMA dan server berada di komputer
   berbeda.
5. Perubahan status (Baru/Lulus/Cadangan/Ditolak) tersinkron ke server,
   sehingga pendaftar bisa **cek status dari perangkatnya sendiri**.

## Baru di v2.10.0
**Tautan Resmi Dinas di Beranda** — 19 portal penting tersimpan rapi di
halaman awal, dikelompokkan: Dapodik & Data Sekolah (Portal Dapodik,
Manajemen Sekolah, Individual GTK, Verval SP/PTK/PD, Keaktifan NUPTK,
Sekolah Kita, Cek NISN), Keuangan & Pengadaan (BOS Online, SIPLah,
Coretax), Guru & Kepegawaian (PMM, MyASN, Portal Ijazah), Dinas Kab.
Brebes (Simasganteng, Etika), dan Media Sosial Resmi. Klik langsung
terbuka di browser.

## Baru di v2.9.0
**Menu Arsip Digital** — penyimpanan berkas digital sekolah per tahun.
Submenu **Tahun 2010 s.d. 2045**, masing-masing berisi tiga folder:
**Sekolah, Guru, dan Siswa**. Setiap folder bisa ditambah banyak berkas
sekaligus (maks. 3 MB per berkas), dilihat, diunduh, dan dihapus.
Isi arsip ikut tersimpan pada data PRIMA sehingga terbawa backup & restore.
Ada tombol pintas menuju halaman Dokumen TA terkait.

## Baru di v2.8.0
**Hapus per Kelas** — tombol merah di toolbar Data Siswa untuk menghapus
banyak siswa sekaligus dalam satu kelas (misal setelah salah impor).
Pilih kelas → tampil daftar nama yang akan dihapus → konfirmasi → selesai.
Rapor, dokumen, dan berkas terkait siswa tersebut ikut terhapus.
Selalu tersedia konfirmasi sebelum eksekusi; tindakan bersifat permanen.

## Baru di v2.7.1
**Ganti tahun ajaran langsung me-render ulang halaman.** Sebelumnya tampilan
bisa tetap menunjukkan data tahun lama setelah TA diganti. Kini setiap
pergantian TA (bilah atas maupun Profil) otomatis memuat ulang halaman —
tahun yang belum diisi langsung tampil kosong. Ditambah **tombol refresh**
(ikon ⟳ di sebelah pemilih TA) untuk memuat ulang tampilan kapan saja.
Form siswa kini punya pilihan **Angkatan / Tahun Ajaran Masuk** — berguna
untuk memindahkan data yang telanjur ter-input di tahun ajaran yang salah.
Juga perbaikan bug: menyimpan siswa tanpa isi mutasi tidak lagi gagal.

## Baru di v2.7.0
**Keterangan mutasi / pindah (opsional).**
- Form siswa punya bagian opsional “Keterangan Mutasi / Pindah”: status
  **Mutasi Masuk / Mutasi Keluar** + keterangan (sekolah asal/tujuan & nomor
  surat).
- Siswa mutasi mendapat **lencana “Mutasi …”** pada tabel Data Siswa.
- Di lembar Buku Induk muncul kolom keterangan mutasi serta slot unggah
  **“Dokumen Mutasi / Pindah”** (surat keterangan) — opsional.
- Lembar cetak Buku Induk ikut mencantumkan keterangan mutasi & catatan
  lampiran dokumennya.

## Baru di v2.6.1
**Bukti pendaftaran untuk orang tua.** Setelah kirim, orang tua mendapat
nomor registrasi **plus tombol “Cetak / Simpan Bukti (PDF)”** — lembar bukti
resmi berisi nomor registrasi, data siswa, berkas terlampir, status seleksi,
dan kolom tanda tangan orang tua & panitia (dicetak lewat dialog cetak
browser, bisa “Save as PDF”). Bukti dapat **dicetak ulang kapan saja** dari
kotak Cek Status Pendaftaran, bahkan setelah data diserap PRIMA.

## Baru di v2.6.0
**PPDB Online terintegrasi.**
- `ppdb.html` — formulir publik bertema PRIMA (terang & ramah orang tua):
  4 bagian, unggah Akte+KK (maks 4 MB, drag & drop), captcha penjumlahan,
  nomor registrasi, dan kotak **Cek Status Pendaftaran**. Pola HP kini
  menerima `+62`.
- Kiriman orang tua **masuk otomatis ke menu PPDB di PRIMA** (satu
  komputer/server yang sama, `npm start` lalu buka
  `http://localhost:8080/ppdb.html`); tanpa internet pun berfungsi
  (offline-first). Google Apps Script tetap opsional sebagai salinan.
- Di PRIMA: verifikasi → tetapkan status (Baru/Lulus/Cadangan/Ditolak —
  status terbaca di halaman cek status orang tua) → **“Terima ke Data
  Siswa”** sekali klik: siswa kelas 1A terbuat lengkap dengan lampiran
  Akte & KK.

## Baru di v2.5.0
**Modul Ijazah Kelas 6 / Lulusan.**
- Panel "Ijazah" di Buku Induk Siswa: pilih **lebih dari satu PDF sekaligus**
  (satu berkas per murid, atau PDF berisi nama) — sistem membaca nama pada PDF
  dan menempelkan ijazah ke siswa yang cocok.
- Di lembar siswa kelas 6 / LULUS ada tombol **Unggah / Ganti Ijazah (PDF)**,
  **Cetak Ijazah Asli (PDF)** (hasil cetak identik persis dengan berkas yang
  diunggah), dan **Hapus Ijazah**.
- Ijazah ikut tersimpan otomatis ke `D:\PRIMA` dan cadangan `.prima`.

## Baru di v2.4.0
**Data mengikuti tahun ajaran aktif.** Saat TA diganti (mis. 2022/2023),
halaman Data Siswa, Buku Induk, Kenaikan Kelas, SPP, dan pilihan siswa pada
Nilai/Rapor hanya menampilkan siswa yang memang tercatat pada tahun tersebut.
Tahun yang belum diisi tampil **kosong** dengan pesan yang jelas — tidak lagi
meminjam data tahun lain. Siswa hasil kenaikan kelas otomatis muncul pada TA
berikutnya (kelas +1), dan siswa LULUS tidak muncul lagi pada tahun-tahun
setelahnya. Kolom "Kelas" selalu menunjukkan kelas pada tahun yang sedang
dibuka.

## Baru di v2.3.1
1. **Kartu peran di layar masuk selalu tampil** saat aplikasi dibuka (perbaikan:
   sebelumnya bisa kosong bila ada data sesi tersimpan). Peran sesi terakhir
   terpilih otomatis sebagai bawaan.
2. **Tombol "Hapus Rapor"** kini juga muncul tepat di bawah tombol
   "Unggah Rapor (PDF)" pada tabel Buku Induk Siswa — untuk membuang rapor yang
   keliru lalu mengunggah ulang.
3. **Ikon aplikasi `icon.ico`** (logo P navy-teal) — otomatis dipakai pada
   jendela aplikasi, tab browser, dan installer hasil `npm run build`.

## Baru di v2.3.0
1. **Layar masuk diperlebar** — kartu peran (TU / Kepala Sekolah / Guru) kini
   lebar; nama peran tampil utuh, tidak terpotong.
2. **Menu "Dokumen per Tahun"** — submenu Tahun Ajaran 2010/2011 s.d.
   2045/2046. Klik salah satu tahun untuk melihat semua data yang dientri pada
   tahun tersebut: surat/agenda, siswa masuk (angkatan), dan rapor yang
   diunggah — lengkap dengan kotak saring.
3. **Tombol Simpan eksplisit** — panel Identitas Sekolah & Pengguna/PIN kini
   punya tombol "Simpan" yang jelas (penyimpanan otomatis tetap berjalan).
4. **Rapor anti tertukar** — unggah rapor lewat tombol per siswa di Buku Induk
   kini selalu jatuh ke siswa tersebut (PDF satu murid). Tersedia tombol
   **"Hapus Rapor Ini"** per semester dan **"Hapus Semua Rapor Siswa Ini"** di
   bawah tombol unggah untuk memperbaiki rapor yang keliru.
5. **Penanda rapor S1/S2** — pada RAPOR Rekaman Berkelanjutan, kotak S1/S2
   menyala hijau bertanda ✓ bila rapor semester tersebut sudah ada; abu-abu
   bertanda · bila belum.

## Baru di v2.2.0
1. **Unggah rapor otomatis per nama** — unggah **satu PDF rapor kelas** (berisi
   banyak siswa, mis. 300 siswa × 2 semester): sistem membaca nama pada PDF lalu
   membagikan nilai **ke masing-masing siswa sesuai namanya**, bukan menempel ke
   semua siswa. PDF asli disimpan **sekali** dan dapat dicetak ulang persis
   aslinya dari tiap siswa. Tersedia tombol unggah global di atas Buku Induk
   maupun tombol per siswa (fallback).
2. **Menu Kenaikan Kelas** — akhir tahun ajaran: naikkan satu kelas sekaligus
   (kelas 6 otomatis **LULUS**) atau tandai per siswa siapa yang **tidak naik**.
   Riwayat kenaikan tiap siswa tercatat dan tampil di Buku Induk.
3. **Pengelompokan data per tahun** — Data Siswa dikelompokkan per **angkatan**
   (tahun ajaran saat siswa masuk); Arsip Surat dikelompokkan per **tahun
   ajaran** dengan filter TA.
4. **Login lebih jelas** — kartu peran besar (TU / Kepala Sekolah / Guru); klik
   peran lalu ketik PIN → otomatis masuk. Tombol Masuk tetap tersedia.

## PIN bawaan
- Tata Usaha `2026` · Kepala Sekolah `1971` · Guru `0804`
- Segera ganti lewat Profil Sekolah; simpan **Kode Pemulihan** di tempat aman.

## Struktur berkas
```
index.html                 kerangka + login + palet perintah
style.css                  tema v2 (terang + navy)
app.js                     seluruh logika (termasuk pembaca Excel mandiri)
data/sekolah.js            template surat/SK, navigasi, pengguna
data/klasifikasi.js        2.719 kode Perbup 8/2023
server.js, main.js         server npm & entry Electron
```
