/* PRIMA — entry Electron.
   Data otomatis disimpan ke folder D:\PRIMA (fallback C:\PRIMA bila D tidak ada),
   dibuat otomatis saat aplikasi pertama kali berjalan. */
const {app, BrowserWindow, Menu, ipcMain, shell}=require('electron');
const path=require('path');
const fs=require('fs');
const os=require('os');

function pickDataDir(){
 const cand=process.platform==='win32'
  ?['D:\\PRIMA','C:\\PRIMA']
  :[path.join(os.homedir(),'PRIMA')];
 for(const d of cand){
  try{
   fs.mkdirSync(d,{recursive:true});
   const t=path.join(d,'.tes'); fs.writeFileSync(t,'ok'); fs.unlinkSync(t);
   return d;
  }catch(e){/* coba folder berikutnya */}
 }
 return app.getPath('userData');
}
const DATA_DIR=pickDataDir();
const DATA_FILE=path.join(DATA_DIR,'prima-data.json');
const KEY_FILE=path.join(DATA_DIR,'prima-key.bin');
const {encryptJSON,decryptJSON,isEncrypted,createEnvelope,decryptJSON2,isEncrypted2,segelData}=require('./cryptolib');
let ENC_DK=null,ENC_KEYS=null,ENC_PASS=null; /* mode v2: ENC_DK; mode v1: ENC_PASS */
let safeStore=null;
try{ const {safeStorage}=require('electron'); if(safeStorage&&safeStorage.isEncryptionAvailable&&safeStorage.isEncryptionAvailable()) safeStore=safeStorage; }catch(e){}

function createWindow(){
 const win=new BrowserWindow({
  width:1320, height:840, minWidth:1024, minHeight:640, show:false,
  backgroundColor:'#eef1f8',
  icon:path.join(__dirname,'icon.ico'),
  webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}
 });
 Menu.setApplicationMenu(null);
 win.once('ready-to-show',()=>win.show());
 /* tautan eksternal (target=_blank) dibuka di browser bawaan, bukan di jendela PRIMA */
 win.webContents.setWindowOpenHandler(({url})=>{
  if(/^https?:/i.test(url)){shell.openExternal(url);}
  return {action:'deny'};
 });
 win.loadFile('index.html');
 win.webContents.once('did-finish-load',()=>{
  let raw=null; try{raw=fs.readFileSync(DATA_FILE,'utf8');}catch(e){/* belum ada data */}
  const payload={dir:DATA_DIR,file:DATA_FILE,data:null,encrypted:false};
  if(raw&&(isEncrypted(raw)||isEncrypted2(raw))){
   payload.encrypted=true;
   if(safeStore&&fs.existsSync(KEY_FILE)){
    try{
     const pass=safeStore.decryptString(fs.readFileSync(KEY_FILE));
     if(isEncrypted2(raw)){ const u=decryptJSON2(raw,pass); ENC_DK=u.dk; ENC_KEYS=JSON.parse(raw).keys; payload.data=u.data; }
     else { payload.data=decryptJSON(raw,pass); ENC_PASS=pass; }
     payload.encrypted=false; payload.remembered=true;
    }catch(e){/* frasa sandi OS gagal — minta manual */}
   }
  }else if(raw){ try{payload.data=JSON.parse(raw);}catch(e){} }
  win.webContents.send('prima-data',payload);
 });
}

function tulisData(json){
 fs.mkdirSync(DATA_DIR,{recursive:true});
 let teks=String(json);
 if(ENC_DK){ teks=JSON.stringify({enc:'PRIMAENC2',keys:ENC_KEYS,data:segelData(JSON.parse(json),ENC_DK)}); }
 else if(ENC_PASS){ teks=encryptJSON(JSON.parse(json),ENC_PASS); }
 fs.writeFileSync(DATA_FILE,teks,'utf8');
}
ipcMain.handle('prima-save',async(e,json)=>{
 try{ tulisData(json); return {ok:true,dir:DATA_DIR,file:DATA_FILE}; }
 catch(err){ return {ok:false,error:String(err&&err.message||err)}; }
});
ipcMain.handle('prima-info',async()=>({dir:DATA_DIR,file:DATA_FILE,encrypted:!!(ENC_DK||ENC_PASS)}));
ipcMain.handle('prima-unlock',async(e,secret,remember)=>{
 let raw=null; try{raw=fs.readFileSync(DATA_FILE,'utf8');}catch(err){ return {ok:false,error:'Berkas data tidak ditemukan.'}; }
 try{
  if(isEncrypted2(raw)){ const u=decryptJSON2(raw,secret); ENC_DK=u.dk; ENC_KEYS=JSON.parse(raw).keys;
   if(remember&&safeStore){ try{fs.writeFileSync(KEY_FILE,safeStore.encryptString(String(secret)));}catch(err){} }
   return {ok:true,data:u.data}; }
  const dec=decryptJSON(raw,String(secret)); ENC_PASS=String(secret);
  if(remember&&safeStore){ try{fs.writeFileSync(KEY_FILE,safeStore.encryptString(ENC_PASS));}catch(err){} }
  return {ok:true,data:dec};
 }catch(err){ return {ok:false,error:'Frasa sandi / kunci pemulihan salah — data tetap tersamar.'}; }
});
ipcMain.handle('prima-setenc',async(e,on,pass,remember,json)=>{
 try{
  if(on){
   const env=createEnvelope(JSON.parse(json),pass);
   ENC_DK=env.dk; ENC_KEYS=JSON.parse(env.text).keys; ENC_PASS=null;
   fs.mkdirSync(DATA_DIR,{recursive:true}); fs.writeFileSync(DATA_FILE,env.text,'utf8');
   if(remember&&safeStore){ try{fs.writeFileSync(KEY_FILE,safeStore.encryptString(String(pass)));}catch(err){} }
   return {ok:true,encrypted:true,recovery:env.recovery};
  }
  const rahasia=String(pass);
  if(ENC_DK){ try{decryptJSON2(fs.readFileSync(DATA_FILE,'utf8'),rahasia);}catch(err){ return {ok:false,error:'Frasa sandi / kunci pemulihan salah.'}; } }
  else if(ENC_PASS&&rahasia!==ENC_PASS) return {ok:false,error:'Frasa sandi salah.'};
  ENC_DK=null; ENC_KEYS=null; ENC_PASS=null;
  try{fs.unlinkSync(KEY_FILE);}catch(err){}
  fs.mkdirSync(DATA_DIR,{recursive:true}); fs.writeFileSync(DATA_FILE,String(json),'utf8');
  return {ok:true,encrypted:false};
 }catch(err){ return {ok:false,error:String(err&&err.message||err)}; }
});
ipcMain.handle('prima-save-as',async(e,rel,json)=>{
 try{
  const p=path.join(DATA_DIR,rel);
  fs.mkdirSync(path.dirname(p),{recursive:true});
  let teks=String(json);
  if(ENC_DK) teks=JSON.stringify({enc:'PRIMAENC2',keys:ENC_KEYS,data:segelData(JSON.parse(json),ENC_DK)});
  else if(ENC_PASS) teks=encryptJSON(JSON.parse(json),ENC_PASS);
  fs.writeFileSync(p,teks,'utf8');
  return {ok:true,file:p};
 }catch(err){ return {ok:false,error:String(err&&err.message||err)}; }
});

app.whenReady().then(createWindow);
app.on('window-all-closed',()=>{ if(process.platform!=='darwin') app.quit(); });
