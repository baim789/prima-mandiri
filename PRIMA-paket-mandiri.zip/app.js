/* ============================================================
   PRIMA v2 — Sistem Administrasi Sekolah (logika aplikasi)
   v2: data contoh dikosongkan, form dapat diisi & diedit,
   impor Excel guru/siswa/pegawai, tahun ajaran berlapis,
   pemulihan PIN, cetak rapor asli PDF.
   ============================================================ */
if(!window.lucide){ window.lucide={createIcons(){}}; }

/* ================= Pembaca Excel (.xlsx) mandiri =================
   Tanpa pustaka eksternal: membaca zip + inflate (deflate raw). */
function makeHuff(lengths){
 const counts=new Array(33).fill(0);
 lengths.forEach(l=>{if(l)counts[l]++;});
 const offs=new Array(33).fill(0);
 for(let i=1;i<=32;i++) offs[i]=(offs[i-1]+counts[i-1])*2;
 return {lengths,counts,offs};
}
function huffSym(h,getBit){
 let cur=0,len=0;
 while(len<32){
  cur=(cur<<1)|getBit(); len++;
  const rel=cur-h.offs[len];
  if(rel>=0&&rel<h.counts[len]){
   let idx=rel;
   for(let s=0;s<h.lengths.length;s++){
    if(h.lengths[s]===len){ if(idx===0) return s; idx--; }
   }
  }
 }
 throw new Error('inflate: kode huffman tidak valid');
}
function inflateRaw(src){
 let p=0,bitbuf=0,nbits=0; const out=[];
 const getBit=()=>{ if(nbits===0){ if(p>=src.length) throw new Error('inflate: data terpotong'); bitbuf=src[p++]; nbits=8;} nbits--; const b=bitbuf&1; bitbuf>>=1; return b; };
 const readBits=n=>{let v=0;for(let i=0;i<n;i++)v|=getBit()<<i;return v;};
 const LENB=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
 const LENX=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
 const DBAS=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
 const DEXT=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
 const CLORD=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
 let bfinal=0;
 while(!bfinal){
  bfinal=getBit();
  const btype=readBits(2);
  if(btype===0){
   nbits=0; bitbuf=0;
   if(p+4>src.length) throw new Error('inflate: blok tersimpan terpotong');
   const len=src[p]|(src[p+1]<<8); p+=4;
   if(p+len>src.length) throw new Error('inflate: blok tersimpan terpotong');
   for(let i=0;i<len;i++)out.push(src[p++]);
   continue;
  }
  let litH,distH;
  if(btype===1){
   const lit=[],dis=[];
   for(let i=0;i<144;i++)lit.push(8); for(let i=144;i<256;i++)lit.push(9);
   for(let i=256;i<280;i++)lit.push(7); for(let i=280;i<288;i++)lit.push(8);
   for(let i=0;i<30;i++)dis.push(5);
   litH=makeHuff(lit); distH=makeHuff(dis);
  }else if(btype===2){
   const hlit=readBits(5)+257, hdist=readBits(5)+1, hclen=readBits(4)+4;
   const cl=new Array(19).fill(0);
   for(let i=0;i<hclen;i++) cl[CLORD[i]]=readBits(3);
   const clH=makeHuff(cl);
   const lens=new Array(hlit+hdist).fill(0); let i=0;
   while(i<hlit+hdist){
    const s=huffSym(clH,getBit);
    if(s<16){lens[i++]=s;}
    else if(s===16){const rep=3+readBits(2),prev=i?lens[i-1]:0;for(let r=0;r<rep;r++)lens[i++]=prev;}
    else if(s===17){i+=3+readBits(3);}
    else{i+=11+readBits(7);}
   }
   litH=makeHuff(lens.slice(0,hlit)); distH=makeHuff(lens.slice(hlit));
  }else throw new Error('inflate: tipe blok tidak dikenal');
  while(true){
   const sym=huffSym(litH,getBit);
   if(sym<256){out.push(sym);}
   else if(sym===256) break;
   else{
    const li=sym-257, len=LENB[li]+readBits(LENX[li]);
    const dSym=huffSym(distH,getBit), dist=DBAS[dSym]+readBits(DEXT[dSym]);
    if(dist>out.length) throw new Error('inflate: jarak tidak valid');
    for(let i=0;i<len;i++) out.push(out[out.length-dist]);
   }
  }
 }
 return new Uint8Array(out);
}
function unzipBuffer(buf){
 const b=new Uint8Array(buf), files={}; const td=new TextDecoder('utf-8');
 let p=0;
 while(p+30<=b.length){
  const sig=b[p]|(b[p+1]<<8)|(b[p+2]<<16)|(b[p+3]<<24);
  if(sig!==0x04034b50) break;
  const method=b[p+8]|(b[p+9]<<8);
  const csize=b[p+18]|(b[p+19]<<8)|(b[p+20]<<16)|(b[p+21]<<24);
  const nlen=b[p+26]|(b[p+27]<<8), elen=b[p+28]|(b[p+29]<<8);
  const name=td.decode(b.subarray(p+30,p+30+nlen));
  const dataStart=p+30+nlen+elen;
  const raw=b.subarray(dataStart,dataStart+csize);
  files[name]=method===8?inflateRaw(raw):raw.slice(0);
  p=dataStart+csize;
 }
 return files;
}
function readXLSX(buf){
 const files=unzipBuffer(buf);
 const td=new TextDecoder('utf-8');
 const ssName=Object.keys(files).find(n=>/sharedStrings\.xml$/.test(n));
 const shared=[];
 if(ssName){
  const xml=td.decode(files[ssName]);
  xml.replace(/<si>([\s\S]*?)<\/si>/g,(m,inner)=>{
   let s=''; inner.replace(/<t[^>]*>([\s\S]*?)<\/t>/g,(mm,t)=>{s+=t;return t;});
   shared.push(s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#10;/g,'\n').replace(/&amp;/g,'&'));
   return m;});
 }
 const shName=Object.keys(files).find(n=>/xl\/worksheets\/sheet1\.xml$/.test(n))||Object.keys(files).find(n=>/xl\/worksheets\/.*\.xml$/.test(n));
 if(!shName) throw new Error('Berkas Excel tidak memiliki lembar kerja.');
 const xml=td.decode(files[shName]);
 const rows=[];
 xml.replace(/<row[^>]*>([\s\S]*?)<\/row>/g,(m,rowXml)=>{
  const cells=[];
  rowXml.replace(/<c\s+([^>]*)\/>|<c\s+([^>]*?)>([\s\S]*?)<\/c>/g,(mm,a1,a2,inner)=>{
   const attrs=a1||a2||''; inner=inner||'';
   const rm=attrs.match(/r="([A-Z]+)\d+"/), tm=attrs.match(/t="([^"]+)"/);
   const colIdx=rm?rm[1].split('').reduce((acc,ch)=>acc*26+(ch.charCodeAt(0)-64),0)-1:cells.length;
   let val='';
   const t=tm?tm[1]:'';
   const vMatch=inner.match(/<v>([\s\S]*?)<\/v>/), isMatch=inner.match(/<is>([\s\S]*?)<\/is>/);
   if(t==='s'&&vMatch) val=shared[parseInt(vMatch[1],10)]||'';
   else if(t==='inlineStr'&&isMatch){isMatch[1].replace(/<t[^>]*>([\s\S]*?)<\/t>/g,(x,tt)=>{val+=tt;return tt;});}
   else if(vMatch) val=vMatch[1];
   val=String(val).replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&amp;/g,'&');
   cells[colIdx]=val; return mm;
  });
  while(cells.length&&!cells[cells.length-1])cells.pop();
  rows.push(cells); return m;
 });
 return rows;
}
function parseCSVText(txt){
 const rows=[]; let row=[],cur='',q=false;
 for(let i=0;i<txt.length;i++){
  const ch=txt[i];
  if(q){ if(ch==='"'){ if(txt[i+1]==='"'){cur+='"';i++;} else q=false; } else cur+=ch; }
  else{
   if(ch==='"')q=true;
   else if(ch===';'||ch===','||ch==='\t'){row.push(cur);cur='';}
   else if(ch==='\n'){row.push(cur);rows.push(row);row=[];cur='';}
   else if(ch!=='\r')cur+=ch;
  }
 }
 if(cur.length||row.length){row.push(cur);rows.push(row);}
 return rows.filter(r=>r.some(c=>String(c).trim()));
}

/* ================= Tahun ajaran (2010/2011 s.d. 2045/2046) ================= */
const taNow=()=>{const d=new Date(),y=d.getMonth()>=6?d.getFullYear():d.getFullYear()-1;return y+'/'+(y+1);};
const taList=()=>{const out=[];for(let y=2010;y<=2045;y++)out.push(y+'/'+(y+1));return out;};

/* ================= Profil sekolah (sumber kop surat) ================= */
const SEKOLAH_DEFAULT={
 jenjang:'SD', nama:'', pemda:'', dinas:'DINAS PENDIDIKAN', npsn:'', nss:'',
 status:'Negeri', akreditasi:'', kurikulum:'Kurikulum Merdeka',
 kepsek:'', nipKepsek:'', alamat:'', telp:'', email:'', kota:'', spp:100000,
};

/* ================= State ================= */
const state={
 page:null, open:'umum',
 user:null, loginSel:'tu',
 suratAgenda:[],
 abs:{},
 spp:{},
 uploads:{logo:null, siswa:{}, guru:{}},
 noSurat:{}, noSk:40, skNos:{}, docHtml:'',
 rapor:{}, raporBerkas:{}, naikLog:[], ijazah:{}, ijazahBerkas:{}, ppdb:[], rekap:{}, log:[],
 arsip:{},
 ppdbServer:'',
 gasUrl:'https://script.google.com/macros/s/AKfycby71SbJ-aryMYk920tsK5C1Ao4geCvnoaXVZZhcrgQDSaiHjk7-iFBKG2Wfnh1RRjpk7w/exec',
 naskah:{aman:'B',kode:'000.5.3.4',urut:1,bulan:new Date().getMonth(),tahun:new Date().getFullYear(),agenda:[]},
 deliv:{r11:1,r12:1,r13:1,r21:1,r22:1,r23:1,r24:1,r31:1,r32:1,r33:1,r34:1,r35:1,r36:1,r41:1,r42:1,r43:1,r44:1,r51:0,r52:0,r53:0},
 sekolah:Object.assign({},SEKOLAH_DEFAULT),
 ta:taNow(),
 pins:{tu:'2026',kepsek:'1971',guru:'0804'},
 recovery:'',
 lastBackup:0, lastAutoBackup:'',
};
const ABS_ORDER=['Hadir','Izin','Sakit','Alfa'];
const ABS_C={Hadir:'#5BD98A',Izin:'#F5B841',Sakit:'#F08A5D',Alfa:'#F2708A'};
const genRecovery=()=>{const ch='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<8;i++)s+=ch[Math.floor(Math.random()*ch.length)];return s.slice(0,4)+'-'+s.slice(4);};

/* ================= Penyimpanan lokal (localStorage) ================= */
const LS_KEY='prima-v2';
let _svT=null;
const requestSave=()=>{clearTimeout(_svT);_svT=setTimeout(simpan,350);};
function collectSave(){
 return {abs:state.abs,spp:state.spp,noSurat:state.noSurat,noSk:state.noSk,
  skNos:state.skNos,deliv:state.deliv,naskah:state.naskah,uploads:state.uploads,
  pegawai:PEGAWAI,mou:MOUD,pangkat:PANGKAT,user:state.user,suratAgenda:state.suratAgenda,
  rapor:state.rapor,raporBerkas:state.raporBerkas,naikLog:state.naikLog,ijazah:state.ijazah,ijazahBerkas:state.ijazahBerkas,ppdb:state.ppdb,rekap:state.rekap,log:state.log,arsip:state.arsip,ppdbServer:state.ppdbServer,gasUrl:state.gasUrl,
  siswa:SISWA,guru:GURU,sekolah:state.sekolah,ta:state.ta,
  pins:state.pins,recovery:state.recovery,lastBackup:state.lastBackup,lastAutoBackup:state.lastAutoBackup};
}
function simpan(){
 const data=Object.assign(collectSave(),{t:Date.now()});
 let akhir=data;
 const coba=d=>{localStorage.setItem(LS_KEY,JSON.stringify(d));return true;};
 try{ coba(data); }
 catch(e){
  try{ akhir=Object.assign({},data,{uploads:{logo:state.uploads.logo,siswa:{},guru:{}}});
   coba(akhir); toast('Penyimpanan hampir penuh — foto/berkas guru tidak ikut tersimpan. Segera buat cadangan .prima!','alert-triangle'); }
  catch(e2){
   try{ akhir=Object.assign({},data,{uploads:{logo:null,siswa:{},guru:{}},rapor:stripRaporData()});
    coba(akhir); toast('Penyimpanan penuh — berkas PDF rapor dilepas dari simpanan (nilai tetap). Buat cadangan .prima sekarang!','alert-triangle'); }
   catch(e3){ toast('Gagal menyimpan — penyimpanan browser penuh. Ekspor cadangan lalu hapus data lama.','alert-triangle'); }
  }
 }
 /* mode aplikasi desktop: tulis juga ke folder D:\PRIMA\prima-data.json */
 if(window.primaFS&&window.primaFS.save){
  try{
   const pr=window.primaFS.save(JSON.stringify(akhir));
   if(pr&&pr.then) pr.then(res=>{window.__PRIMA_FS_OK=!!(res&&res.ok);}).catch(()=>{});
  }catch(e){}
 }
}
function stripRaporData(){
 const r={};
 for(const sp in state.rapor){ r[sp]={};
  for(const k in state.rapor[sp]){ r[sp][k]={};
   for(const sem in state.rapor[sp][k]){ const rec=Object.assign({},state.rapor[sp][k][sem]); delete rec.data; delete rec.berkas; r[sp][k][sem]=rec; } } }
 return r;
}
function muat(){
 let raw=null;
 try{raw=localStorage.getItem(LS_KEY);}catch(e){return false;}
 if(!raw) return false;
 let d=null; try{d=JSON.parse(raw);}catch(e){return false;}
 if(!d||typeof d!=='object') return false;
 if(d.abs) Object.assign(state.abs,d.abs);
 if(d.spp) state.spp=d.spp;
 if(d.noSurat) state.noSurat=d.noSurat;
 if(typeof d.noSk==='number') state.noSk=d.noSk;
 if(d.skNos) state.skNos=d.skNos;
 if(d.deliv) Object.assign(state.deliv,d.deliv);
 if(d.naskah) state.naskah=Object.assign({},state.naskah,d.naskah,{agenda:Array.isArray(d.naskah.agenda)?d.naskah.agenda:state.naskah.agenda});
 if(d.uploads) state.uploads=d.uploads;
 const ganti=(dst,src)=>{dst.length=0;(src||[]).forEach(x=>dst.push(x));};
 if(Array.isArray(d.pegawai)) ganti(PEGAWAI,d.pegawai);
 if(Array.isArray(d.mou)) ganti(MOUD,d.mou);
 if(Array.isArray(d.pangkat)) ganti(PANGKAT,d.pangkat);
 if(Array.isArray(d.siswa)) ganti(SISWA,d.siswa);
 if(Array.isArray(d.guru)) ganti(GURU,d.guru);
 if(d.user) state.user=d.user;
 if(Array.isArray(d.suratAgenda)) state.suratAgenda=d.suratAgenda;
 if(d.rapor&&typeof d.rapor==='object') state.rapor=d.rapor;
if(d.rekap&&typeof d.rekap==='object') state.rekap=d.rekap;
if(Array.isArray(d.log)) state.log=d.log;
 if(d.raporBerkas&&typeof d.raporBerkas==='object') state.raporBerkas=d.raporBerkas;
 if(d.ijazah&&typeof d.ijazah==='object') state.ijazah=d.ijazah;
 if(d.ijazahBerkas&&typeof d.ijazahBerkas==='object') state.ijazahBerkas=d.ijazahBerkas;
 if(Array.isArray(d.naikLog)) state.naikLog=d.naikLog;
 if(Array.isArray(d.ppdb)) state.ppdb=d.ppdb;
 if(typeof d.ppdbServer==='string'&&d.ppdbServer.trim()) state.ppdbServer=d.ppdbServer;
 if(typeof d.gasUrl==='string'&&d.gasUrl.trim()) state.gasUrl=d.gasUrl;
 if(/script\.google\.com\/macros\/s\/AKfycbwAmLbd4vqY/.test(state.gasUrl)) state.gasUrl='https://script.google.com/macros/s/AKfycby71SbJ-aryMYk920tsK5C1Ao4geCvnoaXVZZhcrgQDSaiHjk7-iFBKG2Wfnh1RRjpk7w/exec';
 if(d.arsip&&typeof d.arsip==='object') state.arsip=d.arsip;
 if(d.sekolah) state.sekolah=Object.assign({},SEKOLAH_DEFAULT,d.sekolah);
 if(d.ta) state.ta=d.ta;
 if(d.pins) state.pins=Object.assign({},state.pins,d.pins);
 if(d.recovery) state.recovery=d.recovery;
 if(d.lastBackup) state.lastBackup=d.lastBackup;
if(d.lastAutoBackup) state.lastAutoBackup=d.lastAutoBackup;
 return true;
}

/* ================= Helper ================= */
const badge=(t,c)=>`<span class="badge" style="background:${c}1c;color:${c};border:1px solid ${c}3d"><span class="bdot"></span>${t}</span>`;
const badgeBtn=(s,i)=>`<button class="badge" data-cycle="${i}" style="background:${ABS_C[s]}1c;color:${ABS_C[s]};border:1px solid ${ABS_C[s]}3d;cursor:pointer"><span class="bdot"></span>${s}</button>`;
function ava(n){
 const nm=String(n||'?');
 const cs=[...nm].reduce((a,ch)=>a+ch.charCodeAt(0),0), c=AVA[cs%AVA.length];
 const p=nm.replace(/(Drs\.|S\.Pd\.|M\.Pd\.|S\.Kom\.|S\.Ag\.|,)/g,'').trim().split(/\s+/);
 const ini=((p[0]||'?')[0]+((p[1]||'')[0]||'')).toUpperCase();
 return `<span class="ava" style="background:${c}1c;color:${c};border:1px solid ${c}3d">${ini}</span>`;
}
const head=(t,s,act='')=>`<div class="phead"><div class="pt"><span class="tick"></span><div><h1>${t}</h1><p>${s}</p></div></div><div class="pact">${act}</div></div>`;
const tbl=(id,cols,rows)=>`<div class="panel twrap"><table class="tbl"><thead><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody id="${id}">${rows}</tbody></table></div>`;
const srch=(scope,ph)=>`<label class="srch"><i data-lucide="search"></i><input data-search="${scope}" placeholder="${ph}"></label>`;
const chipsRow=(scope,opts)=>`<div class="chips">${opts.map(([v,l],i)=>`<button class="chip ${i===0?'on':''}" data-chip="${scope}" data-val="${v}">${l}</button>`).join('')}</div>`;
const kvlist=ps=>ps.map(([k,v])=>`<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('');
const rp=n=>'Rp '+(n||0).toLocaleString('id-ID');
const stat=(inner,label,big)=>`<div class="stat ${big?'big':''}"><div class="sv">${inner}</div><div class="sl">${label}</div></div>`;
const cn=(v,dec=0,pre='',suf='')=>`<span data-count="${v}" data-dec="${dec}" data-pre="${pre}" data-suf="${suf}"></span>`;
const tglIndo=(d=new Date())=>d.toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});
const esc=s=>(s&&String(s).trim()?esc2(s):'&hellip;');
const esc2=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const attq=s=>esc2(s).replace(/"/g,'&quot;');
const drow=(l,v)=>`<div class="drow"><span class="dlab">${l}</span><span class="dsep">:</span><span class="dval">${v}</span></div>`;
const sizeFmt=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
const getUp=(kind,key,field)=>kind==='logo'?state.uploads.logo:(state.uploads[kind]&&state.uploads[kind][key]?state.uploads[kind][key][field]:null);
const acceptFor=f=>(f==='foto'||f==='logo')?'image/*':'image/*,application/pdf';
const emptyBox=(icon,t,d,extra='')=>`<div class="empty"><span class="e-ic"><i data-lucide="${icon}"></i></span><b>${t}</b><p>${d}</p><div class="e-act">${extra}</div></div>`;
const rapCount=()=>{let n=0;for(const sp in state.rapor)for(const k in state.rapor[sp])for(const sem in state.rapor[sp][k])if(state.rapor[sp][k][sem])n++;return n;};
const sppAmount=()=>Math.max(0,+state.sekolah.spp||0);
const sppTerkumpul=()=>Object.keys(state.spp).filter(sp=>state.spp[sp]&&state.spp[sp].l).length*sppAmount();
const hadirGuru=()=>{if(!GURU.length)return null;let h=0;GURU.forEach((g,i)=>{if((state.abs[i]||'Hadir')==='Hadir')h++;});return Math.round(h/GURU.length*1000)/10;};

/* ================= Dokumen resmi: kop & builder ================= */
function kop(){
 const S=state.sekolah, L=state.uploads.logo;
 const nm=(S.nama||'NAMA SEKOLAH — lengkapi di Profil Sekolah').toUpperCase();
 return `<div class="kop">
  ${L&&L.data?`<img src="${L.data}" alt="logo">`:'<div class="kop-ph">LOGO<br>SEKOLAH</div>'}
  <div class="kop-t"><div class="k1">${esc2((S.pemda||'PEMERINTAH DAERAH').toUpperCase())}</div><div class="k2">${esc2((S.dinas||'DINAS PENDIDIKAN').toUpperCase())}</div><div class="k3">${esc2(nm)}</div><div class="k4">${esc2(S.alamat||'Alamat sekolah — lengkapi di Profil Sekolah')}${S.telp?' &nbsp;·&nbsp; Telp '+esc2(S.telp):''}${S.email?' &nbsp;·&nbsp; '+esc2(S.email):''}</div></div>
 </div>`;
}
const paper=inner=>`<div class="paper">${inner}</div>`;
const ttdKepsek=()=>{
 const S=state.sekolah;
 return `<div class="ttd">${S.kota?esc2(S.kota)+', ':''}${tglIndo()}<br>Kepala Sekolah,<div class="sp"></div><b>${esc2(S.kepsek||'( Nama Kepala Sekolah )')}</b><br><span class="nip">${S.nipKepsek?'NIP. '+esc2(S.nipKepsek):'NIP.'}</span></div>`;
};
const NOBASE={'aktif-s':0,'aktif-g':0,pernah:0,mutasi:0,m8535:0,ubah:0,rapor:0};
const NOCODE={'aktif-s':'421.2','aktif-g':'800',pernah:'421.2',mutasi:'421.2',m8535:'421.2',ubah:'421.2',rapor:'005'};
function nextNo(id){const k='s_'+id;state.noSurat[k]=(state.noSurat[k]||NOBASE[id])+1;requestSave();return `${NOCODE[id]}/${String(state.noSurat[k]).padStart(3,'0')}/${new Date().getFullYear()}`;}
function nextSkNo(kode){state.noSk++;requestSave();return `${kode}/${String(state.noSk).padStart(3,'0')}/${new Date().getFullYear()}`;}

function suratDoc(id,d,noGiven){
 const no=noGiven||nextNo(id), ttd=ttdKepsek(), ta=state.ta;
 const s=d.siswa?SISWA.find(x=>x.sp===d.siswa):null;
 const g=(d.guru!==undefined&&d.guru!=='')?GURU[+d.guru]:null;
 if(id==='aktif-s') return paper(kop()+`
  <div class="doc-t">SURAT KETERANGAN<br><span class="small">Nomor: ${no}</span></div>
  <p>Yang bertandngan di bawah ini Kepala ${esc2(state.sekolah.nama||'Satuan Pendidikan')}, dengan ini menerangkan bahwa :</p>
  ${drow('Nama Peserta Didik','<b>'+esc(s.n)+'</b>')}
  ${drow('NIS / NISN',esc(s.nis)+' / '+esc(s.nisn))}
  ${drow('Tempat, Tanggal Lahir',esc(s.ttl))}
  ${drow('Kelas','<b>'+esc(s.k)+'</b>')}
  ${drow('Nama Orang Tua / Wali',esc(s.ib))}
  ${drow('Alamat',esc(s.al))}
  <p style="margin-top:9px">adalah benar <b>peserta didik aktif</b> ${esc2(state.sekolah.nama||'satuan pendidikan kami')} pada Tahun Pelajaran ${ta} dan mengikuti kegiatan pembelajaran secara penuh.</p>
  <p>Surat keterangan ini dibuat untuk keperluan <b>${esc(d.keperluan)}</b>.</p>
  <p>Demikian surat keterangan ini dibuat agar dapat dipergunakan sebagaimana mestinya.</p>`+ttd);
 if(id==='aktif-g') return paper(kop()+`
  <div class="doc-t">SURAT KETERANGAN<br><span class="small">Nomor: ${no}</span></div>
  <p>Yang bertanda tangan di bawah ini Kepala ${esc2(state.sekolah.nama||'Satuan Pendidikan')}, dengan ini menerangkan bahwa :</p>
  ${drow('Nama','<b>'+esc(g.n)+'</b>')}
  ${drow('NIP / NUPTK',esc(g.nip))}
  ${drow('Mata Pelajaran / Tugas',esc(g.m))}
  ${drow('Status Kepegawaian','<b>'+esc(g.s)+'</b>')}
  <p style="margin-top:9px">adalah benar <b>guru aktif</b> yang menjalankan tugas mengajar di ${esc2(state.sekolah.nama||'satuan pendidikan kami')} pada Tahun Pelajaran ${ta} dan melaksanakan kewajiban mengajar sesuai beban kerja yang ditetapkan.</p>
  <p>Surat keterangan ini dibuat untuk keperluan <b>${esc(d.keperluan)}</b>.</p>
  <p>Demikian agar dapat dipergunakan sebagaimana mestinya.</p>`+ttd);
 if(id==='pernah') return paper(kop()+`
  <div class="doc-t">SURAT KETERANGAN PERNAH SEKOLAH<br><span class="small">Nomor: ${no}</span></div>
  <p>Yang bertanda tangan di bawah ini Kepala ${esc2(state.sekolah.nama||'Satuan Pendidikan')}, dengan ini menerangkan bahwa :</p>
  ${drow('Nama','<b>'+esc(d.nama)+'</b>')}
  ${drow('NIS / No. Induk',esc(d.nis))}
  ${drow('Tahun Lulus','<b>'+esc(d.tahun)+'</b>')}
  ${d.noijazah?drow('Nomor Ijazah',esc(d.noijazah)):''}
  <p style="margin-top:9px">benar <b>pernah menempuh pendidikan</b> di ${esc2(state.sekolah.nama||'satuan pendidikan kami')} dan dinyatakan <b>LULUS</b> pada tahun ${esc(d.tahun)} melalui rapat pleno dewan guru.</p>
  <p>Surat keterangan ini dibuat untuk keperluan <b>${esc(d.keperluan)}</b>.</p>
  <p>Demikian agar dapat dipergunakan sebagaimana mestinya.</p>`+ttd);
 if(id==='mutasi') return paper(kop()+`
  <div class="doc-t">SURAT MUTASI / PINDAH SEKOLAH<br><span class="small">Nomor: ${no}</span></div>
  <p>Yang bertanda tangan di bawah ini Kepala ${esc2(state.sekolah.nama||'Satuan Pendidikan')}, dengan ini menerangkan bahwa :</p>
  ${drow('Nama Peserta Didik','<b>'+esc(s.n)+'</b>')}
  ${drow('NIS / NISN',esc(s.nis)+' / '+esc(s.nisn))}
  ${drow('Kelas Semula',esc(s.k))}
  ${drow('Nama Orang Tua / Wali',esc(s.ib))}
  <p style="margin-top:9px">terhitung sejak tanggal surat ini dibuat <b>pindah / bermutasi</b> ke <b>${esc(d.tujuan)}</b>. Pemindahan ini atas permintaan orang tua/wali dengan pertimbangan <b>${esc(d.alasan)}</b>, dan sekolah tidak mempunyai keberatan atas perpindahan tersebut.</p>
  <p>Kepada pihak sekolah tujuan, kami mohon dapat menerima dan membina ananda sebagaimana mestinya. Seluruh administrasi sekolah asal telah diselesaikan dan data pada Dapodik akan kami mutakhirkan.</p>
  <p>Demikian surat mutasi ini dibuat agar dapat dipergunakan sebagaimana mestinya.</p>`+ttd);
 if(id==='m8535') return paper(kop()+`
  <div class="doc-t">SURAT KETERANGAN PERUBAHAN DATA PESERTA DIDIK<br><span class="small">(Model 8535) &nbsp;·&nbsp; Nomor: ${no}</span></div>
  <p>Yang bertanda tangan di bawah ini Kepala ${esc2(state.sekolah.nama||'Satuan Pendidikan')} menerangkan dengan sesungguhnya bahwa, berdasarkan hasil penelitian dan verifikasi dokumen, data peserta didik berikut perlu dilakukan <b>perubahan / koreksi pada Dapodik</b> :</p>
  ${drow('Nama Peserta Didik','<b>'+esc(s.n)+'</b>')}
  ${drow('NIS / NISN',esc(s.nis)+' / '+esc(s.nisn))}
  <table class="dt"><thead><tr><th style="width:34px">No</th><th>Uraian Data</th><th>Data Lama (Dapodik)</th><th>Data Baru (sesuai dokumen)</th></tr></thead>
  <tbody><tr><td>1</td><td>${esc(d.jenis)}</td><td>${esc(d.lama)}</td><td><b>${esc(d.baru)}</b></td></tr></tbody></table>
  <p>Perubahan data dilakukan karena <b>${esc(d.alasan)}</b>, disertai dokumen pendukung yang sah dan dapat dipertanggungjawabkan.</p>
  <p>Surat keterangan ini diterbitkan untuk keperluan proses perubahan data pada Dapodik melalui dinas pendidikan yang berwenang.</p>`+ttd);
 if(id==='ubah') return paper(kop()+`
  <div class="doc-t">SURAT KETERANGAN PERUBAHAN IDENTITAS SISWA<br><span class="small">Nomor: ${no}</span></div>
  <p>Yang bertanda tangan di bawah ini Kepala ${esc2(state.sekolah.nama||'Satuan Pendidikan')}, dengan ini menerangkan bahwa :</p>
  ${drow('Nama (sesuai Dapodik)','<b>'+esc(s.n)+'</b>')}
  ${drow('NIS / NISN',esc(s.nis)+' / '+esc(s.nisn))}
  ${drow('Kelas',esc(s.k))}
  ${drow('Identitas Lama','<b>'+esc(d.lama)+'</b>')}
  ${drow('Identitas Baru','<b>'+esc(d.baru)+'</b>')}
  ${drow('Dasar Perubahan',esc(d.dasar))}
  <p style="margin-top:9px">dengan ini menerangkan bahwa <b>identitas lama</b> dan <b>identitas baru</b> tersebut di atas adalah <b>sama orangnya</b>, yaitu peserta didik yang sedang menempuh pendidikan di sekolah kami. Perubahan identitas terjadi karena kepemilikan dokumen resmi terbaru sebagaimana dasar perubahan di atas.</p>
  <p>Surat keterangan ini dibuat untuk keperluan <b>${esc(d.keperluan)}</b>.</p>
  <p>Demikian agar dapat dipergunakan sebagaimana mestinya.</p>`+ttd);
 if(id==='rapor') return paper(kop()+`
  <div class="doc-t">UNDANGAN PENGAMBILAN RAPOR<br><span class="small">Nomor: ${no}</span></div>
  <p>Kepada Yth. Bapak/Ibu Wali Murid dari :</p>
  ${drow('Nama Peserta Didik','<b>'+esc(s.n)+'</b>')}
  ${drow('Kelas',esc(s.k))}
  <p style="margin-top:9px">Dengan hormat, sehubungan dengan berakhirnya semester pada Tahun Pelajaran ${ta}, kami mengundang Bapak/Ibu untuk menghadiri <b>pembagian rapor pendidikan</b> yang akan dilaksanakan pada :</p>
  ${drow('Hari / Tanggal','<b>'+esc(d.tgl)+'</b>')}
  ${drow('Waktu',esc(d.waktu))}
  ${drow('Tempat','Ruang Kelas '+esc(s.k)+', '+esc2(state.sekolah.nama||'sekolah'))}
  <p style="margin-top:9px">Mengingat pentingnya dokumen rapor, kami mengharapkan kehadiran Bapak/Ibu tepat waktu. Apabila berhalangan hadir, dimohon berkenan menghubungi wali kelas untuk penjadwalan ulang.</p>
  <p>Demikian undangan ini kami sampaikan, atas perhatian dan kehadirannya kami ucapkan terima kasih.</p>`+ttd+`
  <p style="margin-top:10px;font-size:10px">Tembusan: Wali Kelas ${esc(s.k)} &nbsp;·&nbsp; Arsip.</p>`);
 return '';
}

function skDoc(sk,no){
 const nmSek=esc2(state.sekolah.nama||'Satuan Pendidikan');
 const tim=sk.tim?`
  <p><b>KEDUA</b> &nbsp;: Untuk melancarkan pelaksanaan tugas, keanggotaan ditetapkan sebagai berikut :</p>
  <table class="dt"><thead><tr><th style="width:34px">No</th><th style="width:44%">Nama</th><th>Jabatan dalam Tim</th></tr></thead>
  <tbody>${sk.tim.map((m,i)=>`<tr><td>${i+1}</td><td>${esc2(m[1])}</td><td>${esc2(m[0])}</td></tr>`).join('')}</tbody></table>`:'';
 const honor=sk.honor?`
  <table class="dt"><thead><tr><th style="width:34px">No</th><th style="width:38%">Nama</th><th>Tugas / Jabatan</th><th style="width:20%">Honor / Bulan</th></tr></thead>
  <tbody>${sk.honor.map((h,i)=>`<tr><td>${i+1}</td><td>${esc2(h[0])}</td><td>${esc2(h[1])}</td><td>Rp ${esc2(h[2])}</td></tr>`).join('')}</tbody></table>
  <p>Honor dibayarkan melalui kas sekolah setiap awal bulan berikutnya, dibukukan sesuai komponen belanja Dana BOS yang berlaku.</p>`:'';
 return paper(kop()+`
  <div class="doc-t">KEPUTUSAN KEPALA ${nmSek.toUpperCase()}<br><span class="small">Nomor: ${no}</span></div>
  <div class="doc-t" style="text-decoration:none;font-size:12px">TENTANG<br><b>${esc(sk.tentang).toUpperCase()}</b></div>
  <p>Kepala ${nmSek},</p>
  <p><b>Menimbang</b></p>
  <p style="margin-left:20px">a. bahwa dalam rangka ${esc(sk.tujuan)}, dipandang perlu menetapkan ${esc(sk.tentang).toLowerCase()} di lingkungan ${nmSek};</p>
  <p style="margin-left:20px">b. bahwa agar pelaksanaan tugas tersebut berjalan tertib, terarah, dan bertanggung jawab, perlu ditetapkan dengan Keputusan Kepala Sekolah;</p>
  <p><b>Mengingat</b></p>
  <ol>${sk.dasar.map(x=>'<li>'+esc(x)+';</li>').join('')}</ol>
  <p><b>MEMUTUSKAN</b></p>
  <p>Menetapkan :</p>
  <p><b>PERTAMA</b> &nbsp;: ${esc(sk.menetapkan)}.</p>
  ${tim}${honor}
  <p><b>KETIGA</b> &nbsp;: Keputusan ini berlaku sejak tanggal ditetapkan, dengan ketentuan apabila di kemudian hari terdapat kekeliruan akan diperbaiki sebagaimana mestinya.</p>
  ${ttdKepsek()}`);
}

function mouDoc(m){
 return paper(kop()+`
  <div class="doc-t">NOTA KESEPAHAMAN<br><span class="small">(Memorandum of Understanding) · Nomor: ${esc(m.no)}</span></div>
  <p>Pada hari ini ${new Date().toLocaleDateString('id-ID',{weekday:'long'})}, tanggal ${tglIndo()}, yang bertanda tangan di bawah ini :</p>
  ${drow('1. Nama','<b>'+esc2(state.sekolah.kepsek||'( Kepala Sekolah )')+'</b>')}
  ${drow('&nbsp;&nbsp;&nbsp;&nbsp;Jabatan','Kepala '+esc2(state.sekolah.nama||'Satuan Pendidikan'))}
  ${drow('2. Nama','<b>'+esc(m.pimpinan)+'</b>')}
  ${drow('&nbsp;&nbsp;&nbsp;&nbsp;Jabatan',esc(m.jabatan)+' — '+esc(m.mitra))}
  <p style="margin-top:9px">selanjutnya disebut <b>Para Pihak</b>, sepakat mengikatkan diri dalam Nota Kesepahaman tentang <b>${esc(m.bidang)}</b> dengan ketentuan sebagai berikut :</p>
  <p><b>Pasal I — Tujuan</b></p>
  <p style="margin-left:20px">Nota Kesepahaman ini dimaksudkan sebagai landasan kerja sama yang saling menguntungkan antara ${esc2(state.sekolah.nama||'sekolah')} dan ${esc(m.mitra)} dalam bidang ${esc(m.bidang).toLowerCase()}.</p>
  <p><b>Pasal II — Ruang Lingkup</b></p>
  <ol>${m.ruang.map(r=>'<li>'+esc(r)+'.</li>').join('')}</ol>
  <p><b>Pasal III — Masa Berlaku</b></p>
  <p style="margin-left:20px">Nota Kesepahaman ini berlaku sejak <b>${esc(m.mulai)}</b> sampai dengan <b>${esc(m.akhir)}</b> dan dapat diperpanjang berdasarkan kesepakatan tertulis kedua belah pihak.</p>
  <p><b>Pasal IV — Penutup</b></p>
  <p style="margin-left:20px">Hal-hal yang belum diatur dalam Nota Kesepahaman ini akan diatur kemudian dalam perjanjian kerja sama teknis tersendiri.</p>
  <div class="ttd2">
   <div>Pihak Pertama<br>${esc2(state.sekolah.nama||'Sekolah')}<div class="sp"></div><b>${esc2(state.sekolah.kepsek||'( Kepala Sekolah )')}</b></div>
   <div>Pihak Kedua<br>${esc(m.mitra)}<div class="sp"></div><b>${esc(m.pimpinan)}</b></div>
  </div>`);
}

/* ================= Penomoran naskah dinas ================= */
const cariKlas=kode=>KLASIFIKASI.find(x=>x[0]===kode);
const nomorNaskah=()=>{const n=state.naskah;return `${n.aman}/${n.kode||'000'}/${String(n.urut).padStart(4,'0')}/${ROMAWI[n.bulan]}/${n.tahun}`;};
const segRow=(c,tok,tt,dd)=>`<div class="seg"><span class="tok" style="background:${c}1c;color:${c};border:1px solid ${c}3d">${tok}</span><span class="sx"><b>${tt}</b>${dd}</span></div>`;
function renderNomorPrev(){
 const n=state.naskah;
 const el=document.getElementById('nomor-prev'); if(el) el.textContent=nomorNaskah();
 const seg=document.getElementById('nomor-seg'); if(!seg) return;
 const e=cariKlas(n.kode), am=KEAMANAN.find(x=>x[0]===n.aman)||KEAMANAN[0];
 seg.innerHTML=
  segRow(C.green,n.aman,'Kode klasifikasi keamanan',`${am[1]} — ${am[2]}.`)+
  segRow(C.lilac,n.kode,'Kode klasifikasi',e?esc2(e[1]):'Tidak ditemukan pada lampiran Perbup.')+
  segRow(C.amber,String(n.urut).padStart(4,'0'),'Nomor urut naskah dinas','Nomor pendaftaran pada buku agenda tahun berjalan.')+
  segRow(C.sky,ROMAWI[n.bulan],'Bulan terbit',`Bulan ke-${n.bulan+1} (${BULAN[n.bulan]}).`)+
  segRow(C.coral,String(n.tahun),'Tahun terbit','Tahun naskah dinas dikeluarkan.');
}
function renderKodeSel(){
 const el=document.getElementById('kode-sel'); if(!el) return;
 const e=cariKlas(state.naskah.kode);
 el.innerHTML=e?`<b>${e[0]}</b><span>${esc2(e[1])}</span>`:`<b>—</b><span>Kode belum dipilih — ketik kata kunci di atas atau gulir daftar.`;
}
function renderKpick(q){
 const list=document.getElementById('kpick-list'); if(!list) return;
 const s=(q||'').toLowerCase();
 const rows=KLASIFIKASI.map((x,i)=>({x,i})).filter(o=>!s||o.x[0].includes(s)||o.x[1].toLowerCase().includes(s)).slice(0,150);
 list.innerHTML=rows.length
  ?rows.map(o=>`<button class="kpick ${o.x[0]===state.naskah.kode?'sel':''}" data-kpick="${o.i}"><span class="kno">${o.x[0]}</span><span>${esc2(o.x[1])}</span></button>`).join('')
  :'<div class="pal-empty">Tidak ada kode yang cocok.</div>';
}
function renderAgenda(){
 const tb=document.getElementById('tb-naskah'); if(!tb) return;
 const lbl={B:'Biasa',T:'Terbatas',R:'Rahasia',SR:'Sangat Rahasia'};
 const clr={B:C.green,T:C.amber,R:C.rose,SR:C.rose};
 const cEl=document.getElementById('ag-cnt'); if(cEl) cEl.textContent=state.naskah.agenda.length;
 tb.innerHTML=state.naskah.agenda.length
  ?state.naskah.agenda.slice().reverse().map((a,ri)=>{const i=state.naskah.agenda.length-1-ri;
   return `<tr><td class="mono strong">${esc2(a.no)}</td><td>${esc2(a.p)}</td><td>${badge(lbl[a.a]||a.a,clr[a.a]||C.grey)}</td><td class="mono">${esc2(a.t)}</td>
   <td style="text-align:right"><button class="ibtn" data-naskahdel="${i}" title="Hapus baris"><i data-lucide="trash-2"></i></button></td></tr>`;}).join('')
  :'<tr><td colspan="5" style="text-align:center;color:var(--tx3);padding:22px">Buku agenda masih kosong — susun nomor lalu klik “Catat ke Buku Agenda”.</td></tr>';
}
const updateNaskah=()=>{renderNomorPrev();renderKodeSel();requestSave();};
function copyText(s){
 const done=()=>toast('Tersalin ke papan klip: '+s,'copy');
 const fb=()=>{const ta=document.createElement('textarea');ta.value=s;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');done();}catch(e){toast('Salin manual: '+s,'info');}ta.remove();};
 if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(s).then(done).catch(fb); else fb();
}
function catatNaskah(){
 const n=state.naskah;
 const pEl=document.getElementById('f-perihal');
 const p=pEl&&pEl.value.trim()?pEl.value.trim():'(tanpa perihal)';
 const e=cariKlas(n.kode);
 n.agenda.push({no:nomorNaskah(),p,u:e?e[1]:'',a:n.aman,t:tglIndo(),ta:state.ta});
 n.urut+=1;
 const uEl=document.getElementById('f-urut'); if(uEl) uEl.value=n.urut;
 renderAgenda(); updateNaskah(); lucide.createIcons();
 toast('Naskah tercatat di buku agenda (TA '+state.ta+') — nomor berikutnya disiapkan.','book-plus');
}

/* ================= Tautan resmi dinas (Beranda) ================= */
const TLINKS=[
 {t:'Dapodik & Data Sekolah',icon:'database',l:[
  ['Portal Dapodik','https://dapo.kemendikdasmen.go.id'],
  ['Manajemen Sekolah','https://sp.datadik.kemendikdasmen.go.id'],
  ['Individual GTK','https://ptk.datadik.kemendikdasmen.go.id'],
  ['Verval SP','http://vervalsp.data.kemendikdasmen.go.id'],
  ['Verval PTK','http://vervalptk.data.kemendikdasmen.go.id'],
  ['Verval PD','http://vervalpd.data.kemendikdasmen.go.id'],
  ['Keaktifan NUPTK','http://gtk.data.kemendikdasmen.go.id'],
  ['Sekolah Kita','http://sekolah.data.kemendikdasmen.go.id'],
  ['Cek NISN','https://nisn.data.kemendikdasmen.go.id/']]},
 {t:'Keuangan & Pengadaan',icon:'wallet',l:[
  ['BOS Online','http://bos.kemendikdasmen.go.id'],
  ['SIPLah','https://siplah.tokoladang.co.id/'],
  ['Pajak (Coretax)','https://coretaxdjp.pajak.go.id/']]},
 {t:'Guru, Kinerja & Kepegawaian',icon:'badge-check',l:[
  ['PMM — Pengelolaan Kinerja','https://guru.kemendikdasmen.go.id/pengelolaan-kinerja'],
  ['MyASN','https://asndigital.bkn.go.id/'],
  ['Portal Ijazah (Verifikasi NIN)','https://ijazah.pendidikan.go.id/verifikasi-nin']]},
 {t:'Dinas Kab. Brebes',icon:'landmark',l:[
  ['Simasganteng','https://simasganteng.brebeskab.go.id/login'],
  ['Etika Dindikpora','https://etika-dindikpora.brebeskab.go.id/etikaweb/dashboard/login']]},
 {t:'Media Sosial Resmi',icon:'share-2',l:[
  ['IG Ditjen Pauddikdasmen','https://instagram.com/ditjen.paud.dikdasmen'],
  ['IG Dapodik','https://instagram.com/dapodik_official']]},
];
const TLINKS_HTML=TLINKS.map(g=>`<div class="lnk-g"><div class="lnk-t"><i data-lucide="${g.icon}"></i>${esc2(g.t)}</div><div class="lnk-row">${g.l.map(([n,u])=>`<a class="lnk" href="${u}" target="_blank" rel="noopener"><i data-lucide="external-link"></i>${esc2(n)}</a>`).join('')}</div></div>`).join('');

/* ================= PAGES ================= */
const PAGES={

beranda(){
 const u=state.user;
 const nm=u?u.name.split(',')[0]:'Pengguna';
 const h=new Date().getHours();
 const greet=h<11?'Selamat pagi':h<15?'Selamat siang':h<19?'Selamat sore':'Selamat malam';
 const tgl=new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 const hadir=hadirGuru();
 const kosong=!SISWA.length&&!GURU.length;
 const suratBulanIni=state.suratAgenda.filter(a=>{const m=a.t&&a.t.match(/(\d{4})$/);return m&&+m[1]===new Date().getFullYear();}).length;
 const mulai=`
  <div class="panel mb16"><div class="ph"><span>Memulai PRIMA</span><span class="sub">3 langkah pertama</span></div><div class="pb steps">
   <div class="step"><span class="stn">1</span><div><b>Isi Profil Sekolah</b><p>Nama sekolah, kepala sekolah, dan alamat dipakai otomatis di semua kop surat.</p></div><button class="btn ghost" data-go="profil">Buka Profil</button></div>
   <div class="step"><span class="stn">2</span><div><b>Unduh template Excel guru & siswa</b><p>Isi data di Excel, lalu unggah kembali ke aplikasi.</p></div><div class="stp-btns"><button class="btn ghost" data-go="dguru">Data Guru</button><button class="btn ghost" data-go="dsiswa">Data Siswa</button></div></div>
   <div class="step"><span class="stn">3</span><div><b>Unggah rapor PDF</b><p>Buka Buku Induk → pilih siswa → unggah rapor; nilai terekstraksi otomatis kelas 1–6.</p></div><button class="btn ghost" data-go="induk">Buku Induk</button></div>
  </div></div>`;
 return `<div class="page">
  ${head(`${greet}, ${esc2(nm)}`,`${tgl} · Tahun Ajaran <b>${state.ta}</b>`,'')}
  <div class="panel strip mb16">
   ${stat(cn(SISWA.length),'Siswa terdaftar',1)}
   ${stat(cn(GURU.length),'Guru')}
   ${stat(cn(PEGAWAI.length),'Pegawai / staf')}
   ${stat(cn(state.suratAgenda.length),'Surat di agenda')}
   ${stat(cn(rapCount()),'Rapor tersimpan')}
   ${hadir!==null?stat(cn(hadir,1,'','<span class="suf">%</span>'),'Kehadiran guru hari ini'):''}
  </div>
  ${kosong?mulai:`
  <div class="g2">
   <div class="panel"><div class="ph"><span>Surat terakhir di agenda</span><span class="sub">${state.suratAgenda.length} tercatat</span></div>
    ${state.suratAgenda.length?state.suratAgenda.slice(-5).reverse().map(a=>`<div class="ag"><div class="agd"><b>${esc2((a.a||'').slice(0,4))}</b><span>${esc2(a.ta||'')}</span></div><div class="agt"><b>${esc2(a.p)}</b><span>${esc2(a.d)} · ${esc2(a.tgl||'')}</span></div></div>`).join(''):'<p style="padding:14px 16px;font-size:13px;color:var(--tx3)">Belum ada surat tercatat — buka Surat & Arsip untuk mencatat.</p>'}
   </div>
   <div class="panel"><div class="ph"><span>Rapor tersimpan</span><span class="sub">rekaman kelas 1–6</span></div>
    ${(()=>{const recs=[];for(const sp in state.rapor)for(const k in state.rapor[sp])for(const sem in state.rapor[sp][k]){const r=state.rapor[sp][k][sem];const s=SISWA.find(x=>x.sp===sp);if(r)recs.push([s?s.n:sp,'Kelas '+k+' Smt '+sem+(r.tahun?' · TA '+r.tahun:'')]);}
     return recs.length?recs.slice(-5).reverse().map(([n,d])=>`<div class="ag"><div class="agd"><b><i data-lucide="book-open" style="width:15px;height:15px"></i></b></div><div class="agt"><b>${esc2(n)}</b><span>${esc2(d)}</span></div></div>`).join(''):'<p style="padding:14px 16px;font-size:13px;color:var(--tx3)">Belum ada rapor diunggah — unggah lewat Buku Induk.</p>'})()}
   </div>
  </div>`}
  <div class="panel"><div class="pb" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
   <span style="font-weight:700;font-size:13px;margin-right:2px">Pintasan</span>
   <button class="chip" data-go="dsiswa">Data Siswa</button>
   <button class="chip" data-go="dguru">Data Guru</button>
   <button class="chip" data-go="induk">Buku Induk</button>
   <button class="chip" data-go="persuratan">Persuratan</button>
   <button class="chip" data-go="penomoran">Penomoran</button>
   <button class="chip" data-go="klasifikasi">Kode Klasifikasi</button>
   <button class="chip" data-go="sk">SK & Keputusan</button>
   <button class="chip" data-go="arsip">Surat & Arsip</button>
   <span style="margin-left:auto;color:var(--tx3);font-size:12px;display:inline-flex;align-items:center;gap:7px"><i data-lucide="mouse-pointer-click" style="width:13px;height:13px"></i>Tekan Ctrl K untuk lompat cepat</span>
  </div></div>
  <div class="panel"><div class="ph"><span>Tautan Resmi Dinas</span><span class="sub"><i data-lucide="external-link" style="width:12px;height:12px"></i>klik untuk membuka di browser</span></div>
   <div class="pb">${TLINKS_HTML}</div>
  </div>
 </div>`;
},

profil(){
 const L=state.uploads.logo, S=state.sekolah;
 const fldP=(f,label,ph)=>`<div class="fld"><label>${label}</label><input data-prof="${f}" value="${attq(S[f])}" placeholder="${ph}"></div>`;
 const pinsHtml=canEdit()?`
  <div class="panel mb16"><div class="ph"><span>Pengguna & PIN</span><span class="sub"><i data-lucide="shield-check" style="width:12px;height:12px"></i>hanya terlihat Tata Usaha & Kepala Sekolah</span></div>
   <div class="pb">
    ${USERS.map(u=>`<div class="userrow"><span class="ava" style="background:${u.c}1f;color:${u.c};border:1px solid ${u.c}3d">${u.ini}</span><div class="ur-i"><b>${esc2(u.name)}</b><span>${u.role}</span></div><label class="fld" style="margin:0"><input class="mono" data-pinset="${u.id}" value="${attq(state.pins[u.id])}" maxlength="8" placeholder="PIN"></label></div>`).join('')}
    <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn pri" data-pinssave><i data-lucide="save"></i>Simpan PIN</button></div>
    <p style="font-size:12px;color:var(--tx3);line-height:1.5;margin-top:4px"><i data-lucide="info" style="width:12px;height:12px;vertical-align:-2px"></i> Ganti PIN segera setelah petugas lama pindah tugas. PIN baru langsung berlaku.</p>
   </div>
  </div>
  <div class="panel mb16"><div class="ph"><span>Kode Pemulihan</span><span class="sub"><i data-lucide="key-round" style="width:12px;height:12px"></i>penyelamat saat semua PIN terlupa</span></div>
   <div class="pb" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <span class="mono" style="font-size:20px;letter-spacing:.12em;font-weight:700;color:var(--accent)">${state.recovery}</span>
    <button class="chip" data-regen><i data-lucide="refresh-cw" style="width:12px;height:12px"></i>Buat Kode Baru</button>
   </div>
   <p style="font-size:12px;color:var(--tx3);line-height:1.5;margin-top:8px">Simpan kode ini di tempat aman (buku arsip / brankas sekolah). Jika ada petugas pindah tanpa menyerahkan PIN, gunakan kode ini lewat tombol <b>Lupa PIN?</b> di layar masuk untuk menyetel PIN baru.</p>
  </div>`:'';
 return `<div class="page">
  ${head('Profil Sekolah','Identitas resmi satuan pendidikan — sumber data seluruh kop surat, SK, dan tanda tangan.',
   `<button class="btn ghost" data-backup><i data-lucide="download"></i>Ekspor .prima</button><button class="btn ghost" data-restore><i data-lucide="upload"></i>Impor Cadangan</button>`)}
  <div class="g2">
   <div>
    <div class="panel mb16"><div class="ph"><span>Logo Sekolah</span><span class="sub"><i data-lucide="stamp" style="width:12px;height:12px"></i>dipakai pada kop surat, SK & MOU</span></div>
     <div class="pb" style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
      <div class="logobox" data-up="logo|main|logo|image/*" title="Klik untuk mengunggah logo">${L?`<img src="${L.data}" alt="Logo sekolah">`:`<span class="lb-ph"><i data-lucide="image-plus"></i><em>Unggah Logo<br>PNG / JPG</em></span>`}</div>
      <div style="flex:1;min-width:200px">
       <p style="font-size:13px;font-weight:600">${L?esc(L.name):'Belum ada logo terunggah'}</p>
       <p style="font-size:12px;color:var(--tx3);margin-top:3px;line-height:1.5">${L?'Logo akan otomatis muncul di kop setiap surat keterangan, SK, dan MOU yang dicetak.':'Format PNG (disarankan transparan) atau JPG, rasio 1:1.'}</p>
       <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button class="chip ${L?'on':''}" data-up="logo|main|logo|image/*">${L?'Ganti Logo':'Pilih Berkas'}</button>
        ${L?`<button class="chip" data-logodel>Hapus</button>`:''}
       </div>
      </div>
     </div>
    </div>
    <div class="panel mb16"><div class="ph"><span>Identitas Sekolah</span><span class="sub"><i data-lucide="save" style="width:12px;height:12px"></i>tersimpan otomatis saat diketik</span></div>
     <div class="pb">
      <div class="frow2">
       <div class="fld"><label>Jenjang</label><select data-prof="jenjang">${['SD','SMP','SMA','SMK'].map(j=>`<option ${S.jenjang===j?'selected':''}>${j}</option>`).join('')}</select></div>
       <div class="fld"><label>Status</label><select data-prof="status">${['Negeri','Swasta'].map(j=>`<option ${S.status===j?'selected':''}>${j}</option>`).join('')}</select></div>
      </div>
      ${fldP('nama','Nama Sekolah','cth: SD Negeri 1 Ungaran')}
      <div class="frow2">
       ${fldP('pemda','Pemerintah Daerah','cth: Pemerintah Kabupaten Brebes')}
       ${fldP('dinas','Dinas','cth: Dinas Pendidikan')}
      </div>
      <div class="frow2">
       ${fldP('npsn','NPSN','cth: 20312345')}
       ${fldP('nss','NSS','cth: 101032712345')}
      </div>
      <div class="frow2">
       <div class="fld"><label>Akreditasi</label><select data-prof="akreditasi">${['','A','B','C','Belum Akreditasi'].map(j=>`<option ${S.akreditasi===j?'selected':''}>${j||'— pilih —'}</option>`).join('')}</select></div>
       ${fldP('kurikulum','Kurikulum','cth: Kurikulum Merdeka')}
      </div>
      ${fldP('kepsek','Nama Kepala Sekolah (beserta gelar)','cth: Dr. Ratna Widyastuti, M.Pd.')}
      ${fldP('nipKepsek','NIP Kepala Sekolah','cth: 19710408 199803 2 003')}
      ${fldP('alamat','Alamat Sekolah','cth: Jl. Merdeka No. 45, Ungaran')}
      <div class="frow2">
       ${fldP('telp','Telepon','cth: (024) 123-456')}
       ${fldP('email','Email','cth: sekolah@sch.id')}
      </div>
      <div class="frow2">
       ${fldP('kota','Kota / Tempat Penandatanganan','cth: Brebes')}
       <div class="fld"><label>Nominal SPP / bulan (Rp)</label><input data-prof="spp" type="number" min="0" step="5000" value="${S.spp||0}"></div>
      </div>
      <p style="font-size:12px;color:var(--tx3);line-height:1.5"><i data-lucide="info" style="width:12px;height:12px;vertical-align:-2px"></i> Semua isian di atas otomatis dipakai pada kop surat, SK, MOU, tagihan, dan tanda tangan dokumen.</p>
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap"><button class="btn pri" data-profsave><i data-lucide="save"></i>Simpan Profil Sekolah</button></div>
     </div>
    </div>
   </div>
   <div>
    <div class="panel mb16"><div class="ph"><span>Pratinjau Kop Surat</span><span class="sub">mengikuti isian profil</span></div><div class="pb"><div id="kop-prev">${kop()}</div></div></div>
    <div class="panel mb16"><div class="ph"><span>Tahun Ajaran & Penyimpanan</span><span class="sub"><i data-lucide="database" style="width:12px;height:12px"></i>strategi data jangka panjang</span></div>
     <div class="pb">
      <div class="fld"><label>Tahun Ajaran Aktif (2010–2045)</label><select data-prof-ta>${taList().map(t=>`<option ${state.ta===t?'selected':''}>${t}</option>`).join('')}</select></div>
      <div class="kvlist">
       <div class="kv"><span>Pemakaian penyimpanan</span><b class="mono" id="store-kb">…</b></div>
       <div class="kv"><span>Surat di agenda</span><b>${state.suratAgenda.length} catatan</b></div>
       <div class="kv"><span>Rapor tersimpan</span><b>${rapCount()} rekaman</b></div>
       <div class="kv"><span>Cadangan harian otomatis</span><b>${state.lastAutoBackup?('terakhir '+state.lastAutoBackup):'aktif (saat masuk aplikasi)'}</b></div>
      </div>
      <p style="font-size:12px;color:var(--tx3);line-height:1.6;margin-top:6px"><b>Cara sistem menangani data jangka panjang:</b> pilih tahun ajaran aktif (2010–2045) di bilah atas; setiap surat, agenda, dan rapor yang dientri <b>tersimpan sesuai tahun ajaran yang dipilih saat entri</b> dan tidak pernah terhapus otomatis saat ganti tahun. Karena penyimpanan browser terbatas (±5 MB), <b>biasakan ekspor cadangan .prima tiap akhir semester</b> (menu Backup & Pulihkan) lalu simpan di flashdisk/Google Drive sekolah — komputer diinstal ulang pun data bisa dikembalikan.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button class="btn pri" data-backup><i data-lucide="download"></i>Ekspor Cadangan Sekarang</button><button class="btn ghost" data-restore><i data-lucide="upload"></i>Impor Cadangan</button></div>
      <div style="margin-top:14px;border-top:1px dashed var(--line);padding-top:12px">
       <div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b style="font-size:13px"><i data-lucide="history" style="width:14px;height:14px;vertical-align:-2px"></i> Log Aktivitas</b><span style="font-size:11px;color:var(--tx3)">${(state.log||[]).length} kejadian (300 tersimpan)</span></div>
       <div style="max-height:220px;overflow:auto;margin-top:6px">${(state.log||[]).slice(0,40).map(l=>'<div style="display:flex;gap:10px;font-size:12px;padding:5px 2px;border-bottom:1px dashed var(--line)"><span class="mono" style="color:var(--tx3);flex:none">'+fmtLogT(l.t)+'</span><span style="flex:none;color:var(--tx2);max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc2(l.u)+'</span><span>'+esc2(l.a)+'</span></div>').join('')||'<p style="font-size:12px;color:var(--tx3);padding:6px 2px">Belum ada aktivitas tercatat.</p>'}</div>
      </div>
     </div>
    </div>
    ${pinsHtml}
   </div>
  </div>
 </div>`;
},

pegawai(){
 const rows=PEGAWAI.map((p,i)=>`<tr>
  <td><div class="cell-u">${ava(p.n)}<span class="strong">${esc2(p.n)}</span></div></td>
  <td>${esc2(p.j)}</td><td>${esc2(p.u)}</td>
  <td>${p.s==='PNS'?badge('PNS',C.sky):p.s==='PTT'?badge('PTT',C.amber):badge(esc2(p.s),C.grey)}</td>
  <td class="mono">${esc2(p.mk)}</td>
  <td style="text-align:right"><button class="ibtn" data-pegedit="${i}" title="Edit"><i data-lucide="pencil"></i></button> <button class="ibtn" data-pegdel="${i}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`).join('');
 return `<div class="page">
  ${head('Pegawai & Tata Usaha','Tenaga kependidikan — data kosong bawaan, silakan isi sesuai kondisi sekolah.',
   `<button class="btn ghost" data-xltpl="pegawai" title="Unduh template Excel"><i data-lucide="file-down"></i>Template Excel</button><button class="btn ghost" data-xlup="pegawai" title="Impor dari Excel"><i data-lucide="file-up"></i>Impor Excel</button><button class="btn ghost" data-export-x="tb-peg" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn pri" data-pegform><i data-lucide="users"></i>Tambah Pegawai</button>`)}
  ${PEGAWAI.length?tbl('tb-peg',['Nama','Jabatan','Unit','Status','Masa Kerja',''],rows):emptyBox('contact','Belum ada data pegawai','Klik “Tambah Pegawai” untuk mengisi satu per satu, atau “Template Excel” untuk mengisi massal lalu “Impor Excel”.',`<button class="btn pri" data-pegform><i data-lucide="user-plus"></i>Tambah Pegawai</button><button class="btn ghost" data-xltpl="pegawai"><i data-lucide="file-down"></i>Unduh Template Excel</button>`)}
 </div>`;
},

persuratan(){
 const cards=SURAT_JENIS.map(s=>`<button class="ccard" data-surat="${s.id}">
   <span class="cic" style="background:${s.c}1c;color:${s.c};border:1px solid ${s.c}3d"><i data-lucide="${s.icon}"></i></span>
   <span class="cbody"><b>${s.t}</b><p>${s.d}</p><span class="cno">Format nomor ${s.no}/… · klik untuk membuat</span></span>
 </button>`).join('');
 return `<div class="page">
  ${head('Persuratan','Generator surat keterangan resmi — kop sekolah dari profil, nomor otomatis, pratinjau, dan cetak langsung.',badge('7 jenis surat',C.coral))}
  <div class="panel mb16"><div class="pb"><div class="cgrid">${cards}</div></div></div>
  <p style="color:var(--tx3);font-size:12px;display:flex;align-items:center;gap:7px"><i data-lucide="info" style="width:13px;height:13px"></i>Logo & identitas kop surat mengikuti halaman <button class="chip" data-go="profil">Profil Sekolah</button>.</p>
  <p style="color:var(--tx3);font-size:12px;display:flex;align-items:center;gap:7px;margin-top:7px;flex-wrap:wrap"><i data-lucide="hash" style="width:13px;height:13px"></i>Butuh nomor format B/000.5.3.4/0007/VI/2026? Buka <button class="chip" data-go="penomoran">Penomoran Naskah Dinas</button> dan cari kodenya di <button class="chip" data-go="klasifikasi">Kode Klasifikasi Arsip</button>.</p>
 </div>`;
},

sk(){
 const cards=SKD.map(s=>`<button class="ccard" data-sk="${s.id}">
   <span class="cic" style="background:${s.c}1c;color:${s.c};border:1px solid ${s.c}3d"><i data-lucide="${s.icon}"></i></span>
   <span class="cbody"><b>${s.t}</b><p>${s.tentang}</p><span class="cno">Format nomor ${s.kode}/… · pratinjau & cetak</span></span>
 </button>`).join('');
 return `<div class="page">
  ${head('SK & Keputusan','Bank template Surat Keputusan resmi — nama sekolah & tanda tangan mengikuti profil sekolah.',badge('13 template SK',C.gold))}
  <div class="panel"><div class="pb"><div class="cgrid">${cards}</div></div></div>
 </div>`;
},

mou(){
 const rows=MOUD.map(m=>`<tr class="rowc" data-mou="${m.id}">
  <td><div class="cell-u"><span class="cic" style="width:30px;height:30px;border-radius:9px;display:grid;place-items:center;background:${m.c}1c;color:${m.c};flex:none"><i data-lucide="handshake" style="width:14px;height:14px"></i></span><span class="strong">${esc2(m.mitra)}</span></div></td>
  <td>${esc2(m.bidang)}</td><td class="mono">${esc2(m.no)}</td><td class="mono">${esc2(m.mulai)} — ${esc2(m.akhir)}</td>
  <td>${m.st==='Aktif'?badge('Aktif',C.green):badge(esc2(m.st),C.amber)}</td>
  <td style="text-align:right"><button class="ibtn" data-mouedit="${m.id}" title="Edit"><i data-lucide="pencil"></i></button> <button class="ibtn" data-moudel="${m.id}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`).join('');
 return `<div class="page">
  ${head('MOU & Kerja Sama','Nota kesepahaman sekolah dengan mitra eksternal — pratinjau dokumen lengkap dengan pasal dan tanda tangan dua pihak.',
   `<button class="btn pri" data-mouform><i data-lucide="handshake"></i>MOU Baru</button>`)}
  ${MOUD.length?tbl('tb-mou',['Mitra','Bidang Kerja Sama','Nomor','Masa Berlaku','Status',''],rows):emptyBox('handshake','Belum ada MOU tercatat','Klik “MOU Baru” untuk mencatat kerja sama sekolah dengan mitra.',`<button class="btn pri" data-mouform><i data-lucide="handshake"></i>MOU Baru</button>`)}
 </div>`;
},

arsip(){
 const tas=[...new Set(state.suratAgenda.map(a=>a.ta).filter(Boolean))].sort().reverse();
 const tanpaTa=state.suratAgenda.some(a=>!a.ta);
 let rows='';
 const barisGrup=list=>list.map((s)=>{const i=state.suratAgenda.indexOf(s);return `<tr class="frow" data-fval="${s.t}" data-jenis="${s.t}" data-ta="${s.ta||''}">
  <td class="mono">${esc2(s.a)}</td><td class="strong">${esc2(s.p)}</td><td>${esc2(s.d)}</td>
  <td>${s.t}</td><td class="mono">${esc2(s.ta||'')}</td>
  <td>${s.s==='Tindak Lanjut'?badge(s.s,C.amber):s.s==='Selesai'?badge(s.s,C.green):badge(s.s,C.sky)}</td>
  <td style="text-align:right"><button class="ibtn" data-smedit="${i}" title="Edit"><i data-lucide="pencil"></i></button> <button class="ibtn" data-dispo="${i}" title="Cetak disposisi"><i data-lucide="printer"></i></button> <button class="ibtn" data-smdel="${i}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`;}).join('');
 for(const ta of tas){
  const grup=state.suratAgenda.filter(a=>a.ta===ta);
  rows+=`<tr class="tahead" data-ta="${esc2(ta)}"><td colspan="7"><i data-lucide="calendar-days" style="width:12px;height:12px;vertical-align:-2px"></i> Tahun Ajaran ${esc2(ta)} — ${grup.length} surat</td></tr>`;
  rows+=barisGrup(grup);
 }
 if(tanpaTa){rows+=`<tr class="tahead" data-ta=""><td colspan="7">Tanpa label tahun ajaran — ${state.suratAgenda.filter(a=>!a.ta).length} surat</td></tr>`;rows+=barisGrup(state.suratAgenda.filter(a=>!a.ta));}
 return `<div class="page">
  ${head('Surat & Arsip','Agenda surat masuk & keluar terindeks kode klasifikasi Perbup — disposisi sekali klik. Arsip lintas tahun ajaran tetap tersimpan.',
   `${srch('tb-surat','Cari perihal, asal, atau nomor…')}<select id="arsip-ta" class="taf"><option value="">Semua TA</option>${tas.map(t=>`<option ${state.ta===t?'selected':''}>${t}</option>`).join('')}</select><button class="btn ghost" data-export-x="tb-surat" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-export-p="tb-surat|Agenda Surat" title="Ekspor PDF"><i data-lucide="file-text"></i>PDF</button><button class="btn pri" data-smform><i data-lucide="mail-plus"></i>Catat Surat</button>`)}
  <div class="tools">${chipsRow('tb-surat',[['','Semua'],['Masuk','Surat Masuk'],['Keluar','Surat Keluar']])}</div>
  ${state.suratAgenda.length?tbl('tb-surat',['No. Agenda','Perihal','Asal / Tujuan','Jenis','TA','Status',''],rows):emptyBox('archive','Agenda surat masih kosong','Klik “Catat Surat” untuk mencatat surat masuk atau keluar. Setiap catatan diberi label tahun ajaran '+state.ta+'.',`<button class="btn pri" data-smform><i data-lucide="mail-plus"></i>Catat Surat</button>`)}
 </div>`;
},

backup(){
 const lb=state.lastBackup?new Date(state.lastBackup).toLocaleString('id-ID',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}):'belum pernah';
 const fsInfo=window.__PRIMA_FS_INFO;
 const lokasi=fsInfo?esc2(fsInfo.file)+' — <b style="color:var(--accent)">tersimpan otomatis setiap perubahan</b>':'Browser ini (localStorage) — jalankan aplikasi .exe agar otomatis tersimpan ke folder D:\\PRIMA';
 return `<div class="page">
  ${head('Backup & Pulihkan','Data sekolah adalah aset jangka panjang — selain tersimpan otomatis, unduh juga cadangannya ke flashdisk / Google Drive.',badge('Tahun ajaran 2010–2045',C.green))}
  <div class="panel mb16"><div class="ph"><span>Lokasi Penyimpanan Data</span><span class="sub"><i data-lucide="hard-drive" style="width:12px;height:12px"></i>${fsInfo?'aplikasi desktop aktif':'mode browser'}</span></div>
   <div class="pb">
    <div class="kvlist">
     <div class="kv"><span>File data</span><b class="mono" style="font-size:12px;text-align:right">${lokasi}</b></div>
     <div class="kv"><span>Ukuran data saat ini</span><b class="mono" id="bk-size">…</b></div>
     <div class="kv"><span>Cadangan .prima terakhir</span><b>${lb}</b></div>
     <div class="kv"><span>Cadangan harian otomatis</span><b>${state.lastAutoBackup||'aktif — tersimpan saat masuk'}</b></div>
    </div>
    <p style="font-size:12px;color:var(--tx3);line-height:1.6;margin-top:8px">${fsInfo?'Folder dibuat otomatis oleh aplikasi. Komputer diinstal ulang pun, selama folder ini ikut tercadangkan (atau berkas .prima tersimpan), data bisa dikembalikan.':'Saat dijalankan lewat aplikasi .exe, folder <b>D:\\PRIMA</b> dibuat otomatis dan seluruh data tersimpan di sana tanpa perlu diklik.'}</p>
   </div>
  </div>
  <div class="g2">
   <div class="panel"><div class="ph"><span>Ekspor Cadangan</span><span class="sub"><i data-lucide="download" style="width:12px;height:12px"></i>unduh seluruh data</span></div>
    <div class="pb">
     <p style="font-size:12.5px;color:var(--tx2);line-height:1.6">Satu berkas <b>.prima</b> berisi seluruh data aplikasi: profil sekolah, guru, siswa, rapor & berkas, surat & agenda, SK, MOU, PIN, dan tahun ajaran.</p>
     <div class="kvlist" style="margin:12px 0">
      <div class="kv"><span>Cadangan terakhir</span><b>${lb}</b></div>
      <div class="kv"><span>Ukuran data saat ini</span><b class="mono" id="bk-size">…</b></div>
     </div>
     <button class="btn pri" data-backup><i data-lucide="download"></i>Unduh Cadangan (.prima)</button>
     <p style="font-size:12px;color:var(--tx3);line-height:1.6;margin-top:10px"><b>Anjuran:</b> lakukan setiap akhir semester dan setiap selesai input data besar (PPDB / rapor). Simpan minimal 2 rangkap di tempat berbeda.</p>
    </div>
   </div>
   <div class="panel"><div class="ph"><span>Pulihkan dari Cadangan</span><span class="sub"><i data-lucide="upload" style="width:12px;height:12px"></i>ganti komputer / instal ulang</span></div>
    <div class="pb">
     <p style="font-size:12.5px;color:var(--tx2);line-height:1.6">Pilih berkas <b>.prima</b> yang pernah diunduh. Seluruh data di komputer ini akan <b>digantikan</b> oleh isi cadangan — komputer diinstal ulang, ganti komputer, atau pindah ke aplikasi baru, data kembali utuh seperti semula.</p>
     <button class="btn ghost" data-restore style="margin-top:12px"><i data-lucide="upload"></i>Pilih Berkas Cadangan</button>
     <p style="font-size:12px;color:var(--tx3);line-height:1.6;margin-top:10px"><i data-lucide="info" style="width:12px;height:12px;vertical-align:-2px"></i> Bila komputer ini masih ada datanya, unduh dulu cadangannya sebelum memulihkan berkas lama.</p>
    </div>
   </div>
  </div>
  <div class="panel mb16"><div class="ph"><span>Enkripsi Data (Opsional)</span><span class="sub">${(window.__PRIMA_FS_INFO&&window.__PRIMA_FS_INFO.encrypted)?badge('AKTIF — berkas tersamar',C.green):badge('NONAKTIF',C.amber)}</span></div>
   <div class="pb">
    <p style="font-size:12.5px;color:var(--tx2);line-height:1.6">Bila diaktifkan, berkas <b>D:\\PRIMA\\prima-data.json</b> disandikan (AES-256) sehingga tidak bisa dibaca siapa pun tanpa frasa sandi — aman bila laptop dibawa bepergian atau dicuri. Frasa sandi cukup diketik saat aplikasi dibuka (atau diingat aman oleh sistem operasi komputer ini).</p>
    <div class="frow2" style="margin-top:8px">
     <div class="fld"><label>Frasa sandi (min. 6 karakter)</label><input id="enc-pass" type="password" placeholder="cth: kopi-manis-2026"></div>
     <div class="fld"><label>Ulangi frasa sandi</label><input id="enc-pass2" type="password"></div>
    </div>
    <label style="display:flex;gap:8px;align-items:center;margin:8px 2px;font-size:12.5px;color:var(--tx2)"><input type="checkbox" id="enc-remember"> Ingat frasa sandi di komputer ini (tanpa mengetik tiap buka)</label>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button class="btn pri" data-encon><i data-lucide="shield-check"></i>Aktifkan Enkripsi</button><button class="btn ghost" data-encoff><i data-lucide="lock-open"></i>Matikan Enkripsi</button></div>
   </div>
  </div>
  <div class="panel mb16"><div class="ph"><span>Log Aktivitas & Cadangan Harian</span><span class="sub">${(state.log||[]).length} kejadian (300 tersimpan) · cadangan harian: ${state.lastAutoBackup||'aktif'}</span></div>
   <div class="pb" style="max-height:260px;overflow:auto">${(state.log||[]).slice(0,50).map(l=>'<div style="display:flex;gap:10px;font-size:12px;padding:5px 2px;border-bottom:1px dashed var(--line)"><span class="mono" style="color:var(--tx3);flex:none">'+fmtLogT(l.t)+'</span><span style="flex:none;color:var(--tx2);max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc2(l.u)+'</span><span>'+esc2(l.a)+'</span></div>').join('')||'<p style="font-size:12px;color:var(--tx3)">Belum ada aktivitas tercatat — log diisi otomatis saat masuk, impor, kirim WA, dan pencadangan.</p>'}</div>
  </div>
  <div class="panel mb16"><div class="ph"><span>Bagaimana data disimpan lintas tahun</span></div>
   <div class="pb" style="font-size:12.5px;color:var(--tx2);line-height:1.7">
    <p>• Pilih <b>Tahun Ajaran Aktif</b> di bilah atas (rentang 2010/2011 s.d. 2045/2046). Semua entri — surat, agenda, rapor — <b>tersimpan dengan label tahun ajaran yang dipilih saat entri</b> (mis. entri saat TA 2010/2011 tercatat di 2010/2011) dan tidak pernah dihapus otomatis.</p>
    <p style="margin-top:5px">• Data tahun-tahun lama dapat dilihat kapan saja lewat saringan TA di halaman Surat & Arsip, dan rapor lama tetap tampil di Buku Induk siswa.</p>
    <p style="margin-top:5px">• Penyimpanan berada di browser komputer ini (±5 MB). Jika penyimpanan hampir penuh, aplikasi otomatis mengingatkan untuk membuat cadangan.</p>
   </div>
  </div>
  <div class="panel"><div class="ph"><span>Reset Aplikasi</span><span class="sub"><i data-lucide="alert-triangle" style="width:12px;height:12px"></i>berbahaya</span></div>
   <div class="pb" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
    <p style="font-size:12.5px;color:var(--tx2);line-height:1.6;flex:1;min-width:240px">Menghapus seluruh data di browser ini dan kembali ke kondisi kosong. Pastikan cadangan .prima sudah diunduh sebelum melakukan reset.</p>
    <button class="btn ghost" data-reset><i data-lucide="trash-2"></i>Hapus Semua Data</button>
   </div>
  </div>
 </div>`;
},

penomoran(){
 const n=state.naskah;
 const amanSel=KEAMANAN.map(([k,l])=>`<option value="${k}" ${k===n.aman?'selected':''}>${k} — ${l}</option>`).join('');
 const bulanSel=ROMAWI.map((r,i)=>`<option value="${i}" ${i===n.bulan?'selected':''}>${r} — ${BULAN[i]}</option>`).join('');
 return `<div class="page">
  ${head('Penomoran Naskah Dinas','Susun nomor sesuai tata naskah dinas: keamanan / kode klasifikasi / nomor urut / bulan romawi / tahun.',badge('Format: B/000.5.3.4/0007/VI/'+n.tahun,C.gold))}
  <div class="g2">
   <div class="panel">
    <div class="ph"><span>Susun Nomor</span><span class="sub"><i data-lucide="hash" style="width:12px;height:12px"></i>kode klasifikasi mengikuti Perbup No. 8/2023</span></div>
    <div class="pb">
     <div class="frow2">
      <div class="fld"><label>Kode Keamanan</label><select id="f-aman">${amanSel}</select></div>
      <div class="fld"><label>Nomor Urut Naskah</label><input id="f-urut" type="number" min="1" max="9999" value="${n.urut}"></div>
     </div>
     <div class="fld"><label>Kode Klasifikasi — cari atau gulir</label>
      <input id="f-kode-search" placeholder="Ketik kata kunci, cth: kearsipan, perpustakaan, pendidikan…" value="${n.kode}">
      <div class="kpick-list" id="kpick-list"></div>
      <div class="ksel" id="kode-sel"></div>
     </div>
     <div class="frow2">
      <div class="fld"><label>Bulan Terbit</label><select id="f-bulan">${bulanSel}</select></div>
      <div class="fld"><label>Tahun</label><input id="f-tahun" maxlength="4" value="${n.tahun}"></div>
     </div>
     <div class="fld"><label>Perihal (buku agenda)</label><input id="f-perihal" placeholder="cth: laporan kegiatan literasi semester ganjil"></div>
     <div style="display:flex;gap:9px;flex-wrap:wrap">
      <button class="btn pri" data-catatno><i data-lucide="book-plus"></i>Catat ke Buku Agenda</button>
      <button class="btn ghost" data-copyno><i data-lucide="copy"></i>Salin Nomor</button>
     </div>
    </div>
   </div>
   <div class="panel">
    <div class="noprev"><div class="big" id="nomor-prev"></div><div class="cap">Nomor naskah dinas</div></div>
    <div id="nomor-seg"></div>
   </div>
  </div>
  <div class="panel">
   <div class="ph"><span>Buku Agenda Naskah Dinas</span><span class="sub"><span id="ag-cnt">${n.agenda.length}</span> tercatat · terbaru di atas</span></div>
   <div class="twrap"><table class="tbl"><thead><tr><th>Nomor</th><th>Perihal</th><th>Keamanan</th><th>Tanggal</th><th></th></tr></thead><tbody id="tb-naskah"></tbody></table></div>
  </div>
 </div>`;
},

klasifikasi(){
 const rows=KLASIFIKASI.map(([k,u])=>{const lv=k.split('.').length-1;
  return `<div class="frow krow lv${lv}" data-fval="${k.split('.')[0]}" data-kcopy="${k}" style="--lv:${lv}"><span class="kno">${k}</span><span class="kur">${esc2(u)}</span></div>`;}).join('');
 return `<div class="page">
  ${head('Kode Klasifikasi Arsip',`${KLASIFIKASI_META.dasar} tentang ${KLASIFIKASI_META.judul} — gulir daftar atau ketik untuk mencari.`,badge(KLASIFIKASI.length+' kode',C.lilac))}
  <div class="tools">${srch('tb-klas','Cari kode atau uraian… cth: perpustakaan')}${chipsRow('tb-klas',[['','Semua'],...KLASIFIKASI_META.kelompok.map(t=>[t,t])])}<span id="tb-klas-cnt"></span></div>
  <div class="panel"><div class="klist" id="tb-klas">${rows}</div>
   <div class="kfoot"><i data-lucide="mouse-pointer-click" style="width:13px;height:13px"></i>Klik baris untuk menyalin kode · ditandatangani ${KLASIFIKASI_META.penandatangan}</div>
  </div>
 </div>`;
},

dguru(){
 const rows=GURU.map(g=>`<tr class="frow">
  <td><div class="cell-u">${upThumb('guru',g.nip,g.n)}<span class="strong">${esc2(g.n)}</span></div></td>
  <td class="mono">${esc2(g.nip)}</td><td>${esc2(g.m)}</td>
  <td>${g.s==='PNS'?badge('PNS',C.sky):badge(esc2(g.s),C.amber)}</td>
  <td><div style="display:flex;gap:9px;align-items:center"><div class="bar" style="width:64px"><i style="width:${Math.min(100,+g.skp||0)}%"></i></div><span class="mono">${g.skp||'—'}</span></div></td>
  <td style="text-align:right"><button class="ibtn" data-guruedit="${attq(g.nip)}" title="Edit"><i data-lucide="pencil"></i></button> <button class="ibtn" data-gurudel="${attq(g.nip)}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`).join('');
 return `<div class="page">
  ${head('Data Guru','Data induk tenaga pendidik — unduh template Excel, isi, lalu unggah kembali.',
   `${srch('tb-guru','Cari nama atau mapel…')}<button class="btn ghost" data-xltpl="guru" title="Unduh template Excel"><i data-lucide="file-down"></i>Template Excel</button><button class="btn ghost" data-xlup="guru" title="Impor dari Excel"><i data-lucide="file-up"></i>Impor Excel</button><button class="btn ghost" data-export-x="tb-guru" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Ekspor</button><button class="btn pri" data-guruform><i data-lucide="user-plus"></i>Tambah Guru</button>`)}
  ${GURU.length?tbl('tb-guru',['Nama','NIP / NUPTK','Mata Pelajaran','Status','SKP',''],rows):emptyBox('users','Belum ada data guru','Unduh “Template Excel”, isi daftar guru di Excel, lalu klik “Impor Excel”. Bisa juga tambah satu per satu.',`<button class="btn ghost" data-xltpl="guru"><i data-lucide="file-down"></i>Unduh Template Excel</button><button class="btn pri" data-xlup="guru"><i data-lucide="file-up"></i>Impor Excel</button>`)}
 </div>`;
},

dgurudok(){
 const rows=GURU.map(g=>{const U=state.uploads.guru[g.nip]||{};
  const done=['foto','skCpns','skTerakhir'].filter(f=>U[f]).length;
  return `<tr class="frow rowc" data-gshow="${attq(g.nip)}">
  <td><div class="cell-u">${upThumb('guru',g.nip,g.n)}<div><span class="strong" style="display:block">${esc2(g.n)}</span><span class="mono" style="font-size:11px;color:var(--tx3)">${esc2(g.nip)}</span></div></div></td>
  <td>${esc2(g.m)} · ${badge(esc2(g.s),g.s==='PNS'?C.sky:C.amber)}</td>
  <td><div class="upset">${upBadge('guru',g.nip,'foto','Foto')}${upBadge('guru',g.nip,'skCpns','SK CPNS/PPPK')}${upBadge('guru',g.nip,'skTerakhir','SK Terakhir')}</div></td>
  <td style="text-align:right">${done===3?badge('Lengkap',C.green):badge(done+'/3',C.amber)} <button class="ibtn" style="display:inline-grid;vertical-align:middle"><i data-lucide="folder-open"></i></button></td></tr>`;}).join('');
 return `<div class="page">
  ${head('Dokumen Guru','Kelengkapan berkas digital: foto, SK CPNS/PPPK, dan SK terakhir — klik baris untuk mengelola.',
   srch('tb-gdok','Cari guru…'))}
  ${GURU.length?tbl('tb-gdok',['Guru','Mapel · Status','Dokumen','Kelengkapan'],rows):emptyBox('folder-open','Belum ada guru','Isi Data Guru terlebih dahulu (impor Excel atau tambah manual).',`<button class="btn pri" data-go="dguru"><i data-lucide="users"></i>Ke Data Guru</button>`)}
 </div>`;
},

aguru(){
 const rows=GURU.map((g,i)=>`<div class="srow" style="padding-top:9px;padding-bottom:9px">
  <div class="cell-u" style="width:230px;flex:none">${ava(g.n)}<div><b class="strong" style="font-size:13px;display:block">${esc2(g.n)}</b><span style="font-size:11.5px;color:var(--tx3)">${esc2(g.m)}</span></div></div>
  <span style="color:var(--tx3);font-size:12px;display:inline-flex;align-items:center;gap:6px"><i data-lucide="mouse-pointer-click" style="width:13px;height:13px"></i>klik status untuk mengubah</span>
  <span style="margin-left:auto" id="ab-${i}">${badgeBtn(state.abs[i]||'Hadir',i)}</span></div>`).join('');
 return `<div class="page">
  ${head('Absensi Guru','Rekap kehadiran mengajar hari ini.')}
  ${GURU.length?`
  <div class="panel cnt mb16">
   <span class="cnt-item"><span class="cdot" style="background:${C.green}"></span><b id="ac-Hadir">0</b><span class="clbl">Hadir</span></span>
   <span class="cnt-item"><span class="cdot" style="background:${C.amber}"></span><b id="ac-Izin">0</b><span class="clbl">Izin</span></span>
   <span class="cnt-item"><span class="cdot" style="background:${C.coral}"></span><b id="ac-Sakit">0</b><span class="clbl">Sakit</span></span>
   <span class="cnt-item"><span class="cdot" style="background:${C.rose}"></span><b id="ac-Alfa">0</b><span class="clbl">Alfa</span></span>
  </div>
  <div class="panel">${rows}</div>`:emptyBox('user-check','Belum ada guru','Isi Data Guru terlebih dahulu agar absensi dapat dicatat.',`<button class="btn pri" data-go="dguru"><i data-lucide="users"></i>Ke Data Guru</button>`)}
 </div>`;
},

jadwal(){
 const rows=JADWAL.map(j=>`<tr class="frow" data-fval="${j.h}">
  <td class="strong">${esc2(j.h)}</td><td class="mono">${esc2(j.j)}</td><td>${esc2(j.k)}</td><td>${esc2(j.m)}</td><td>${esc2(j.g)}</td></tr>`).join('');
 return `<div class="page">
  ${head('Jadwal Mengajar','Jadwal minggu berjalan.',
   `<button class="btn ghost" data-export-x="tb-jadwal" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-export-p="tb-jadwal|Jadwal Mengajar" title="Ekspor PDF"><i data-lucide="file-text"></i>PDF</button>`)}
  ${JADWAL.length?`<div class="tools">${chipsRow('tb-jadwal',[['','Semua'],['Senin','Senin'],['Selasa','Selasa'],['Rabu','Rabu'],['Kamis','Kamis'],['Jumat','Jumat']])}</div>
  ${tbl('tb-jadwal',['Hari','Jam','Kelas','Mata Pelajaran','Guru'],rows)}`:emptyBox('calendar-days','Jadwal belum diisi','Modul pelengkap — jadwal mengajar dapat dikelola pada versi berikutnya.')}
 </div>`;
},

kinerja(){
 const pred=s=>s>=90?badge('Sangat Baik',C.green):s>=85?badge('Baik',C.sky):badge('Cukup',C.amber);
 const rows=[...GURU].sort((a,b)=>(b.skp||0)-(a.skp||0)).map(g=>`<tr>
  <td><div class="cell-u">${ava(g.n)}<span class="strong">${esc2(g.n)}</span></div></td>
  <td>${esc2(g.m)}</td><td class="num" style="color:var(--tx)">${g.skp||'—'}</td>
  <td><div class="bar" style="width:130px"><i style="width:${Math.min(100,+g.skp||0)}%"></i></div></td>
  <td>${g.skp?pred(+g.skp):badge('Belum dinilai',C.grey)}</td></tr>`).join('');
 return `<div class="page">
  ${head('Kinerja & Penilaian','Skor SKP gabungan semester berjalan.',
   `<button class="btn ghost" data-export-x="tb-kin" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-export-p="tb-kin|Kinerja Guru" title="Ekspor PDF"><i data-lucide="file-text"></i>PDF</button>`)}
  ${GURU.length?tbl('tb-kin',['Nama','Mapel','Skor','Capaian','Predikat'],rows):emptyBox('gauge','Belum ada guru','Isi Data Guru terlebih dahulu; skor SKP diisi saat menambah/mengedit guru.')}
 </div>`;
},

pangkat(){
 const rows=PANGKAT.map(p=>`<tr>
  <td><div class="cell-u">${ava(p.n)}<span class="strong">${esc2(p.n)}</span></div></td>
  <td class="mono">${esc2(p.g)}</td><td class="mono" style="color:var(--accent)">${esc2(p.t)}</td><td>${esc2(p.y)}</td>
  <td>${p.s==='Proses Verifikasi'?badge(p.s,C.amber):p.s==='Berkas Disiapkan'?badge(p.s,C.sky):p.s==='Diajukan ke SimPEG'?badge(p.s,C.green):badge(esc2(p.s),C.grey)}</td></tr>`).join('');
 return `<div class="page">
  ${head('Kenaikan Pangkat','Pelaporan kenaikan pangkat guru.',
   `<button class="btn ghost" data-export-x="tb-pkt" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-export-p="tb-pkt|Kenaikan Pangkat" title="Ekspor PDF"><i data-lucide="file-text"></i>PDF</button><button class="btn pri" data-ajukan><i data-lucide="trending-up"></i>Ajukan Berkas</button>`)}
  ${PANGKAT.length?tbl('tb-pkt',['Nama','Golongan','Target','Perkiraan','Status'],rows):emptyBox('trending-up','Belum ada usulan kenaikan pangkat','Usulan dapat diajukan setelah data guru terisi.')}
 </div>`;
},

dsiswa(){
 const list=siswaTA();
 const kelas=[...new Set(list.map(s=>classForYear(s,state.ta)))];
 const angkatan=[...new Set(list.map(s=>s.masuk||state.ta))].sort().reverse();
 let rows='';
 for(const ang of angkatan){
  const grup=list.filter(s=>(s.masuk||state.ta)===ang);
  rows+=`<tr class="anghead" data-ang="${esc2(ang)}"><td colspan="6"><i data-lucide="layers" style="width:12px;height:12px;vertical-align:-2px"></i> Angkatan TA ${esc2(ang)} — ${grup.length} siswa</td></tr>`;
  rows+=grup.map(s=>{const p=state.spp[s.sp]||{l:false};
   return `<tr class="frow" data-fval="${classForYear(s,state.ta)}">
  <td><div class="cell-u">${upThumb('siswa',s.sp,s.n)}<span class="strong">${esc2(s.n)}</span>${s.mutasi&&s.mutasi.jenis?' '+badge('Mutasi '+s.mutasi.jenis,C.amber):''}</div></td>
  <td class="mono">${esc2(s.nis)}</td><td>${esc2(classForYear(s,state.ta))}</td><td>${esc2(s.jk)}</td>
  <td>${p.l?badge('Lunas',C.green):badge('Belum',C.grey)}</td>
  <td style="text-align:right"><button class="ibtn" data-siswaedit="${s.sp}" title="Edit"><i data-lucide="pencil"></i></button> <button class="ibtn" data-siswadel="${s.sp}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`;}).join('');
 }
 return `<div class="page">
  ${head('Data Siswa','Data peserta didik pada TA aktif '+state.ta+' — dikelompokkan per angkatan. Tahun ajaran yang belum diisi tampil kosong.',
   `${srch('tb-sis','Cari nama atau NIS…')}<button class="btn ghost" data-go="induk"><i data-lucide="book-marked"></i>Buku Induk</button><button class="btn ghost" data-xltpl="siswa" title="Unduh template Excel"><i data-lucide="file-down"></i>Template Excel</button><button class="btn ghost" data-xlup="siswa" title="Impor dari Excel"><i data-lucide="file-up"></i>Impor Excel</button><button class="btn ghost" data-export-x="tb-sis" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Ekspor</button><button class="btn dng" data-delkelas title="Hapus semua siswa dalam satu kelas sekaligus"><i data-lucide="trash-2"></i>Hapus per Kelas</button><button class="btn pri" data-siswaform><i data-lucide="user-plus"></i>Tambah Siswa</button>`)}
  ${list.length?`<div class="tools">${chipsRow('tb-sis',[['','Semua'],...kelas.map(k=>[k,k])])}</div>
  ${tbl('tb-sis',['Nama','NIS','Kelas','L/P','SPP',''],rows)}`:emptyBox('users','Belum ada data siswa pada TA '+state.ta,'Pilih tahun ajaran aktif di bilah atas untuk melihat data tahun lain. Unduh “Template Excel”, isi, lalu “Impor Excel” untuk mengisi tahun ini.',`<button class="btn ghost" data-xltpl="siswa"><i data-lucide="file-down"></i>Unduh Template Excel</button><button class="btn pri" data-xlup="siswa"><i data-lucide="file-up"></i>Impor Excel</button>`)}
 </div>`;
},

induk(){
 const list=siswaTA();
 const complete=list.filter(s=>{const U=state.uploads.siswa[s.sp]||{};return U.foto&&U.kk&&U.akte;}).length;
 const rows=list.map(s=>`<tr class="frow rowc" data-sdet="${s.sp}">
  <td class="mono">${esc2(s.nis)}</td>
  <td><div class="cell-u">${upThumb('siswa',s.sp,s.n)}<div><span class="strong" style="display:block">${esc2(s.n)}</span><span style="font-size:11px;color:var(--tx3)">${esc2(s.ttl)}</span></div></div></td>
  <td>${esc2(s.ib)}</td><td class="mono" style="font-size:11px">${esc2(s.asal)}</td>
  <td><div class="upset">${upBadge('siswa',s.sp,'foto','Foto')}${upBadge('siswa',s.sp,'kk','KK')}${upBadge('siswa',s.sp,'akte','Akte')}</div></td>
  <td><div class="upset">${upBadge('siswa',s.sp,'rapor','Unggah Rapor (PDF)')}${canEdit()&&state.rapor[s.sp]&&Object.keys(state.rapor[s.sp]).length?`<button class="chip rapwipe" data-rapwipes="${s.sp}" title="Hapus semua rekaman rapor siswa ini"><i data-lucide="trash-2" style="width:11px;height:11px"></i>Hapus Rapor</button>`:''}</div></td>
  <td style="text-align:right"><button class="ibtn" data-siswaedit="${s.sp}" title="Edit data"><i data-lucide="pencil"></i></button> <button class="ibtn" style="display:inline-grid"><i data-lucide="folder-open"></i></button></td></tr>`).join('');
 return `<div class="page">
  ${head('Buku Induk Siswa','Lembar induk digital TA '+state.ta+' — klik nama siswa untuk membuka lembar & cetak. Tahun ajaran lain yang belum diisi tampil kosong.',
   `${srch('tb-induk','Cari nama atau NIS…')}<button class="btn ghost" data-jilid><i data-lucide="printer"></i>Cetak Jilid</button>`)}
  <div class="panel rapup mb16"><div class="ph"><span>Unggah Rapor (PDF) — TA ${state.ta}</span><span class="sub"><i data-lucide="scan-line" style="width:12px;height:12px"></i>kelas, semester & nama siswa terbaca otomatis dari berkas</span></div>
   <div class="pb" style="display:flex;gap:11px;align-items:flex-end;flex-wrap:wrap">
    <div class="fld" style="flex:1;min-width:250px;margin:0"><label>Peserta didik TA ${state.ta} — biarkan “Otomatis” agar sistem mencocokkan nama pada PDF</label>
     <select id="rg-sub"><option value="auto">Otomatis — cocokkan nama dari PDF rapor</option>${list.map(s=>`<option value="${s.sp}">${esc2(s.n)} — ${esc2(classForYear(s,state.ta))} · NIS ${esc2(s.nis)}</option>`).join('')}</select>
    </div>
    <button class="btn pri" data-rapup><i data-lucide="file-up"></i>Pilih Berkas Rapor (PDF)</button>
   </div>
   <p style="font-size:12px;color:var(--tx3);margin-top:9px;line-height:1.6">Nilai tersimpan ke rekaman berkelanjutan kelas 1–6 milik siswa yang cocok dengan label TA ${state.ta}; berkas PDF aslinya ikut tersimpan dan dapat dicetak persis dari lembar siswa. Bisa juga lewat tombol “Rapor” pada tabel di bawah.</p>
  </div>
  <div class="panel mb16"><div class="ph"><span>Ijazah Kelas 6 / Lulusan (PDF)</span><span class="sub"><i data-lucide="graduation-cap" style="width:12px;height:12px"></i>bisa pilih LEBIH DARI SATU berkas sekaligus — nama dibaca otomatis</span></div>
   <div class="pb" style="display:flex;gap:11px;align-items:flex-end;flex-wrap:wrap">
    <div class="fld" style="flex:1;min-width:250px;margin:0"><label>Peserta didik — biarkan “Otomatis” agar sistem membaca nama pada PDF</label>
     <select id="ij-sub"><option value="auto">Otomatis — cocokkan nama dari PDF ijazah</option>${list.filter(isK6).map(s=>`<option value="${s.sp}">${esc2(s.n)} — ${esc2(classForYear(s,state.ta))} · NIS ${esc2(s.nis)}</option>`).join('')}</select>
    </div>
    <button class="btn pri" data-ijup><i data-lucide="files"></i>Pilih Berkas Ijazah (bisa banyak)</button>
   </div>
   <p style="font-size:12px;color:var(--tx3);margin-top:9px;line-height:1.6">Satu PDF berisi satu murid, atau banyak PDF sekaligus (satu per murid) — semuanya ditempelkan ke siswa sesuai nama. Hasil “Cetak Ijazah Asli” pada lembar siswa identik dengan PDF yang diunggah. ${list.filter(isK6).length?list.filter(isK6).length+' siswa kelas 6 / lulus pada TA '+state.ta+'.':'Belum ada siswa kelas 6 / lulus pada TA '+state.ta+' — panel tetap menerima unggahan per siswa dari lembar siswa.'}</p>
  </div>
  <div class="panel strip mb16">
   ${stat(cn(list.length),'Siswa pada TA '+state.ta,1)}
   ${stat(`<span style="color:${C.green}">${cn(complete)}</span>`,'Dokumen lengkap')}
   ${stat(cn(Math.max(0,list.length-complete)),'Menunggu dilengkapi')}
   ${stat(cn(rapCount()),'Rapor tersimpan')}
  </div>
  ${list.length?tbl('tb-induk',['NIS','Nama','Orang Tua','Asal Sekolah','Dokumen','Rapor',''],rows):emptyBox('book-marked','Buku induk kosong pada TA '+state.ta,'Tahun ajaran ini belum diisi data siswa. Pilih TA lain di bilah atas untuk melihat data, atau isi lewat Data Siswa.',`<button class="btn pri" data-go="dsiswa"><i data-lucide="users"></i>Ke Data Siswa</button>`)}
 </div>`;
},

naik(){
 const list=siswaTA();
 const kelas=[...new Set(list.map(s=>classForYear(s,state.ta)))].sort((a,b)=>{
  const na=parseInt(String(a).match(/^\d+/)||99), nb=parseInt(String(b).match(/^\d+/)||99);
  return na-nb||String(a).localeCompare(String(b));
 });
 const rows=list.map(s=>`<tr class="frow">
  <td><span class="strong">${esc2(s.n)}</span><span style="font-size:11px;color:var(--tx3)"> · NIS ${esc2(s.nis)}</span></td>
  <td class="mono">${esc2(classForYear(s,state.ta))}</td>
  <td><label class="ck"><input type="checkbox" data-naikck="${s.sp}" checked><span>Naik</span></label></td>
  <td><input data-naikto="${s.sp}" value="${attq(nextKelas(classForYear(s,state.ta)))}" style="padding:6px 10px;border:1px solid var(--line2);border-radius:8px;width:110px;font-size:12.5px"></td>
  <td class="mono" style="font-size:11px;color:var(--tx3)">${(s.riwayat||[]).slice(-1).map(r=>esc2(r.dari+'→'+r.ke+' ('+r.ta+')')).join('')||'—'}</td></tr>`).join('');
 const riwayat=state.naikLog.slice().reverse().map(l=>`<tr><td class="mono">${esc2(l.tgl)}</td><td class="mono">${esc2(l.ta)}</td><td>${esc2(l.ket)}</td><td class="mono">${l.n} siswa</td></tr>`).join('');
 return `<div class="page">
  ${head('Kenaikan Kelas','Akhir tahun ajaran — naikkan kelas seluruh siswa per kelas, atau tandai satu per satu siswa yang tidak naik.',badge('TA aktif '+state.ta,C.cyan))}
  <div class="panel mb16"><div class="ph"><span>Kenaikan per Kelas (sekali klik)</span><span class="sub"><i data-lucide="arrow-up-circle" style="width:12px;height:12px"></i>kelas 6 otomatis menjadi LULUS</span></div>
   <div class="pb" style="display:flex;gap:11px;align-items:flex-end;flex-wrap:wrap">
    <div class="fld" style="margin:0"><label>Kelas Asal</label><select id="nk-dari">${kelas.map(k=>`<option>${esc2(k)}</option>`).join('')||'<option value="">(belum ada kelas)</option>'}</select></div>
    <div class="fld" style="margin:0"><label>Menjadi</label><input id="nk-ke" placeholder="otomatis" value="${kelas.length?attq(nextKelas(kelas[0])):''}"></div>
    <button class="btn pri" data-naikkan><i data-lucide="arrow-up-circle"></i>Naikkan Kelas Ini</button>
    ${kelas.length?'':'<p style="font-size:12px;color:var(--tx3)">Belum ada siswa pada TA '+state.ta+' — tahun yang belum diisi memang kosong; pilih TA aktif di bilah atas atau isi Data Siswa dulu.</p>'}
   </div>
  </div>
  ${list.length?`
  <div class="panel mb16"><div class="ph"><span>Kenaikan per Siswa</span><span class="sub">hilangkan centang untuk siswa yang TIDAK naik</span></div>
   <div class="pb">
    <div style="display:flex;gap:9px;flex-wrap:wrap;margin-bottom:12px">
     ${srch('tb-naik','Cari nama siswa…')}
     <button class="btn ghost" data-naikauto><i data-lucide="wand-2"></i>Isi Otomatis (+1 Semua)</button>
     <button class="btn pri" data-naikproses><i data-lucide="check-circle"></i>Proses Kenaikan Terpilih</button>
    </div>
    ${tbl('tb-naik',['Nama','Kelas Sekarang','Naik?','Kelas Tujuan','Riwayat Terakhir'],rows)}
   </div>
  </div>
  <div class="panel"><div class="ph"><span>Riwayat Kenaikan</span><span class="sub">${state.naikLog.length} proses tercatat</span></div>
   ${state.naikLog.length?`<div class="twrap"><table class="tbl"><thead><tr><th>Tanggal</th><th>TA</th><th>Keterangan</th><th>Jumlah</th></tr></thead><tbody>${riwayat}</tbody></table></div>`:'<p style="padding:14px 18px;font-size:12.5px;color:var(--tx3)">Belum ada proses kenaikan kelas tercatat.</p>'}
  </div>`:''}
 </div>`;
},

ppdb(){
 serapPpdbInbox();
 const L=state.ppdb;
 const cnt=s=>L.filter(x=>x.status===s).length;
 const rows=L.map(p=>`<tr class="frow">
  <td class="mono" style="font-size:11px">${esc2(p.reg)}</td>
  <td><span class="strong">${esc2(p.n)}</span><div style="font-size:11px;color:var(--tx3)">${esc2(p.jk==='P'?'Perempuan':'Laki-laki')} · ${esc2(p.tlahir||'')}, ${esc2(fmtTglPPDB(p.tgl))}</div></td>
  <td>${esc2(p.asal||'—')}</td>
  <td style="font-size:12px">${esc2(p.ib||'—')} / ${esc2(p.im||'—')}<div class="mono" style="font-size:11px;color:var(--tx3)">${esc2(p.hp||'')}</div></td>
  <td>${p.status==='Lulus'?badge(p.status,C.green):p.status==='Cadangan'?badge(p.status,C.amber):p.status==='Ditolak'?badge(p.status,C.rose):badge(p.status,C.sky)}</td>
  <td style="text-align:right"><button class="ibtn" data-ppwa="${p.sp}" title="Kirim status via WhatsApp" style="color:#1fae5a"><i data-lucide="message-circle"></i></button> <button class="ibtn" data-ppdet="${p.sp}" title="Detail"><i data-lucide="folder-open"></i></button> <button class="ibtn" data-ppdel="${p.sp}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`).join('');
 return `<div class="page">
  ${head('PPDB — Penerimaan Peserta Didik Baru','Pendaftaran daring dari formulir publik ppdb.html. Mode jaringan: pendaftar dari HP/laptop mana pun yang satu jaringan sekolah mengirim ke server, lalu ditarik ke sini dengan tombol “Tarik dari Server”.',
   `<input id="ppdb-url" value="${attq(state.ppdbServer||'')}" placeholder="Server jaringan (kosong = otomatis)" title="Alamat server lokal tempat formulir dibuka, cth: http://192.168.1.10:8080" style="padding:9px 12px;border:1px solid var(--line2);border-radius:9px;font-size:13px;min-width:200px;background:#fff"><button class="btn pri" data-netpull title="Tarik pendaftaran baru dari server jaringan sekolah"><i data-lucide="inbox"></i>Tarik dari Server</button><input id="ppdb-gas" value="${attq(state.gasUrl||'')}" placeholder="Alamat Google Apps Script (internet)" title="Web app URL dari Google Apps Script — lihat google-apps-script.js" style="padding:9px 12px;border:1px solid var(--line2);border-radius:9px;font-size:13px;min-width:230px;background:#fff"><button class="btn ghost" data-gaspull title="Tarik pendaftaran baru dari Google (internet)"><i data-lucide="cloud-download"></i>Tarik dari Cloud</button><button class="btn ghost" data-gastest title="Uji koneksi ke Google Apps Script"><i data-lucide="plug"></i>Tes Koneksi</button><button class="btn ghost" data-spmb title="Impor daftar murid baru dari berkas SPMB kabupaten / sistem lain"><i data-lucide="sparkles"></i>Impor SPMB</button><button class="btn ghost" data-export-x="tb-ppdb" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-ppdbform title="Buka formulir publik"><i data-lucide="external-link"></i>Formulir Publik</button>`)}
  <div class="panel strip mb16">
   ${stat(cn(L.length),'Total pendaftar',1)}
   ${stat(cn(cnt('Baru')),'Menunggu verifikasi')}
   ${stat(`<span style="color:${C.green}">${cn(cnt('Lulus'))}</span>`,'Lulus')}
   ${stat(cn(cnt('Cadangan')),'Cadangan')}
  </div>
  ${L.length?tbl('tb-ppdb',['No. Registrasi','Nama / TTL','Asal TK','Orang Tua / HP','Status',''],rows):emptyBox('clipboard-list','Belum ada pendaftaran masuk','Buka formulir publik “ppdb.html” pada browser/server yang sama — setiap kiriman orang tua masuk otomatis ke tabel ini.',`<button class="btn pri" data-ppdbform><i data-lucide="external-link"></i>Buka Formulir Publik</button>`)}
 </div>`;
},

asiswa(){
 const rows=ABKEL.map(([k,v])=>`<div class="srow"><div class="slab"><b>${esc2(k)}</b><span>kehadiran bulan ini</span></div><div class="bar"><i style="width:${v}%"></i></div><span class="pct">${v.toLocaleString('id-ID')}%</span>${v<90?badge('Perlu atensi',C.rose):''}</div>`).join('');
 return `<div class="page">
  ${head('Absensi Siswa','Persentase kehadiran per rombongan belajar.')}
  ${ABKEL.length?`<div class="panel">${rows}</div>`:emptyBox('calendar-check','Rekap absensi belum terisi','Rekap kehadiran per kelas dapat dikelola pada versi berikutnya.')}
 </div>`;
},

nilai(){
 const bars=NILAI.map(([m,v])=>`<div class="nb"><span class="nl">${esc2(m)}</span><div class="bar"><i style="width:${v}%"></i></div><span class="nv">${v.toLocaleString('id-ID')}</span></div>`).join('');
 const top=TOP.map(([n,v],i)=>`<div class="rk"><span class="pos ${i===0?'top':''}">${i+1}</span><b>${esc2(n)}</b><span class="nv">${v.toLocaleString('id-ID')}</span></div>`).join('');
 return `<div class="page">
  ${head('Nilai & Rapor','Rata-rata per mata pelajaran dan peringkat — nilai rapor tersimpan di Buku Induk (rekaman kelas 1–6).',
   `<button class="btn ghost" data-surat="rapor"><i data-lucide="mail-open"></i>Undangan Rapor</button><button class="btn ghost" data-go="induk"><i data-lucide="book-marked"></i>Buku Induk</button>`)}
  ${NILAI.length||TOP.length?`<div class="g2">
   ${NILAI.length?`<div class="panel"><div class="ph"><span>Rata-rata per mapel</span><span class="sub">skala 0–100</span></div>${bars}</div>`:''}
   ${TOP.length?`<div class="panel"><div class="ph"><span>Peringkat sementara</span></div>${top}</div>`:''}
  </div>`:emptyBox('book-open','Rekap nilai belum terisi','Unggah rapor PDF lewat Buku Induk — nilai terekstraksi otomatis dan dapat dicetak sebagai transkrip kelas 1–6.',`<button class="btn pri" data-go="induk"><i data-lucide="book-marked"></i>Buka Buku Induk</button>`)}
  <div class="panel" style="margin-top:14px">
   <div class="ph"><span><i data-lucide="sparkles" style="width:15px;height:15px;color:#c9a53a;vertical-align:-2px"></i> Rekap e-Rapor (impor Excel)</span><span class="sub">TA ${esc2(state.ta)}</span></div>
   <div style="padding:4px 16px 14px;font-size:12.5px;color:var(--tx3)">Hasil ekspor nilai dari aplikasi <b>e-Rapor</b> (atau Excel mana pun) bisa diimpor menjadi arsip rekap sekolah — kolom dikenali otomatis, nama dicocokkan dengan Data Siswa.</div>
   ${panelRekap()}
  </div>
 </div>`;
},

spp(){
 const list=siswaTA();
 const rows=list.map(s=>{const p=state.spp[s.sp]||{l:false};
  return `<tr class="frow" data-fval="${p.l?'lunas':'nunggak'}">
  <td><div class="cell-u">${ava(s.n)}<span class="strong">${esc2(s.n)}</span></div></td>
  <td>${esc2(classForYear(s,state.ta))}</td><td class="num">${sppAmount().toLocaleString('id-ID')}</td>
  <td id="sb-${s.sp}">${p.l?badge('Lunas',C.green):badge('Belum Bayar',C.rose)}</td>
  <td style="text-align:right" id="sa-${s.sp}">${p.l?'<span style="color:var(--tx3);font-size:12px;display:inline-flex;align-items:center;gap:6px"><i data-lucide="check" style="width:13px;height:13px"></i>Lunas</span>':`<button class="btn ghost" data-pay="${s.sp}"><i data-lucide="check"></i>Tandai Lunas</button>`}</td></tr>`;}).join('');
 const nunggak=list.filter(s=>!(state.spp[s.sp]&&state.spp[s.sp].l)).length;
 return `<div class="page">
  ${head('Pembayaran SPP','Nominal mengikuti Profil Sekolah ('+rp(sppAmount())+' / bulan) — tandai lunas per siswa.',
   `<button class="btn ghost" data-export-x="tb-spp" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-export-p="tb-spp|Pembayaran SPP" title="Ekspor PDF"><i data-lucide="file-text"></i>PDF</button><button class="btn pri" data-tagihan><i data-lucide="printer"></i>Cetak Tagihan</button>`)}
  ${list.length?`
  <div class="panel strip mb16">
   ${stat(`<span id="sp-total">${rp(sppTerkumpul())}</span>`,'Terkumpul bulan ini',1)}
   ${stat(`<span id="sp-left">${nunggak}</span>`,'Siswa belum bayar')}
   ${stat(rp(sppAmount()),'Nominal per bulan')}
  </div>
  <div class="tools">${chipsRow('tb-spp',[['','Semua'],['lunas','Lunas'],['nunggak','Belum Bayar']])}</div>
  ${tbl('tb-spp',['Nama','Kelas','Nominal','Status',''],rows)}`:emptyBox('receipt','Belum ada siswa pada TA '+state.ta,'Tahun ajaran ini belum diisi. Pilih TA lain di bilah atas atau isi Data Siswa dahulu.')}
 </div>`;
},

perpus(){
 const rows=PERPUS.map(b=>`<tr>
  <td class="strong">${esc2(b.b)}</td><td>${esc2(b.p)}</td><td>${esc2(b.pin)}</td><td class="mono">${esc2(b.tmp)}</td>
  <td>${b.s==='Dipinjam'?badge(b.s,C.sky):b.s==='Terlambat'?badge(b.s,C.rose):badge(b.s,C.green)}</td></tr>`).join('');
 return `<div class="page">
  ${head('Perpustakaan','Sirkulasi koleksi.',
   `<button class="btn ghost" data-export-x="tb-lib" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i>Excel</button><button class="btn ghost" data-export-p="tb-lib|Sirkulasi Perpustakaan" title="Ekspor PDF"><i data-lucide="file-text"></i>PDF</button>`)}
  ${PERPUS.length?tbl('tb-lib',['Judul','Peminjam','Dipinjam','Jatuh Tempo','Status'],rows):emptyBox('library','Sirkulasi perpustakaan belum terisi','Modul pelengkap — pencatatan peminjaman dapat dikelola pada versi berikutnya.')}
 </div>`;
},

roadmap(){
 const tpl=p=>{
  const total=p.c.length, done=p.c.filter(c=>state.deliv[c[0]]).length;
  const st=p.st==='selesai'?['Selesai',C.green]:p.st==='berjalan'?['Berjalan',C.amber]:['Mendatang',C.grey];
  const node=p.st==='selesai'?'done':p.st==='berjalan'?'run':'next';
  const nodeIn=p.st==='selesai'?'<i data-lucide="check"></i>':'';
  return `<article class="phase panel ${p.id==='f4'?'open':''}">
   <span class="node ${node}">${nodeIn}</span>
   <button class="ph-head" data-ph="1">
    <div><h3>Fase ${p.id.slice(1)} — ${p.t}</h3><div class="ph-meta"><span>${p.w}</span><span>·</span>${badge(st[0],st[1])}</div></div>
    <div class="ph-right"><span class="ph-count" id="pc-${p.id}">${done}/${total}</span><i data-lucide="chevron-down" class="chev"></i></div>
   </button>
   <div class="ph-body"><div class="ph-bin"><div class="ph-bin-in">
    <p class="ph-desc">${p.d}</p>
    <div class="ph-bar"><div class="bar"><i id="pg-${p.id}" style="width:${total?done/total*100:0}%"></i></div><span class="ph-pct" id="pp-${p.id}">${total?Math.round(done/total*100):0}%</span></div>
    <div class="checks">${p.c.map(([id,txt])=>`<label class="ck"><input type="checkbox" data-deliv="${id}" ${state.deliv[id]?'checked':''} ${p.st==='selesai'?'disabled':''}><span>${txt}</span></label>`).join('')}</div>
   </div></div></div>
  </article>`;
 };
 const pr=PRINSIP.map(([i,t,d])=>`<div class="pr-item"><span class="pr-ic"><i data-lucide="${i}"></i></span><div><b>${t}</b><p>${d}</p></div></div>`).join('');
 const rel=REL.map(([k,v])=>`<div class="kv"><span style="font-family:var(--mono);font-size:11px;text-transform:uppercase;letter-spacing:.06em">${k}</span><b>${v}</b></div>`).join('');
 return `<div class="page">
  ${head('Peta Jalan Pengembangan','Lima fase menuju sistem administrasi sekolah yang utuh.',badge('PRIMA v2',C.teal))}
  <div class="panel mb16" style="padding:16px 18px">
   <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px">
    <span style="font-weight:700;font-size:13.5px">Kemajuan keseluruhan</span>
    <span class="mono" id="ov-pct" style="color:var(--accent);font-weight:700">—</span>
   </div>
   <div class="bar" style="height:9px"><i id="ov-bar"></i></div>
  </div>
  <div class="g2">
   <div class="tl">${PHASES.map(tpl).join('')}</div>
   <div>
    <div class="panel mb16"><div class="ph"><span>Arah produk</span></div>${pr}</div>
    <div class="panel"><div class="ph"><span>Rencana rilis</span></div>${rel}</div>
   </div>
  </div>
 </div>`;
},
};

/* ================= Dokumen per Tahun Ajaran ================= */
function tahunPage(t){
 const surat=state.suratAgenda.filter(a=>(a.ta||'')===t);
 const siswa=SISWA.filter(s=>(s.masuk||'')===t);
 const rapor=[];
 for(const sp in state.rapor){const R=state.rapor[sp];
  for(const k in R)for(const sem in R[k]){const rec=R[k][sem];
   if((rec.ta||'')===t){const s=SISWA.find(x=>x.sp===sp);rapor.push({nama:s?s.n:'(siswa terhapus)',k,sem,rec});}}}
 rapor.sort((a,b)=>a.nama.localeCompare(b.nama)||+a.k-+b.k||a.sem-b.sem);
 const sRows=surat.map(s=>`<tr class="frow trow"><td class="mono">${esc2(s.a)}</td><td class="strong">${esc2(s.p)}</td><td>${esc2(s.d)}</td><td>${s.t}</td><td>${s.s==='Selesai'?badge(s.s,C.green):s.s==='Tindak Lanjut'?badge(s.s,C.amber):badge(s.s,C.sky)}</td></tr>`).join('');
 const wRows=siswa.map(s=>`<tr class="frow trow"><td><span class="strong">${esc2(s.n)}</span></td><td class="mono">${esc2(s.nis)}</td><td>${esc2(s.k)}</td><td>${s.jk}</td></tr>`).join('');
 const rRows=rapor.map(r=>`<tr class="frow trow"><td class="strong">${esc2(r.nama)}</td><td class="mono">Kelas ${esc2(r.k)}</td><td class="mono">Semester ${r.sem}</td><td class="mono">rata-rata ${rapAvg(r.rec)||'—'}</td></tr>`).join('');
 const kosong=(pesan)=>`<p style="padding:13px 16px;font-size:12.5px;color:var(--tx3)">${pesan}</p>`;
 return `<div class="page">
  ${head('Dokumen Tahun Ajaran '+t,'Semua data yang dientri pada tahun ajaran '+t+' terkumpul di sini — surat, siswa masuk (angkatan), dan rapor.',`<label class="srch"><i data-lucide="search"></i><input id="thn-q" placeholder="Saring data tahun ${t}…"></label>`)}
  <div class="stats">
   ${stat(surat.length,'Surat di agenda',1)}${stat(siswa.length,'Siswa masuk (angkatan)',1)}${stat(rapor.length,'Rekaman rapor diunggah',1)}
  </div>
  <div class="panel mb16"><div class="ph"><span>Surat & Agenda — TA ${t}</span><span class="sub">${surat.length} catatan</span></div>
   ${surat.length?`<div class="twrap"><table class="tbl"><thead><tr><th>No. Agenda</th><th>Perihal</th><th>Asal / Tujuan</th><th>Jenis</th><th>Status</th></tr></thead><tbody>${sRows}</tbody></table></div>`:kosong('Belum ada surat tercatat pada TA '+t+'.')}</div>
  <div class="panel mb16"><div class="ph"><span>Siswa Masuk (Angkatan ${t})</span><span class="sub">${siswa.length} siswa</span></div>
   ${siswa.length?`<div class="twrap"><table class="tbl"><thead><tr><th>Nama</th><th>NIS</th><th>Kelas Sekarang</th><th>JK</th></tr></thead><tbody>${wRows}</tbody></table></div>`:kosong('Belum ada siswa dengan tahun masuk '+t+'.')}</div>
  <div class="panel"><div class="ph"><span>Rapor Diunggah pada TA ${t}</span><span class="sub">${rapor.length} rekaman</span></div>
   ${rapor.length?`<div class="twrap"><table class="tbl"><thead><tr><th>Nama Siswa</th><th>Kelas</th><th>Semester</th><th>Nilai</th></tr></thead><tbody>${rRows}</tbody></table></div>`:kosong('Belum ada rapor diunggah pada TA '+t+'.')}</div>
 </div>`;
}
for(let y=2045;y>=2010;y--){const t=y+'/'+(y+1);PAGES['ta-'+t]=()=>tahunPage(t);}

/* ================= Arsip Digital (berkas per tahun) ================= */
const hsize=b=>{if(b==null)return '—';if(b<1024)return b+' B';if(b<1048576)return (b/1024).toFixed(0)+' KB';return (b/1048576).toFixed(1)+' MB';};
const ARSIP_FOLDER=[['sekolah','Sekolah','school',C.amber],['guru','Guru','users',C.sky],['siswa','Siswa','graduation-cap',C.rose]];
function arsipFolder(y,f){ state.arsip[y]=state.arsip[y]||{sekolah:[],guru:[],siswa:[]}; state.arsip[y][f]=state.arsip[y][f]||[]; return state.arsip[y][f]; }
function arsipTahunPage(y){
 const lists=ARSIP_FOLDER.map(([f])=>arsipFolder(y,f));
 const nAll=lists.reduce((a,l)=>a+l.length,0);
 const sizeAll=lists.reduce((a,l)=>a+l.reduce((b,x)=>b+(x.size||0),0),0);
 const cards=ARSIP_FOLDER.map(([f,label,icon,c],ci)=>{
  const arr=lists[ci];
  const rows=arr.map((x,i)=>`<tr>
   <td><div class="cell-u"><span class="cic" style="background:${c}1c;color:${c};border:1px solid ${c}3d"><i data-lucide="file"></i></span><span class="strong">${esc2(x.n)}</span></div></td>
   <td class="mono">${hsize(x.size)}</td>
   <td class="mono" style="color:var(--tx3)">${new Date(x.ts).toLocaleDateString('id-ID',{day:'2-digit',month:'short',year:'numeric'})} · ${new Date(x.ts).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'})}</td>
   <td style="text-align:right;white-space:nowrap">
    <button class="ibtn" data-arsipview="${y}|${f}|${i}" title="Lihat / pratinjau"><i data-lucide="eye"></i></button>
    <button class="ibtn" data-arsipdl="${y}|${f}|${i}" title="Unduh"><i data-lucide="download"></i></button>
    <button class="ibtn" data-arsipdel="${y}|${f}|${i}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`).join('');
  return `<div class="card" style="margin-bottom:14px">
   <div style="display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--line)">
    <span class="cic" style="background:${c}1c;color:${c};border:1px solid ${c}3d;width:34px;height:34px"><i data-lucide="${icon}"></i></span>
    <div style="flex:1"><b>Folder ${label}</b><div style="font-size:12px;color:var(--tx3)">${arr.length} berkas · ${hsize(arr.reduce((a,x)=>a+(x.size||0),0))}</div></div>
    <button class="btn ghost" data-arsipup="${y}|${f}"><i data-lucide="upload"></i>Tambah Berkas</button>
   </div>
   ${arr.length?`<div class="twrap" style="padding:0"><table class="tbl" style="margin:0"><thead><tr><th>Nama Berkas</th><th style="width:90px">Ukuran</th><th style="width:170px">Diunggah</th><th style="width:120px"></th></tr></thead><tbody>${rows}</tbody></table></div>`
    :`<div style="padding:18px 16px;color:var(--tx3);font-size:13px">Folder kosong — klik “Tambah Berkas” untuk menyimpan berkas ${label.toLowerCase()} tahun ${y}.</div>`}
  </div>`;
 }).join('');
 return `<div class="page">
  ${head('Arsip Digital — Tahun '+y,'Penyimpanan berkas digital sekolah per tahun, dipilah dalam folder Sekolah, Guru, dan Siswa. Berkas tersimpan di data PRIMA (ikut backup & restore); maksimal 3 MB per berkas.',
   `<button class="btn ghost" data-go="ta-${y}/${y+1}"><i data-lucide="calendar-days"></i>Dokumen TA ${y}/${y+1}</button>`)}
  ${stat(`<span style="color:${C.green}">${cn(nAll)}</span>`,'Total berkas')}${stat(`<span style="color:${C.sky}">${hsize(sizeAll)}</span>`,'Total ukuran')}${stat(`<span style="color:${C.lilac}">${cn(3)}</span>`,'Folder')}
  ${cards}
 </div>`;
}
for(let y=2045;y>=2010;y--){PAGES['ad-'+y]=()=>arsipTahunPage(y);}
function pickArsip(spec){const [y,f]=spec.split('|');
 const inp=document.createElement('input');inp.type='file';inp.multiple=true;
 inp.onchange=()=>{const files=[...(inp.files||[])].filter(x=>x);if(!files.length)return;
  const ok=files.filter(x=>x.size<=3*1024*1024);
  files.forEach(x=>{if(x.size>3*1024*1024)toast('“'+x.name+'” lebih dari 3 MB — tidak disimpan.','alert-triangle');});
  if(!ok.length)return; let n=0;
  ok.forEach(file=>{const rd=new FileReader();
   rd.onload=()=>{arsipFolder(y,f).push({n:file.name,size:file.size,ts:Date.now(),data:rd.result});n++;
    if(n===ok.length){requestSave();navigate(state.page);toast(n+' berkas tersimpan di folder '+f.charAt(0).toUpperCase()+f.slice(1)+' — Tahun '+y+'.','folder-archive');}};
   rd.readAsDataURL(file);});};
 document.body.appendChild(inp);inp.click();setTimeout(()=>inp.remove(),3000);}
function getArsip(spec){const [y,f,i]=spec.split('|');const arr=((state.arsip||{})[y]||{})[f];return arr?arr[+i]:null;}
function dlArsip(spec){const x=getArsip(spec);if(!x||!x.data){toast('Berkas tidak ditemukan.','info');return;}
 const a=document.createElement('a');a.href=x.data;a.download=x.n||'berkas';document.body.appendChild(a);a.click();setTimeout(()=>a.remove(),500);}
function viewArsip(spec){const x=getArsip(spec);if(!x)return;
 if(x.data&&/^data:image\//.test(x.data)){document.getElementById('lbimg').src=x.data;document.getElementById('lightbox').classList.add('show');}
 else if(x.data){dlArsip(spec);}
 else toast('Pratinjau tidak tersedia untuk berkas ini.','info');}
function delArsip(spec){const [y,f,i]=spec.split('|');const arr=((state.arsip||{})[y]||{})[f];if(!arr||!arr[+i])return;
 if(!confirm('Hapus berkas “'+arr[+i].n+'” dari arsip Tahun '+y+'? Tindakan ini permanen.'))return;
 arr.splice(+i,1);requestSave();navigate(state.page);toast('Berkas dihapus dari arsip.','trash-2');}
function tahunFilter(){
 const q=(document.getElementById('thn-q').value||'').toLowerCase();
 document.querySelectorAll('#content .trow').forEach(r=>{
  r.style.display=(!q||r.textContent.toLowerCase().includes(q))?'':'none';
 });
}

/* ================= Upload ================= */
function upBadge(kind,key,field,label){
 const u=getUp(kind,key,field);
 return `<button class="upbadge ${u?'ok':''}" data-up="${kind}|${key}|${field}|${acceptFor(field)}" title="${u?esc2(u.name):'Unggah '+label}">
  <i data-lucide="${u?'check':'upload'}"></i>${label}</button>`;
}
function upThumb(kind,key,fallback){
 const u=getUp(kind,key,'foto');
 if(u&&u.img) return `<img class="uthumb" src="${u.data}" alt="foto">`;
 return ava(fallback);
}
function pickUp(kind,key,field,accept){
 const inp=document.createElement('input');
 inp.type='file'; inp.accept=accept;
 inp.onchange=()=>{
  const f=inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
   const val={name:f.name,size:f.size,data:r.result,img:f.type.startsWith('image/')};
   const raporPdf=field==='rapor'&&f.type==='application/pdf';
   if(kind==='logo'){state.uploads.logo=val;}
   else if(!raporPdf){(state.uploads[kind][key]=state.uploads[kind][key]||{})[field]=val;}
   if(field==='rapor'){
    if(f.type==='application/pdf'&&window.pdfjsLib){
     pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';
     parseRaporPDF(r.result).then(recs=>{
      distributeRapor(recs,key,r.result,f);
     }).catch(()=>{
      distributeRapor(null,key,r.result,f);
     });
    }else{
     distributeRapor(null,key,r.result,f);
    }
   }
   toast('Terunggah: '+f.name+' ('+sizeFmt(f.size)+')','upload');
   navigate(state.page);
   if(drawerRedraw) drawerRedraw();
   requestSave();
  };
  r.readAsDataURL(f);
 };
 inp.click();
}

/* ================= Drawer ================= */
let drawerRedraw=null;
function openDrawer(html,redraw){
 drawerRedraw=redraw||null;
 document.getElementById('drin').innerHTML=html;
 document.body.classList.add('dr-open');
 lucide.createIcons();
 document.getElementById('drin').scrollTop=0;
}
function closeDrawer(){document.body.classList.remove('dr-open');drawerRedraw=null;}
document.getElementById('drback').addEventListener('click',closeDrawer);

function docSlot(kind,key,field,label,icon){
 const u=getUp(kind,key,field);
 return `<div class="docslot">
  <div class="ds-ic">${u&&u.img?`<img src="${u.data}" alt="${label}">`:u?'<i data-lucide="file-text"></i>':`<i data-lucide="${icon}"></i>`}</div>
  <div class="ds-m"><b>${label}</b><span>${u?esc2(u.name)+' · '+sizeFmt(u.size):'Belum diunggah — klik tombol untuk memilih berkas (JPG / PDF)'}</span></div>
  <div class="ds-a">
   ${u&&u.img?`<button class="ibtn" data-upview="${kind}|${key}|${field}" title="Lihat"><i data-lucide="eye"></i></button>`:''}
   <button class="ibtn" data-up="${kind}|${key}|${field}|${acceptFor(field)}" title="${u?'Ganti berkas':'Unggah'}"><i data-lucide="${u?'refresh-cw':'upload'}"></i></button>
  </div></div>`;
}

function indukDrawer(s){
 const f=getUp('siswa',s.sp,'foto');
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.lime}1c;color:${C.lime};border:1px solid ${C.lime}3d"><i data-lucide="book-marked"></i></span>
   <div><b>Lembar Buku Induk</b><span class="sub">${esc2(s.n)} · NIS ${esc2(s.nis)} · Kelas ${esc2(s.k)}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   <div class="idrow">
    <div class="photobox" data-up="siswa|${s.sp}|foto|image/*" title="Klik untuk mengunggah foto 3×4">
     ${f&&f.img?`<img src="${f.data}" alt="Foto siswa">`:`<span class="ph-ic"><i data-lucide="camera"></i><em>Unggah Foto<br>3 × 4</em></span>`}
    </div>
    <div class="kvlist">
     ${kvlist([['NISN','<span class="mono">'+esc2(s.nisn)+'</span>'],['Tempat, Tgl Lahir',esc(s.ttl)],['Jenis Kelamin',s.jk==='L'?'Laki-laki':'Perempuan'],['Agama',esc(s.ag)],['Anak ke-',String(s.ak||'—')],['Asal Sekolah',esc(s.asal)],['Keterangan Mutasi',s.mutasi&&s.mutasi.jenis?esc2(s.mutasi.jenis==='Masuk'?'Mutasi masuk':'Mutasi keluar')+(s.mutasi.ket?' — '+esc2(s.mutasi.ket):''):'—']])}
    </div>
   </div>
   <div class="kvlist">
    ${kvlist([['Nama Ayah',esc(s.ib)],['Nama Ibu',esc(s.im)],['Pekerjaan Orang Tua',esc(s.kr)],['Alamat',esc(s.al)],['Telepon','<span class="mono">'+esc2(s.tl||'—')+'</span>'],['Angkatan (masuk)',esc2(s.masuk||state.ta)]])}
   </div>
   ${(s.riwayat&&s.riwayat.length)?`<div class="kvlist" style="margin-top:8px">${kvlist([['Riwayat kelas',s.riwayat.map(r=>esc2(r.dari+' → '+r.ke+' ('+r.ta+')')).join('<br>')]])}</div>`:''}
   <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:10px">
    <button class="btn ghost" data-siswaedit="${s.sp}"><i data-lucide="pencil"></i>Edit Data Siswa</button>
   </div>
   <div class="sect">Dokumen Persyaratan</div>
   ${docSlot('siswa',s.sp,'kk','Kartu Keluarga (KK)','contact')}
   ${docSlot('siswa',s.sp,'akte','Akte Kelahiran','scroll-text')}
   ${s.mutasi&&s.mutasi.jenis?docSlot('siswa',s.sp,'mutasi','Dokumen Mutasi / Pindah (surat keterangan)','file-text'):''}
   <div class="sect">Rapor — Rekaman Berkelanjutan (Kelas 1–6)</div>
   <div class="rap-grid">${rapCards(s)}</div>
   <div id="rap-det"></div>
   <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    ${upBadge('siswa',s.sp,'rapor','Unggah Rapor (PDF) — otomatis masuk kelas & semester terbaca')}
    ${canEdit()&&state.rapor[s.sp]&&Object.keys(state.rapor[s.sp]).length?`<button class="chip rapwipe" data-rapwipes="${s.sp}"><i data-lucide="trash-2" style="width:11px;height:11px"></i>Hapus Semua Rapor Siswa Ini</button>`:''}
   </div>
   ${isK6(s)?`
   <div class="sect">Ijazah — Kelas 6 / Lulusan</div>
   <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <button class="upbadge ${state.ijazah[s.sp]?'ok':''}" data-ijups="${s.sp}"><i data-lucide="${state.ijazah[s.sp]?'check':'upload'}"></i>${state.ijazah[s.sp]?'Ganti Ijazah (PDF)':'Unggah Ijazah (PDF)'}</button>
    ${state.ijazah[s.sp]&&(state.ijazah[s.sp].data||(state.ijazah[s.sp].berkas&&state.ijazahBerkas[state.ijazah[s.sp].berkas]))?`<button class="btn ghost" data-ijprint="${s.sp}"><i data-lucide="file-text"></i>Cetak Ijazah Asli (PDF)</button>`:''}
    ${canEdit()&&state.ijazah[s.sp]?`<button class="chip rapwipe" data-ijdel="${s.sp}"><i data-lucide="trash-2" style="width:11px;height:11px"></i>Hapus Ijazah</button>`:''}
   </div>
   ${state.ijazah[s.sp]?`<p style="font-size:11px;color:var(--tx3);margin-top:5px">Berkas: ${esc2(state.ijazah[s.sp].file)} · diunggah ${esc2(state.ijazah[s.sp].tgl)} · TA ${esc2(state.ijazah[s.sp].ta||'—')}</p>`:'<p style="font-size:11.5px;color:var(--tx3);margin-top:5px">Unggah pindaian ijazah (PDF) — hasil cetak identik dengan berkas asli. Bisa juga unggah massal (lebih dari satu PDF) dari panel “Ijazah” di halaman Buku Induk.</p>'}
   `:''}
   <div style="display:flex;gap:9px;margin-top:18px;flex-wrap:wrap">
    <button class="btn pri" data-indukprint="${s.sp}"><i data-lucide="printer"></i>Cetak Lembar Induk</button>
    <button class="btn ghost" data-transkrip="${s.sp}"><i data-lucide="graduation-cap"></i>Cetak Transkrip Rapor</button>
    <button class="btn ghost" data-drclose>Tutup</button>
   </div>
  </div>`,()=>indukDrawer(s));
 renderRapDet(s.sp,1);
}

function guruDrawer(g){
 const f=getUp('guru',g.nip,'foto');
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.sky}1c;color:${C.sky};border:1px solid ${C.sky}3d"><i data-lucide="users"></i></span>
   <div><b>Dokumen Guru</b><span class="sub">${esc2(g.n)} · ${esc2(g.m)}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   <div class="idrow">
    <div class="photobox" data-up="guru|${attq(g.nip)}|foto|image/*" title="Klik untuk mengunggah foto">
     ${f&&f.img?`<img src="${f.data}" alt="Foto guru">`:`<span class="ph-ic"><i data-lucide="camera"></i><em>Unggah<br>Foto</em></span>`}
    </div>
    <div class="kvlist">
     ${kvlist([['NIP / NUPTK','<span class="mono">'+esc2(g.nip)+'</span>'],['Mata Pelajaran',esc2(g.m)],['Status Kepegawaian',esc2(g.s)],['Skor SKP','<span class="mono">'+esc2(String(g.skp||'—'))+'</span>']])}
    </div>
   </div>
   <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:10px">
    <button class="btn ghost" data-guruedit="${attq(g.nip)}"><i data-lucide="pencil"></i>Edit Data Guru</button>
   </div>
   <div class="sect">Berkas Kepegawaian</div>
   ${docSlot('guru',g.nip,'skCpns','SK CPNS / PPPK','scroll-text')}
   ${docSlot('guru',g.nip,'skTerakhir','SK Terakhir (penugasan / kenaikan pangkat)','file-check')}
   <div style="display:flex;gap:9px;margin-top:18px;flex-wrap:wrap">
    <button class="btn ghost" data-drclose>Tutup</button>
   </div>
  </div>`,()=>guruDrawer(g));
}

/* ---- Drawer surat ---- */
const fld=(id,label,ph='',val='')=>`<div class="fld"><label>${label}</label><input id="${id}" value="${attq(val)}" placeholder="${ph}"></div>`;
const selSiswa=()=>`<div class="fld"><label>Pilih Peserta Didik (TA ${state.ta})</label><select id="f-sub">${siswaTA().map(s=>`<option value="${s.sp}">${esc2(s.n)} — ${esc2(classForYear(s,state.ta))} · NIS ${esc2(s.nis)}</option>`).join('')||'<option value="">(belum ada siswa pada TA '+state.ta+' — tahun kosong)</option>'}</select></div>`;
const selGuru=()=>`<div class="fld"><label>Pilih Guru</label><select id="f-guru">${GURU.map((g,i)=>`<option value="${i}">${esc2(g.n)} — ${esc2(g.m)}</option>`).join('')||'<option value="">(belum ada guru — isi Data Guru dulu)</option>'}</select></div>`;

function suratForm(id){
 if(id==='aktif-s') return selSiswa()+fld('f-keperluan','Keperluan Surat','cth: pendaftaran lomba OSN di luar sekolah');
 if(id==='aktif-g') return selGuru()+fld('f-keperluan','Keperluan Surat','cth: pengajuan keringanan cicilan bank');
 if(id==='pernah') return fld('f-nama','Nama Lengkap Alumni','cth: Andre Wijaya')+fld('f-nis','NIS / No. Induk','cth: 19.0034')+
  `<div class="frow2">${fld('f-tahun','Tahun Lulus','cth: 2019')}${fld('f-ijazah','No. Ijazah (opsional)','DN-…')}</div>`+fld('f-keperluan','Keperluan Surat','cth: syarat melanjutkan kuliah');
 if(id==='mutasi') return selSiswa()+fld('f-tujuan','Sekolah Tujuan','cth: SD Negeri 2 Ungaran')+fld('f-alasan','Pertimbangan / Alasan','cth: orang tua pindah tugas');
 if(id==='m8535') return selSiswa()+
  `<div class="fld"><label>Uraian Data yang Berubah</label><select id="f-jenis"><option>Nama Lengkap</option><option>Nama Ibu Kandung</option><option>Tempat & Tanggal Lahir</option><option>NISN</option><option>Jenis Kelamin</option><option>Alamat</option></select></div>`+
  fld('f-lama','Data Lama (di Dapodik)','sesuai data sekarang')+fld('f-baru','Data Baru (sesuai dokumen)','sesuai akte / KK terbaru')+fld('f-alasan','Alasan / Dasar Perubahan','cth: koreksi penulisan pada akte kelahiran');
 if(id==='ubah') return selSiswa()+fld('f-lama','Identitas Lama (Nama)','sesuai dokumen lama')+fld('f-baru','Identitas Baru (Nama)','sesuai dokumen baru')+
  fld('f-dasar','Dasar Perubahan','cth: Kartu Keluarga baru No. 3204…/…')+fld('f-keperluan','Keperluan Surat','cth: penyesuaian data Dapodik & bank');
 if(id==='rapor') return selSiswa()+`<div class="frow2">${fld('f-tgl','Hari / Tanggal','','Sabtu, 21 Juni 2026')}${fld('f-waktu','Waktu','','08.00 – 12.00 WIB')}</div>`;
 return '';
}
let SR_ID=null;
function srPrev(id){
 const el=document.getElementById('sr-prev'); if(!el) return;
 const use=document.getElementById('sr-use'); const on=!use||use.checked;
 const d=new Date();
 if(on){
  const kode=KPSEL['sr']||KODE_PERBUP[id]||'000';
  const seq=String((state.noSurat['p_'+id]||NOBASE[id]||0)+1).padStart(4,'0');
  el.innerHTML=`<b>B/${kode}/${seq}/${ROMAWI[d.getMonth()]}/${d.getFullYear()}</b><span>Perkiraan nomor format Perbup — nomor urut naik saat pratinjau dibuat.</span>`;
 }else{
  el.innerHTML=`<b>${NOCODE[id]}/${String((state.noSurat['s_'+id]||NOBASE[id])+1).padStart(3,'0')}/${d.getFullYear()}</b><span>Format lama (kotak Perbup tidak dicentang).</span>`;
 }
}
function suratDrawer(id){
 const s=SURAT_JENIS.find(x=>x.id===id);
 SR_ID=id;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${s.c}1c;color:${s.c};border:1px solid ${s.c}3d"><i data-lucide="${s.icon}"></i></span>
   <div><b>${s.t}</b><span class="sub">${s.d}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${suratForm(id)}
   <div class="sect">Nomor Naskah — format Perbup 8/2023</div>
   <label class="ck" style="margin:0 0 8px"><input type="checkbox" id="sr-use" checked><span>Gunakan format B / kode / 0000 / bulan romawi / tahun</span></label>
   <div class="fld"><label>Kode klasifikasi (cari atau gulir)</label>${klasPickerHTML('sr',KODE_PERBUP[id]||'')}</div>
   <div class="ksel" id="sr-prev" style="margin-bottom:10px"></div>
   <div style="display:flex;gap:9px;margin-top:4px"><button class="btn pri" data-sgen="${id}"><i data-lucide="file-signature"></i>Buat Pratinjau</button></div>
   <div id="sprev" class="mt16"></div>
  </div>`);
 bindKlasPicker('sr',KODE_PERBUP[id]||'',()=>srPrev(id));
 renderKlasPicker('sr',KPSEL['sr']);
 srPrev(id);
}
function generateSurat(id){
 const v=x=>{const el=document.getElementById(x);return el?el.value.trim():'';};
 const butuhSiswa=['aktif-s','mutasi','m8535','ubah','rapor'];
 if(butuhSiswa.includes(id)&&!SISWA.length){toast('Belum ada data siswa — isi lewat Data Siswa (impor Excel).','info');return;}
 if(id==='aktif-g'&&!GURU.length){toast('Belum ada data guru — isi lewat Data Guru (impor Excel).','info');return;}
 let d={},miss=[];
 if(butuhSiswa.includes(id)) d.siswa=v('f-sub');
 if(id==='aktif-g') d.guru=v('f-guru');
 if(id==='aktif-s'||id==='aktif-g'){d.keperluan=v('f-keperluan');if(!d.keperluan)miss.push('Keperluan surat');}
 if(id==='pernah'){d.nama=v('f-nama');d.nis=v('f-nis');d.tahun=v('f-tahun');d.noijazah=v('f-ijazah');d.keperluan=v('f-keperluan');
  if(!d.nama)miss.push('Nama');if(!d.nis)miss.push('NIS');if(!d.tahun)miss.push('Tahun lulus');}
 if(id==='mutasi'){d.tujuan=v('f-tujuan');d.alasan=v('f-alasan');
  if(!d.tujuan)miss.push('Sekolah tujuan');if(!d.alasan)miss.push('Alasan');}
 if(id==='m8535'){d.jenis=v('f-jenis');d.lama=v('f-lama');d.baru=v('f-baru');d.alasan=v('f-alasan');
  if(!d.lama)miss.push('Data lama');if(!d.baru)miss.push('Data baru');if(!d.alasan)miss.push('Alasan');}
 if(id==='ubah'){d.lama=v('f-lama');d.baru=v('f-baru');d.dasar=v('f-dasar');d.keperluan=v('f-keperluan');
  if(!d.lama)miss.push('Identitas lama');if(!d.baru)miss.push('Identitas baru');if(!d.dasar)miss.push('Dasar perubahan');}
 if(id==='rapor'){d.tgl=v('f-tgl');d.waktu=v('f-waktu');
  if(!d.tgl)miss.push('Tanggal');if(!d.waktu)miss.push('Waktu');}
 if(miss.length){toast('Lengkapi dulu: '+miss.join(', '),'info');return;}
 let no=null;
 const use=document.getElementById('sr-use');
 if(use&&use.checked){
  const kode=KPSEL['sr']||KODE_PERBUP[id]||'000', k='p_'+id, dt=new Date();
  state.noSurat[k]=(state.noSurat[k]||NOBASE[id]||0)+1;
  no=`B/${kode}/${String(state.noSurat[k]).padStart(4,'0')}/${ROMAWI[dt.getMonth()]}/${dt.getFullYear()}`;
  requestSave();
 }
 const html=suratDoc(id,d,no);
 state.docHtml=html;
 document.getElementById('sprev').innerHTML=html+
  `<div style="display:flex;gap:9px;margin-top:14px"><button class="btn pri" data-sprint><i data-lucide="printer"></i>Cetak Surat</button></div>`;
 lucide.createIcons();
 toast('Pratinjau siap — periksa sebelum mencetak.','file-signature');
}

/* ---- Drawer SK & MOU ---- */
function skDrawer(sk){
 const no=state.skNos[sk.id]||(state.skNos[sk.id]=nextSkNo(sk.kode));
 const html=skDoc(sk,no);
 state.docHtml=html;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${sk.c}1c;color:${sk.c};border:1px solid ${sk.c}3d"><i data-lucide="${sk.icon}"></i></span>
   <div><b>${sk.t}</b><span class="sub">${sk.tentang}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${html}
   <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap">
    <button class="btn pri" data-sprint><i data-lucide="printer"></i>Cetak SK</button>
    <button class="btn ghost" data-drclose>Tutup</button>
   </div>
  </div>`);
}
let MOU_EDIT=null;
function mouDrawer(m){
 const html=mouDoc(m);
 state.docHtml=html;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${m.c}1c;color:${m.c};border:1px solid ${m.c}3d"><i data-lucide="handshake"></i></span>
   <div><b>MOU — ${esc2(m.mitra)}</b><span class="sub">${esc2(m.bidang)} · ${esc2(m.mulai)} s.d. ${esc2(m.akhir)}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${html}
   <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap">
    <button class="btn pri" data-sprint><i data-lucide="printer"></i>Cetak MOU</button>
    <button class="btn ghost" data-mouedit="${m.id}"><i data-lucide="pencil"></i>Edit MOU</button>
    <button class="btn ghost" data-drclose>Tutup</button>
   </div>
  </div>`);
}
/* ================= Formulir isian (tambah & edit) ================= */
const fldT=(id,label,ph='',val='')=>`<div class="fld"><label>${label}</label><textarea id="${id}" rows="4" placeholder="${ph}">${esc2(val)}</textarea></div>`;

/* ---- Pegawai ---- */
let PEG_EDIT=null;
function pegawaiForm(p){
 PEG_EDIT=p?PEGAWAI.indexOf(p):null;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.peri}1c;color:${C.peri};border:1px solid ${C.peri}3d"><i data-lucide="users"></i></span>
   <div><b>${p?'Edit Pegawai':'Tambah Pegawai'}</b><span class="sub">tersimpan langsung ke tabel Pegawai & Tata Usaha</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${fld('pf-nama','Nama Lengkap','cth: Agus Salim',p?p.n:'')}
   ${fld('pf-jab','Jabatan','cth: Staf Keuangan',p?p.j:'')}
   <div class="frow2">
    <div class="fld"><label>Unit</label><select id="pf-unit">${['Administrasi','Keuangan','Perpustakaan','Kurikulum'].map(u=>`<option ${p&&p.u===u?'selected':''}>${u}</option>`).join('')}</select></div>
    <div class="fld"><label>Status Kepegawaian</label><select id="pf-status">${['PNS','PTT','Honorer'].map(u=>`<option ${p&&p.s===u?'selected':''}>${u}</option>`).join('')}</select></div>
   </div>
   ${fld('pf-mk','Masa Kerja','cth: 3 th',p?p.mk:'')}
   <div style="display:flex;gap:9px;margin-top:6px;flex-wrap:wrap">
    <button class="btn pri" data-pegsave><i data-lucide="user-plus"></i>${p?'Simpan Perubahan':'Simpan Pegawai'}</button>
    <button class="btn ghost" data-drclose>Batal</button>
   </div>
  </div>`);
}
function savePegawai(){
 const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
 const n=v('pf-nama'), j=v('pf-jab');
 if(!n||!j){toast('Lengkapi dulu: Nama, Jabatan','info');return;}
 const rec={n,j,u:v('pf-unit')||'Administrasi',s:v('pf-status')||'Honorer',mk:v('pf-mk')||'baru'};
 if(PEG_EDIT!==null&&PEGAWAI[PEG_EDIT]){PEGAWAI[PEG_EDIT]=rec;toast('Data pegawai diperbarui: '+n,'pencil');}
 else{PEGAWAI.push(rec);toast('Pegawai baru tercatat: '+n,'user-plus');}
 closeDrawer(); navigate('pegawai'); requestSave();
}

/* ---- Guru ---- */
let GURU_EDIT=null;
function guruForm(g){
 GURU_EDIT=g?g.nip:null;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.sky}1c;color:${C.sky};border:1px solid ${C.sky}3d"><i data-lucide="users"></i></span>
   <div><b>${g?'Edit Guru':'Tambah Guru'}</b><span class="sub">tersimpan ke tabel Data Guru</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${fld('gf-nama','Nama Lengkap & Gelar','cth: Budi Santoso, S.Pd.',g?g.n:'')}
   ${fld('gf-nip','NIP / NUPTK','cth: 19850217 200903 2 010',g?g.nip:'')}
   ${fld('gf-mapel','Mata Pelajaran / Tugas','cth: Matematika',g?g.m:'')}
   <div class="frow2">
    <div class="fld"><label>Status Kepegawaian</label><select id="gf-status">${['PNS','PPPK','Honorer'].map(u=>`<option ${g&&g.s===u?'selected':''}>${u}</option>`).join('')}</select></div>
    ${fld('gf-skp','Skor SKP (opsional)','cth: 88',g&&g.skp?String(g.skp):'')}
   </div>
   <div style="display:flex;gap:9px;margin-top:6px;flex-wrap:wrap">
    <button class="btn pri" data-gurusave><i data-lucide="user-plus"></i>${g?'Simpan Perubahan':'Simpan Guru'}</button>
    <button class="btn ghost" data-drclose>Batal</button>
   </div>
  </div>`);
}
function saveGuru(){
 const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
 const n=v('gf-nama');
 if(!n){toast('Lengkapi dulu: Nama','info');return;}
 const rec={n,nip:v('gf-nip')||('G'+Date.now()),m:v('gf-mapel')||'—',s:v('gf-status')||'Honorer',skp:+v('gf-skp')||0};
 if(GURU_EDIT!==null){const i=GURU.findIndex(x=>x.nip===GURU_EDIT);if(i>=0){rec.nip=GURU_EDIT;GURU[i]=rec;}}
 else GURU.push(rec);
 state.spp=state.spp; // noop
 closeDrawer(); navigate(state.page==='dgurudok'||state.page==='aguru'||state.page==='kinerja'?state.page:'dguru'); requestSave();
 toast(GURU_EDIT!==null?'Data guru diperbarui: '+n:'Guru baru tercatat: '+n,'users');
}

/* ---- Siswa ---- */
let SISWA_EDIT=null;
function siswaForm(s){
 SISWA_EDIT=s?s.sp:null;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.rose}1c;color:${C.rose};border:1px solid ${C.rose}3d"><i data-lucide="graduation-cap"></i></span>
   <div><b>${s?'Edit Data Siswa':'Tambah Siswa'}</b><span class="sub">tersimpan ke Data Siswa & Buku Induk</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${fld('sf-nama','Nama Lengkap','cth: Ananda Putra',s?s.n:'')}
   <div class="frow2">
    ${fld('sf-nis','NIS','cth: 26.0001',s?s.nis:'')}
    ${fld('sf-nisn','NISN','cth: 0123456789',s?s.nisn:'')}
   </div>
   <div class="frow2">
    ${fld('sf-kelas','Kelas','cth: 1A',s?s.k:'')}
    <div class="fld"><label>Jenis Kelamin</label><select id="sf-jk"><option value="L" ${s&&s.jk==='L'?'selected':''}>Laki-laki</option><option value="P" ${s&&s.jk==='P'?'selected':''}>Perempuan</option></select></div>
   </div>
   ${fld('sf-ttl','Tempat, Tanggal Lahir','cth: Ungaran, 12 Mei 2019',s?s.ttl:'')}
   <div class="frow2">
    ${fld('sf-agama','Agama','cth: Islam',s?s.ag:'')}
    ${fld('sf-ak','Anak ke-','cth: 2',s?String(s.ak||''):'')}
   </div>
   <div class="frow2">
    ${fld('sf-ayah','Nama Ayah','cth: Budi Santoso',s?s.ib:'')}
    ${fld('sf-ibu','Nama Ibu','cth: Sari Wulandari',s?s.im:'')}
   </div>
   ${fld('sf-kerja','Pekerjaan Orang Tua','cth: Wiraswasta',s?s.kr:'')}
   ${fld('sf-alamat','Alamat','cth: Jl. Kenanga No. 12, Ungaran',s?s.al:'')}
   <div class="frow2">
    ${fld('sf-telp','Telepon / WA','cth: 0812-3456-7890',s?s.tl:'')}
    ${fld('sf-asal','Asal Sekolah','cth: TK Pertiwi',s?s.asal:'')}
   </div>
   <div class="fld" style="margin-top:12px"><label>Angkatan / Tahun Ajaran Masuk</label><select id="sf-masuk">${taList().map(t=>`<option ${(s&&s.masuk?s.masuk:state.ta)===t?'selected':''}>${t}</option>`).join('')}</select>
    <p style="font-size:11px;color:var(--tx3);margin-top:4px">Menentukan tahun ajaran tempat siswa ini tampil. Gunakan bila ada data lama yang perlu dipindah tahunnya.</p></div>
   <div class="sect" style="margin-top:14px">Keterangan Mutasi / Pindah <span style="color:var(--tx3);font-weight:400">(opsional)</span></div>
   <div class="frow2">
    <div class="fld"><label>Status Mutasi</label><select id="sf-mut"><option value="">— bukan siswa mutasi —</option><option value="Masuk" ${s&&s.mutasi&&s.mutasi.jenis==='Masuk'?'selected':''}>Mutasi Masuk (pindahan dari sekolah lain)</option><option value="Keluar" ${s&&s.mutasi&&s.mutasi.jenis==='Keluar'?'selected':''}>Mutasi Keluar (pindah ke sekolah lain)</option></select></div>
    ${fld('sf-mutket','Keterangan (sekolah & no. surat)','cth: Pindahan dari SDN 2 Brebes · surat no. 421/012/VI/2026',s&&s.mutasi?s.mutasi.ket:'')}
   </div>
   <p style="font-size:11.5px;color:var(--tx3);line-height:1.5;margin-top:4px">Dokumen mutasi (surat pindah/keterangan) dapat diunggah pada lembar Buku Induk siswa — kolom “Dokumen Mutasi”.</p>
   <div style="display:flex;gap:9px;margin-top:6px;flex-wrap:wrap">
    <button class="btn pri" data-siswasave><i data-lucide="user-plus"></i>${s?'Simpan Perubahan':'Simpan Siswa'}</button>
    <button class="btn ghost" data-drclose>Batal</button>
   </div>
  </div>`);
}
function saveSiswa(){
 const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
 const n=v('sf-nama');
 if(!n){toast('Lengkapi dulu: Nama','info');return;}
 const rec={n,nis:v('sf-nis')||('—'),nisn:v('sf-nisn')||'—',k:v('sf-kelas')||'—',jk:v('sf-jk')||'L',
  ttl:v('sf-ttl')||'—',ag:v('sf-agama')||'—',ak:+v('sf-ak')||0,ib:v('sf-ayah')||'—',im:v('sf-ibu')||'—',
  kr:v('sf-kerja')||'—',al:v('sf-alamat')||'—',tl:v('sf-telp')||'',asal:v('sf-asal')||'—'};
 const mj=v('sf-mut'),mk=v('sf-mutket');
 rec.mutasi=(mj||mk)?{jenis:mj||'',ket:mk||''}:(SISWA_EDIT?(SISWA.find(x=>x.sp===SISWA_EDIT)||{}).mutasi:undefined);
 rec.masuk=v('sf-masuk')||(SISWA_EDIT?(SISWA.find(x=>x.sp===SISWA_EDIT)||{}).masuk:state.ta);
 if(SISWA_EDIT){const i=SISWA.findIndex(x=>x.sp===SISWA_EDIT);if(i>=0){rec.sp=SISWA_EDIT;rec.riwayat=SISWA[i].riwayat;SISWA[i]=rec;}}
 else{rec.sp='s'+Date.now()+Math.floor(Math.random()*1000);SISWA.push(rec);state.spp[rec.sp]=state.spp[rec.sp]||{l:false};}
 closeDrawer(); navigate(state.page||'dsiswa'); requestSave();
 toast(SISWA_EDIT?'Data siswa diperbarui: '+n:'Siswa baru tercatat: '+n,'graduation-cap');
}
function kelasDkList(){const list=siswaTA();const ks=[...new Set(list.map(s=>classForYear(s,state.ta)))].sort();return ks.map(k=>({k,n:list.filter(s=>classForYear(s,state.ta)===k)}));}
function updDk(){const sel=document.getElementById('dk-kelas');if(!sel)return;const k=sel.value.split(' — ')[0];const names=siswaTA().filter(s=>classForYear(s,state.ta)===k);
 const lb=document.getElementById('dk-label');if(lb)lb.textContent=k;
 const box=document.getElementById('dk-nama');if(box)box.innerHTML='<b style="font-size:12px;color:var(--tx3)">Siswa yang akan dihapus ('+names.length+'):</b><div style="margin-top:4px;line-height:1.6">'+(names.length?names.map(s=>esc2(s.n)).join(', '):'—')+'</div>';}
function delKelasForm(){const ks=kelasDkList();
 if(!ks.length){toast('Tidak ada siswa pada TA '+state.ta+'.','info');return;}
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:#c227361c;color:#c22736;border:1px solid #c227363d"><i data-lucide="trash-2"></i></span>
   <div><b>Hapus per Kelas</b><span class="sub">hapus banyak siswa sekaligus — TA ${esc2(state.ta)}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   <div class="fld"><label>Pilih kelas</label><select id="dk-kelas">${ks.map(o=>`<option>${o.k} — ${o.n.length} siswa</option>`).join('')}</select></div>
   <div id="dk-nama" style="margin-top:10px;padding:10px 12px;background:var(--bg3);border:1px dashed var(--line2);border-radius:10px;font-size:13px"></div>
   <p style="font-size:12px;color:#c22736;margin-top:10px"><b>Perhatian:</b> semua siswa kelas terpilih akan dihapus permanen beserta rapor & dokumen mereka, dan tidak bisa dibatalkan.</p>
   <div class="frow" style="margin-top:14px">
    <button class="btn ghost" data-drclose>Batal</button>
    <button class="btn dng" data-delkelasgo><i data-lucide="trash-2"></i>Hapus Semua Siswa Kelas <span id="dk-label"></span></button>
   </div>
  </div>`);
 const sel=document.getElementById('dk-kelas'); if(sel){sel.addEventListener('change',updDk);updDk();}}
function delKelasGo(){const sel=document.getElementById('dk-kelas');if(!sel)return;const k=sel.value.split(' — ')[0];
 const targets=siswaTA().filter(s=>classForYear(s,state.ta)===k);
 if(!targets.length){toast('Tidak ada siswa di kelas '+k+'.','info');return;}
 if(!confirm('Hapus '+targets.length+' siswa kelas '+k+' (TA '+state.ta+') beserta rapor & dokumennya?\n\nTindakan ini permanen dan tidak bisa dibatalkan.'))return;
 targets.forEach(s=>{const i=SISWA.findIndex(x=>x.sp===s.sp);if(i>=0)SISWA.splice(i,1);delete state.spp[s.sp];delete state.rapor[s.sp];delete state.uploads.siswa[s.sp];if(state.ijazah)delete state.ijazah[s.sp];
  if(state.raporBerkas)Object.keys(state.raporBerkas).forEach(key=>{if(key.split('|')[0]===s.sp)delete state.raporBerkas[key];});
  if(state.ijazahBerkas)Object.keys(state.ijazahBerkas).forEach(key=>{if(key.split('|')[0]===s.sp)delete state.ijazahBerkas[key];});});
 closeDrawer();navigate('dsiswa');requestSave();toast(targets.length+' siswa kelas '+k+' dihapus.','trash-2');}

/* ---- MOU baru / edit ---- */
function mouForm(m){
 MOU_EDIT=m?m.id:null;
 const noSug=m?m.no:'001/MOU/'+new Date().getFullYear();
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.teal}1c;color:${C.teal};border:1px solid ${C.teal}3d"><i data-lucide="handshake"></i></span>
   <div><b>${m?'Edit MOU':'MOU Baru'}</b><span class="sub">mitra, pasal ruang lingkup, dan masa berlaku</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${fld('mf-mitra','Nama Mitra','cth: PT Karya Digital Nusantara',m?m.mitra:'')}
   <div class="frow2">
    ${fld('mf-pimpinan','Nama Pimpinan','cth: Ir. Budi Hartono',m?m.pimpinan:'')}
    ${fld('mf-jabatan','Jabatan Pimpinan','cth: Direktur Utama',m?m.jabatan:'')}
   </div>
   ${fld('mf-bidang','Bidang Kerja Sama','cth: Magang & Sertifikasi',m?m.bidang:'')}
   ${fld('mf-no','Nomor MOU','',noSug)}
   <div class="frow2">
    ${fld('mf-mulai','Mulai Berlaku','cth: Januari 2026',m?m.mulai:'')}
    ${fld('mf-akhir','Berakhir','cth: Januari 2029',m?m.akhir:'')}
   </div>
   ${fldT('mf-ruang','Ruang Lingkup (satu butir per baris)','cth: Kuota magang 12 peserta didik per tahun',m?m.ruang.join('\n'):'')}
   <div style="display:flex;gap:9px;margin-top:6px;flex-wrap:wrap">
    <button class="btn pri" data-mousave><i data-lucide="handshake"></i>${m?'Simpan Perubahan':'Simpan MOU'}</button>
    <button class="btn ghost" data-drclose>Batal</button>
   </div>
  </div>`);
}
function saveMou(){
 const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
 const mitra=v('mf-mitra'), pimpinan=v('mf-pimpinan'), bidang=v('mf-bidang'), no=v('mf-no');
 const miss=[];
 if(!mitra)miss.push('Mitra'); if(!pimpinan)miss.push('Pimpinan'); if(!bidang)miss.push('Bidang'); if(!no)miss.push('Nomor');
 if(miss.length){toast('Lengkapi dulu: '+miss.join(', '),'info');return;}
 const ruang=v('mf-ruang').split('\n').map(s=>s.trim()).filter(Boolean);
 const rec={mitra,pimpinan,jabatan:v('mf-jabatan')||'Pimpinan Mitra',bidang,no,
  mulai:v('mf-mulai')||'—',akhir:v('mf-akhir')||'—',st:'Aktif',
  ruang:ruang.length?ruang:['Ruang lingkup dirinci dalam perjanjian kerja sama teknis.']};
 if(MOU_EDIT){const i=MOUD.findIndex(x=>x.id===MOU_EDIT);if(i>=0){Object.assign(MOUD[i],rec);toast('MOU '+mitra+' diperbarui.','pencil');}}
 else{rec.id='m'+Date.now();rec.c=[C.sky,C.peri,C.green,C.amber,C.teal,C.lilac][MOUD.length%6];MOUD.push(rec);toast('MOU dengan '+mitra+' tersimpan — klik barisnya untuk pratinjau & cetak.','handshake');}
 closeDrawer(); navigate('mou'); requestSave();
}

/* ---- Cetak tagihan SPP ---- */
function tagihanDoc(){
 const gel=document.getElementById('tg-gel')?document.getElementById('tg-gel').value:'1';
 const tempo=document.getElementById('tg-tempo')&&document.getElementById('tg-tempo').value.trim()?document.getElementById('tg-tempo').value.trim():'—';
 const onlyN=document.getElementById('tg-nunggak')?document.getElementById('tg-nunggak').checked:true;
 const list=siswaTA().filter(s=>!onlyN||!(state.spp[s.sp]&&state.spp[s.sp].l));
 const rows=list.map((s,i)=>`<tr><td>${i+1}</td><td>${esc2(s.n)}</td><td>${esc2(classForYear(s,state.ta))}</td><td>Rp ${sppAmount().toLocaleString('id-ID')}</td><td>${state.spp[s.sp]&&state.spp[s.sp].l?'LUNAS':'BELUM BAYAR'}</td></tr>`).join('');
 return paper(kop()+`
  <div class="doc-t">DAFTAR TAGIHAN SPP — GELOMBANG ${esc2(gel)}<br><span class="small">Tahun Pelajaran ${state.ta} · jatuh tempo ${esc2(tempo)}</span></div>
  <table class="dt"><thead><tr><th style="width:30px">No</th><th>Nama Peserta Didik</th><th>Kelas</th><th>Nominal</th><th>Status</th></tr></thead><tbody>${rows||'<tr><td colspan="5">Tidak ada siswa pada saringan ini.</td></tr>'}</tbody></table>
  <p>Pembayaran dilakukan melalui Bendahara Sekolah pada jam kerja atau transfer ke rekening resmi sekolah dengan konfirmasi bukti pembayaran.</p>`+ttdKepsek());
}
function tagihanDrawer(){
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.green}1c;color:${C.green};border:1px solid ${C.green}3d"><i data-lucide="printer"></i></span>
   <div><b>Cetak Tagihan SPP</b><span class="sub">pratinjau daftar tagihan sebelum dicetak</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   <div class="frow2">
    <div class="fld"><label>Gelombang</label><select id="tg-gel"><option value="1" selected>Gelombang 1</option><option value="2">Gelombang 2</option></select></div>
    ${fld('tg-tempo','Jatuh Tempo','cth: 10 Oktober 2026')}
   </div>
   <label class="ck" style="margin:2px 0 10px"><input type="checkbox" id="tg-nunggak" checked><span>Hanya siswa yang belum membayar</span></label>
   <div id="tg-prev"></div>
   <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap">
    <button class="btn pri" data-tgprint><i data-lucide="printer"></i>Cetak Tagihan</button>
    <button class="btn ghost" data-drclose>Tutup</button>
   </div>
  </div>`);
 renderTagihan();
}
function renderTagihan(){
 const el=document.getElementById('tg-prev'); if(!el) return;
 el.innerHTML=tagihanDoc();
}

/* ---- Ajukan berkas kenaikan pangkat ---- */
function ajukanDrawer(){
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.gold}1c;color:${C.gold};border:1px solid ${C.gold}3d"><i data-lucide="trending-up"></i></span>
   <div><b>Ajukan Berkas Kenaikan Pangkat</b><span class="sub">status berubah menjadi “Diajukan ke SimPEG”</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   ${PANGKAT.length?`<div class="fld"><label>Pegawai</label><select id="aj-sub">${PANGKAT.map((p,i)=>`<option value="${i}">${esc2(p.n)} — ${esc2(p.g)} → ${esc2(p.t)}</option>`).join('')}</select></div>
   ${fld('aj-cat','Catatan Kelengkapan Berkas','cth: SKP dua tahun terakhir lengkap')}
   <p style="font-size:12px;color:var(--tx3);margin-bottom:12px;line-height:1.5">Pengajuan akan mencatat tanggal hari ini dan memperbarui status pada tabel Kenaikan Pangkat.</p>`
   :'<p style="font-size:13px;color:var(--tx3);line-height:1.6">Belum ada usulan kenaikan pangkat. Tambahkan lewat formulir ini setelah data guru terisi.</p>'+fld('aj-nama','Nama Guru','cth: Siti Nurhaliza, S.Pd.')}
   <div style="display:flex;gap:9px;flex-wrap:wrap">
    <button class="btn pri" data-ajsave><i data-lucide="send"></i>Kirim Pengajuan</button>
    <button class="btn ghost" data-drclose>Batal</button>
   </div>
  </div>`);
}
function saveAjukan(){
 const subEl=document.getElementById('aj-sub');
 if(subEl){
  const p=PANGKAT[+subEl.value]; if(!p) return;
  p.s='Diajukan ke SimPEG';
  p.y=new Date().toLocaleDateString('id-ID',{month:'short',year:'numeric'});
  toast('Pengajuan kenaikan pangkat '+p.n.split(',')[0]+' terkirim ke SimPEG.','send');
 }else{
  const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
  const n=v('aj-nama'); if(!n){toast('Lengkapi dulu: Nama','info');return;}
  PANGKAT.push({n,g:'—',t:'—',y:new Date().toLocaleDateString('id-ID',{month:'short',year:'numeric'}),s:'Berkas Disiapkan'});
  toast('Usulan kenaikan pangkat '+n+' dicatat.','trending-up');
 }
 closeDrawer(); navigate('pangkat'); requestSave();
}

/* ================= Rapor berkelanjutan (Kelas 1–6) ================= */
const MAPEL_SD=['Pendidikan Agama & Budi Pekerti','Pendidikan Pancasila','Bahasa Indonesia','Matematika','Seni Budaya','Bahasa Inggris','PJOK'];
const rapAvg=rec=>{if(!rec||!rec.nilai||!rec.nilai.length)return null;return Math.round(rec.nilai.reduce((a,[,v])=>a+v,0)/rec.nilai.length);};
function rapCards(s){
 const R=state.rapor[s.sp]||{};
 let cards='';
 for(let k=1;k<=6;k++){
  const r1=R[k]&&R[k][1], r2=R[k]&&R[k][2];
  const a1=rapAvg(r1), a2=rapAvg(r2);
  const avg=a1&&a2?Math.round((a1+a2)/2):(a1||a2);
  const bars=[1,2,3,4,5,6].map(b=>{const bb=R[b]?[rapAvg(R[b][1]),rapAvg(R[b][2])].filter(Boolean):[];const v=bb.length?bb.reduce((x,y)=>x+y,0)/bb.length:0;return `<i style="height:${v?Math.max(12,(v-60))*2.2:3}%" title="Kelas ${b}${v?' · rata-rata '+Math.round(v):''}"></i>`;}).join('');
  cards+=`<button class="rap-card" data-rapdet="${s.sp}|${k}">
   <b>Kelas ${k}</b><span class="ravg">${avg||'—'}</span>
   <div class="rap-sem"><span class="sb ${r1?'ok':''}" title="${r1?'Semester 1 sudah ada rapor':'Semester 1 belum ada rapor'}">S1 ${r1?'✓ '+(a1||'berkas'):'·'}</span><span class="sb ${r2?'ok':''}" title="${r2?'Semester 2 sudah ada rapor':'Semester 2 belum ada rapor'}">S2 ${r2?'✓ '+(a2||'berkas'):'·'}</span></div>
   ${k===1?`<div class="rap-bar">${bars}</div>`:''}
  </button>`;
 }
 return cards;
}
function renderRapDet(sp,k){
 const el=document.getElementById('rap-det'); if(!el) return;
 const R=(state.rapor[sp]||{})[k];
 document.querySelectorAll('.rap-card').forEach((c,i)=>c.classList.toggle('on',i===k-1));
 if(!R||(!R[1]&&!R[2])){el.innerHTML=`<div class="rap-det"><h4><i data-lucide="info" style="width:14px;height:14px"></i>Kelas ${k} — belum ada rapor tersimpan.</h4><p style="font-size:12px;color:var(--tx3)">Unggah rapor PDF lewat tombol di bawah; sistem membaca kelas & semester lalu mengisi rekaman ini otomatis.</p></div>`;lucide.createIcons();return;}
 const semB=sem=>{const rec=R[sem]; if(!rec) return '';
  const a=rapAvg(rec);
  return `<h4><i data-lucide="book-open" style="width:14px;height:14px;color:var(--accent)"></i>Semester ${sem} · TA ${esc2(rec.tahun||rec.ta||'—')} · rata-rata <b style="color:var(--accent)">${a||'—'}</b></h4>
  <table><thead><tr><th>Mata Pelajaran</th><th style="width:70px">Nilai Akhir</th></tr></thead>
  <tbody>${(rec.nilai||[]).map(([m,v])=>`<tr><td>${esc2(m)}</td><td class="mono">${v}</td></tr>`).join('')||'<tr><td colspan="2">Nilai tidak terbaca (berkas scan?) — berkas asli tetap tersimpan & bisa dicetak.</td></tr>'}</tbody></table>
  <p style="font-size:12px;color:var(--tx2)"><b>Ketidakhadiran:</b> sakit ${rec.kehadiran?rec.kehadiran.sakit||0:0} · izin ${rec.kehadiran?rec.kehadiran.izin||0:0} · alfa ${rec.kehadiran?rec.kehadiran.alfa||0:0} hari</p>
  ${rec.catatan?`<p style="font-size:12px;color:var(--tx2);margin-top:5px"><b>Catatan wali kelas:</b> ${esc2(rec.catatan)}</p>`:''}
  <p style="font-size:11px;color:var(--tx3);margin-top:5px">Berkas: ${esc2(rec.file||'—')}${rec.tgl?' · diunggah '+esc2(rec.tgl):''}${rec.nama&&rec.nama!==SISWA.find(x=>x.sp===sp)?.n?' · nama pada PDF: '+esc2(rec.nama):''}</p>
  ${rec.besar?'<p style="font-size:11px;color:var(--tx3);margin-top:3px">PDF asli terlalu besar untuk disimpan di browser — nilai tetap tersimpan; simpan berkas asli di arsip sekolah.</p>':''}
  <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">${(rec.data||(rec.berkas&&state.raporBerkas[rec.berkas]))?`<button class="btn ghost" data-rapprint="${sp}|${k}|${sem}"><i data-lucide="file-text"></i>Cetak Rapor Asli (PDF)</button>`:''}${canEdit()?`<button class="btn ghost rapdel" data-rapdel="${sp}|${k}|${sem}"><i data-lucide="trash-2"></i>Hapus Rapor Ini</button>`:''}</div>`;};
 el.innerHTML=`<div class="rap-det">${semB(1)}${semB(2)||'<p style="font-size:12px;color:var(--tx3)">Semester 2 belum diunggah.</p>'}</div>`;
 lucide.createIcons();
}
function bersihkanBerkas(){
 const dipakai=new Set();
 for(const sp in state.rapor){const R=state.rapor[sp];
  for(const k in R)for(const sem in R[k]){const b=R[k][sem]&&R[k][sem].berkas;if(b)dipakai.add(b);}}
 for(const key of Object.keys(state.raporBerkas)) if(!dipakai.has(key)) delete state.raporBerkas[key];
}
function rapDel(sp,k,sem){
 const R=(state.rapor[sp]||{})[k];
 if(!R||!R[sem]){toast('Rekaman rapor tidak ditemukan.','info');return;}
 if(!confirm('Hapus rekaman rapor kelas '+k+' semester '+sem+' ini? Data yang dihapus tidak bisa dikembalikan.')) return;
 delete R[sem];
 if(!Object.keys(state.rapor[sp][k]).length) delete state.rapor[sp][k];
 if(!Object.keys(state.rapor[sp]).length) delete state.rapor[sp];
 bersihkanBerkas(); requestSave();
 if(state.page==='induk') navigate('induk');
 const s=SISWA.find(x=>x.sp===sp); if(s) indukDrawer(s);
 toast('Rapor kelas '+k+' semester '+sem+' dihapus. Unggah ulang bila ada berkas yang benar.','trash-2');
}
function rapWipes(sp){
 if(!state.rapor[sp]||!Object.keys(state.rapor[sp]).length){toast('Siswa ini belum punya rekaman rapor.','info');return;}
 if(!confirm('Hapus SEMUA rekaman rapor siswa ini (seluruh kelas & semester)? Tindakan ini tidak bisa dibatalkan.')) return;
 delete state.rapor[sp]; bersihkanBerkas(); requestSave();
 if(state.page==='induk') navigate('induk');
 const s=SISWA.find(x=>x.sp===sp); if(s) indukDrawer(s);
 toast('Semua rapor siswa ini dihapus — silakan unggah ulang.','trash-2');
}
function printRaporAsli(sp,k,sem){
 const rec=((state.rapor[sp]||{})[k]||{})[sem];
 const data=rec&&(rec.data||(rec.berkas?state.raporBerkas[rec.berkas]:null));
 if(!data){toast('Berkas PDF asli tidak tersimpan untuk rekaman ini (berkas terlalu besar / cadangan lama).','info');return;}
 try{
  const bin=atob(data.split(',')[1]);
  const arr=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);
  const url=URL.createObjectURL(new Blob([arr],{type:'application/pdf'}));
  const w=window.open(url,'_blank');
  toast('Rapor asli dibuka di jendela baru — cetak langsung dari sana (Ctrl+P). Dokumen identik dengan PDF yang diunggah.','printer');
  if(w&&w.addEventListener) w.addEventListener('afterprint',()=>setTimeout(()=>URL.revokeObjectURL(url),2000));
 }catch(e){toast('Gagal membuka PDF rapor.','alert-triangle');}
}
async function parseRaporPDF(dataUrl){
 const bin=atob(dataUrl.split(',')[1]);
 const arr=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);
 const doc=await pdfjsLib.getDocument({data:arr}).promise;
 let text='';
 for(let p=1;p<=Math.min(doc.numPages,40);p++){
  const pg=await doc.getPage(p); const tc=await pg.getTextContent();
  text+=tc.items.map(i=>i.str).join('\n')+'\n';
 }
 return extractRapor(text);
}
function extractRapor(text){
 /* pecah PDF rapor menjadi SATU REKAMAN PER MURID (berdasar NIS/NISN) */
 const chunks=String(text).split(/(?=Nama Murid)/).filter(c=>c.includes('Nama Murid'));
 const recs=[]; let cur=null, curNis=null;
 for(const ch of chunks){
  const nm=ch.match(/NIS\/NISN\s*:\s*([\d./\s]+)/);
  const nis=nm?nm[1].replace(/\s+/g,' ').trim():null;
  if(!cur||(nis&&nis!==curNis)){cur={text:ch};recs.push(cur);curNis=nis;}
  else cur.text+=ch;
 }
 const out=[];
 for(const r0 of recs){
  const rc=r0.text;
  const km=rc.match(/Kelas\s*:\s*Kelas\s*(\d)/);
  if(!km) continue;
  const sm=rc.match(/Semester\s*:\s*\n?\s*(\d)/);
  const tm=rc.match(/Tahun Ajaran\s*:\s*\n?\s*(\d{4}\/\d{4})/);
  const fm=rc.match(/Kelas \d[A-Z]?\s*\|\s*([^|\n]+)/);
  const um=rc.match(/\n([A-Z][A-Z .'’-]{5,})\nNIS/i);
  const nama=fm?fm[1].trim():(um?um[1].trim():'');
  const lines=rc.split('\n').map(l=>l.trim());
  const HEAD=new Set(['No','Mata Pelajaran','Nilai Akhir','Capaian Kompetensi','Kokurikuler','Ekstrakurikuler','Keterangan','Ketidakhadiran','Catatan Wali Kelas','Tanggapan Orang Tua/Wali Murid','Orang Tua Murid','Kepala Sekolah','Wali Kelas','LAPORAN HASIL BELAJAR','Kelompok A','Kelompok B','Kelas','Fase','Sekolah','Semester','Alamat','Tahun Ajaran','Pamengger','Nama','Nama Murid','NIS/NISN']);
  let last=null; const nilai=[]; const done={};
  for(let i=0;i<lines.length;i++){
   const l=lines[i];
   if(/^\d{1,2}$/.test(l)&&i+1<lines.length&&/^\d{2,3}$/.test(lines[i+1])&&last){nilai.push([last,+lines[i+1]]);done[last]=1;i++;continue;}
   if(/^dan /.test(l)&&last&&!done[last]){last+=' '+l;continue;}
   if(l.length>3&&!HEAD.has(l)&&/^[A-Z][A-Za-z& ,'’.\/()-]+$/.test(l)&&!/Mencapai|Perlu|NIP|Ananda|Kompetensi|Pelajar|antara lain/.test(l)&&!/^[A-Z\s.'’-]+$/.test(l)){
    if(last&&!done[last]) last+=' '+l; else last=l;
   }
  }
  const cm=rc.match(/Catatan Wali Kelas\s*\n([\s\S]*?)\s*Tanggapan/);
  const ks=rc.match(/Sakit\s*:\s*(\d*)\s*hari/), ki=rc.match(/Izin\s*:\s*(\d*)\s*hari/), ka=rc.match(/Tanpa Keterangan\s*:\s*(\d*)\s*hari/);
  out.push({kelas:+km[1],sem:sm?+sm[1]:1,tahun:tm?tm[1]:'',nama,
   nilai,kehadiran:{sakit:ks?+(ks[1]||0):0,izin:ki?+(ki[1]||0):0,alfa:ka?+(ka[1]||0):0},
   catatan:cm?cm[1].replace(/\n/g,' ').trim():''});
 }
 /* buang duplikat (nama+kelas+semester sama) — pertahankan yang nilainya terbanyak */
 const ded={};
 for(const r of out){
  const k=(r.nama||'?')+'|'+r.kelas+'|'+r.sem;
  if(!ded[k]||(r.nilai.length>ded[k].nilai.length)) ded[k]=r;
 }
 const arr=Object.values(ded);
 return arr.length?arr:null;
}

function indukSheet(s){
 const f=getUp('siswa',s.sp,'foto');
 return paper(kop()+`
  <div class="doc-t">LEMBAR BUKU INDUK PESERTA DIDIK<br><span class="small">Nomor Induk: ${esc2(s.nis)} · NISN: ${esc2(s.nisn)}</span></div>
  <table style="width:100%;border-collapse:collapse"><tr>
   <td style="width:70%;vertical-align:top;padding-right:16px">
    ${drow('Nama Peserta Didik','<b>'+esc2(s.n)+'</b>')}
    ${drow('Tempat, Tanggal Lahir',esc2(s.ttl))}
    ${drow('Jenis Kelamin',s.jk==='L'?'Laki-laki':'Perempuan')}
    ${drow('Agama',esc2(s.ag))}
    ${drow('Anak ke-',String(s.ak||'—'))}
    ${drow('Asal Sekolah',esc2(s.asal))}
   ${s.mutasi&&s.mutasi.jenis?drow('Keterangan Mutasi',esc2(s.mutasi.jenis==='Masuk'?'Mutasi masuk':'Mutasi keluar')+(s.mutasi.ket?' — '+esc2(s.mutasi.ket):'')+(getUp('siswa',s.sp,'mutasi')?' Dokumen mutasi terlampir pada arsip digital.':'')):''}
    ${drow('Nama Ayah',esc2(s.ib))}
    ${drow('Nama Ibu',esc2(s.im))}
    ${drow('Pekerjaan Orang Tua',esc2(s.kr))}
    ${drow('Alamat',esc2(s.al))}
    ${drow('Telepon',esc2(s.tl||'—'))}
    ${drow('Kelas Saat Ini',esc2(s.k))}
   </td>
   <td style="width:30%;vertical-align:top;text-align:center">
    ${f&&f.img?`<img src="${f.data}" style="width:120px;height:150px;object-fit:cover;border:1px solid #555">`:'<div style="width:120px;height:150px;border:1px dashed #777;display:inline-grid;place-items:center;font-size:10px;color:#777">FOTO<br>3 × 4</div>'}
    <div style="font-size:9px;margin-top:4px;color:#555">Pasfoto terbaru</div>
   </td></tr></table>
  <p style="margin-top:14px"><b>Catatan:</b> ${getUp('siswa',s.sp,'kk')?'Berkas Kartu Keluarga terlampir pada arsip digital.':'Kartu Keluarga belum diunggah ke arsip digital.'} ${getUp('siswa',s.sp,'akte')?'Berkas Akte Kelahiran terlampir pada arsip digital.':'Akte Kelahiran belum diunggah ke arsip digital.'}</p>`+ttdKepsek());
}
function printInduk(s){printDoc(indukSheet(s));}
function transkripDoc(s){
 const R=state.rapor[s.sp]||{};
 const mapel=[];
 for(let k=1;k<=6;k++)for(let sem=1;sem<=2;sem++){const rec=R[k]&&R[k][sem];if(rec)(rec.nilai||[]).forEach(([m])=>{if(!mapel.includes(m))mapel.push(m);});}
 const cell=(m,k)=>{const vals=[];for(let sem=1;sem<=2;sem++){const rec=R[k]&&R[k][sem];if(rec){const f=(rec.nilai||[]).find(([mm])=>mm===m);if(f)vals.push(f[1]);}}
  return vals.length?Math.round(vals.reduce((a,b)=>a+b,0)/vals.length):'—';};
 const tblA=mapel.map(m=>`<tr><td>${escX(m)}</td>${[1,2,3,4,5,6].map(k=>`<td style="text-align:center">${cell(m,k)}</td>`).join('')}</tr>`).join('');
 const tblB=[1,2,3,4,5,6].map(k=>{
  const r1=R[k]&&R[k][1], r2=R[k]&&R[k][2];
  const a1=rapAvg(r1), a2=rapAvg(r2);
  const th=a1&&a2?Math.round((a1+a2)/2):(a1||a2);
  const abs=(r1&&r1.kehadiran?r1.kehadiran.sakit+r1.kehadiran.izin+r1.kehadiran.alfa:0)+(r2&&r2.kehadiran?r2.kehadiran.sakit+r2.kehadiran.izin+r2.kehadiran.alfa:0);
  return `<tr><td style="text-align:center"><b>${k}</b></td><td style="text-align:center">${a1||'—'}</td><td style="text-align:center">${a2||'—'}</td><td style="text-align:center"><b>${th||'—'}</b></td><td style="text-align:center">${abs}</td></tr>`;
 }).join('');
 return paper(kop()+`
  <div class="doc-t">TRANSKRIP HASIL BELAJAR — REKAP RAPOR<br><span class="small">Rekaman berkelanjutan Kelas 1 s.d. 6</span></div>
  ${drow('Nama Peserta Didik','<b>'+esc2(s.n)+'</b>')}
  ${drow('NIS / NISN',esc2(s.nis)+' / '+esc2(s.nisn))}
  ${drow('Tempat, Tanggal Lahir',esc2(s.ttl))}
  <table class="dt"><thead><tr><th>Mata Pelajaran</th>${[1,2,3,4,5,6].map(k=>`<th style="text-align:center">Kelas ${k}</th>`).join('')}</tr></thead>
  <tbody>${tblA||'<tr><td colspan="7">Belum ada data rapor.</td></tr>'}</tbody></table>
  <table class="dt"><thead><tr><th style="width:60px">Kelas</th><th>Rata-rata Smt 1</th><th>Rata-rata Smt 2</th><th>Rata-rata Tahun</th><th>Tidak Hadir (hari)</th></tr></thead>
  <tbody>${tblB}</tbody></table>
  <p style="font-size:10.5px">Nilai per mata pelajaran merupakan rata-rata Semester 1 dan 2 pada tahun ajaran bersangkutan; tanda "—" berarti rapor pada kelas tersebut belum diunggah.</p>`+ttdKepsek());
}
function cetakJilid(){
 if(!SISWA.length){toast('Belum ada siswa di buku induk.','info');return;}
 printDoc(SISWA.map(s=>indukSheet(s)).join(''));
 toast('Jilid buku induk ('+SISWA.length+' lembar) dikirim ke dialog cetak.','book-marked');
}

/* ================= Kenaikan kelas ================= */
const nextKelas=k=>{
 const m=String(k).match(/^(\d+)(.*)$/);
 if(!m) return String(k);
 const n=+m[1];
 return n>=6?'LULUS':String(n+1)+m[2];
};
function pushRiwayat(s,dari,ke){
 (s.riwayat=s.riwayat||[]).push({ta:state.ta,tgl:tglIndo(),dari,ke});
 if(s.riwayat.length>12) s.riwayat=s.riwayat.slice(-12);
}
function naikkanKelas(){
 const dariEl=document.getElementById('nk-dari'), keEl=document.getElementById('nk-ke');
 const dari=dariEl?dariEl.value:''; if(!dari){toast('Pilih kelas asal dulu.','info');return;}
 const ke=(keEl&&keEl.value.trim())?keEl.value.trim():nextKelas(dari);
 let n=0;
 siswaTA().forEach(s=>{if(classForYear(s,state.ta)===dari){pushRiwayat(s,dari,ke);s.k=ke;n++;}});
 if(!n){toast('Tidak ada siswa di kelas '+dari+' pada TA '+state.ta+'.','info');return;}
 state.naikLog.push({ta:state.ta,tgl:tglIndo(),ket:'Kelas '+dari+' → '+ke,n});
 requestSave(); navigate('naik');
 toast(n+' siswa kelas '+dari+' dinaikkan menjadi '+ke+' (mulai TA berikutnya).','arrow-up-circle');
}
function prosesNaik(){
 let n=0, tidak=0;
 document.querySelectorAll('[data-naikck]').forEach(ck=>{
  const sp=ck.dataset.naikck; const s=SISWA.find(x=>x.sp===sp); if(!s) return;
  const toEl=document.querySelector('[data-naikto="'+sp+'"]');
  const dari=classForYear(s,state.ta);
  const ke=toEl?toEl.value.trim():nextKelas(dari);
  if(ck.checked&&ke&&ke!==dari){pushRiwayat(s,dari,ke);s.k=ke;n++;}
  else if(!ck.checked) tidak++;
 });
 if(!n&&!tidak){toast('Tidak ada perubahan yang dipilih.','info');return;}
 state.naikLog.push({ta:state.ta,tgl:tglIndo(),ket:'Kenaikan per siswa ('+n+' naik'+(tidak?', '+tidak+' tetap':'')+')',n});
 requestSave(); navigate('naik');
 toast(n+' siswa dinaikkan'+(tidak?', '+tidak+' siswa tidak naik':'')+'.','arrow-up-circle');
}
function naikAutoIsi(){
 document.querySelectorAll('[data-naikto]').forEach(el=>{
  const s=SISWA.find(x=>x.sp===el.dataset.naikto); if(s) el.value=nextKelas(classForYear(s,state.ta));
 });
 toast('Kelas tujuan diisi otomatis (+1; kelas 6 → LULUS).','wand-2');
}

/* ---- Lingkup siswa per tahun ajaran aktif: tahun yang belum diisi tampil kosong ---- */
const yi=t=>{const m=String(t||'').match(/^(\d{4})/);return m?+m[1]:0;};
const tahunMasukS=s=>yi(s.masuk||state.ta);
function yearEndS(s){
 const ri=s.riwayat||[]; const E=tahunMasukS(s);
 const lulus=ri.filter(r=>r.ke==='LULUS').map(r=>yi(r.ta));
 if(lulus.length) return Math.max(...lulus);
 return Math.max(E,...ri.map(r=>yi(r.ta)+1));
}
const enrolledIn=(s,T)=>{const y=yi(T);return y>=tahunMasukS(s)&&y<=yearEndS(s);};
const siswaTA=()=>SISWA.filter(s=>enrolledIn(s,state.ta));
function classForYear(s,T){
 const ri=s.riwayat||[]; const hit=ri.find(r=>r.ta===T); if(hit) return hit.dari;
 const after=ri.filter(r=>yi(r.ta)>yi(T)).length;
 if(!after) return s.k;
 const m=String(s.k).match(/^(\d+)(.*)$/); if(!m) return s.k;
 return String(Math.max(1,+m[1]-after))+m[2];
}

/* ---- Unggah rapor: pecah PDF per nama siswa & distribusikan otomatis ---- */
const normNama=s=>String(s||'').toUpperCase().replace(/[^A-Z]/g,'');
function matchSiswaByName(nama){
 const t=normNama(nama); if(!t) return null;
 const pool=siswaTA(); /* utamakan siswa pada TA aktif agar tidak nyangkut ke tahun lain */
 return pool.find(s=>normNama(s.n)===t)||pool.find(s=>{const a=normNama(s.n);return a.length>5&&t.length>5&&(a.includes(t)||t.includes(a));})
  ||SISWA.find(s=>normNama(s.n)===t)||SISWA.find(s=>{const a=normNama(s.n);return a.length>5&&t.length>5&&(a.includes(t)||t.includes(a));})||null;
}
function distributeRapor(recs,preferSp,dataUrl,f){
 const simpan=(s,rec,berkasKey)=>{
  state.rapor[s.sp]=state.rapor[s.sp]||{};
  const k=(rec.kelas>=1&&rec.kelas<=6)?rec.kelas:0;
  state.rapor[s.sp][k]=state.rapor[s.sp][k]||{};
  const rec2=Object.assign({},rec,{file:f.name,tgl:tglIndo(),ta:state.ta});
  if(!rec2.nama) rec2.nama=s.n;
  if(berkasKey) rec2.berkas=berkasKey;
  state.rapor[s.sp][k][rec.sem||1]=rec2;
  return s;
 };
 if(!recs||!recs.length){
  const s=preferSp?SISWA.find(x=>x.sp===preferSp):null;
  if(!s){toast('Rapor tidak terbaca otomatis dan tidak ada siswa terpilih.','info');return;}
  let berkasKey=null;
  if(dataUrl&&f.size<=3145728){berkasKey='b'+Date.now();state.raporBerkas[berkasKey]=dataUrl;}
  simpan(s,{kelas:0,sem:1,tahun:state.ta,nilai:[],kehadiran:{sakit:0,izin:0,alfa:0},catatan:'',besar:!berkasKey&&f.size>3145728},berkasKey);
  toast('Rapor '+s.n+' tersimpan sebagai berkas (nilai tidak terbaca otomatis).','file-text');
  requestSave(); if(state.page==='induk')navigate('induk'); if(drawerRedraw)drawerRedraw();
  return;
 }
 /* PDF kelas (banyak siswa): berkas asli disimpan SEKALI & dipakai semua nama */
 let berkasKey=null;
 const terlaluBesar=f.size>3145728;
 if(dataUrl&&!terlaluBesar){berkasKey='b'+Date.now();state.raporBerkas[berkasKey]=dataUrl;}
 /* unggah dari tombol PER-SISWA dan PDF hanya memuat 1 murid → wajib jatuh ke siswa itu (anti tertukar) */
 if(preferSp&&recs.length===1){
  const s=SISWA.find(x=>x.sp===preferSp);
  if(s){
   simpan(s,recs[0],berkasKey);
   requestSave(); if(state.page==='induk')navigate('induk'); if(drawerRedraw)drawerRedraw();
   const nb=berkasKey?'':' (PDF asli terlalu besar untuk disimpan — nilai tetap tersimpan)';
   toast('Rapor kelas '+recs[0].kelas+' semester '+(recs[0].sem||1)+' tersimpan untuk '+s.n+nb+'.','scan-line');
   return;
  }
 }
 let n=0; const gagal=[]; const dipakai=new Set();
 for(const rec of recs){
  const s=matchSiswaByName(rec.nama);
  if(s){simpan(s,rec,berkasKey);dipakai.add(s.sp);n++;}
  else gagal.push(rec.nama||'(tanpa nama)');
 }
 /* unggahan dari tombol per-siswa: pastikan jatuh ke siswa tersebut */
 if(preferSp&&!dipakai.has(preferSp)){
  const s=SISWA.find(x=>x.sp===preferSp);
  if(s&&recs.length){
   const sisa=recs.find(r=>!matchSiswaByName(r.nama))||recs[0];
   simpan(s,sisa,berkasKey); dipakai.add(preferSp); n++;
   const gi=gagal.indexOf(sisa.nama); if(gi>=0)gagal.splice(gi,1);
  }
 }
 requestSave();
 if(state.page==='induk') navigate('induk');
 if(drawerRedraw) drawerRedraw();
 const nb=berkasKey?'':' (PDF asli terlalu besar untuk disimpan — nilai tetap tersimpan)';
 if(n===1){
  const s=SISWA.find(x=>dipakai.has(x.sp));
  toast('Rapor tersimpan untuk '+(s?s.n:'1 siswa')+' sesuai nama pada PDF'+nb+'.','scan-line');
 }else if(n>1){
  toast(n+' rapor tersimpan otomatis — satu PDF dibagi per nama siswa'+nb+(gagal.length?'. Tidak cocok: '+gagal.slice(0,3).join(', ')+(gagal.length>3?'…':''):'.'),'scan-line');
 }else{
  toast('Tidak ada nama pada PDF yang cocok dengan data siswa'+(gagal.length?': '+gagal.slice(0,3).join(', '):'')+'. Periksa ejaan di Data Siswa atau pilih siswa secara manual.','info');
 }
}
function pickRaporGlobal(){
 if(!SISWA.length){toast('Belum ada data siswa — isi Data Siswa dulu sebelum mengunggah rapor.','info');return;}
 const inp=document.createElement('input'); inp.type='file'; inp.accept='application/pdf';
 inp.onchange=()=>{
  const f=inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=async()=>{
   let recs=null;
   if(window.pdfjsLib){ try{recs=await parseRaporPDF(r.result);}catch(e){} }
   const selEl=document.getElementById('rg-sub');
   const selVal=selEl?selEl.value:'auto';
   const prefer=(selVal&&selVal!=='auto')?selVal:null;
   distributeRapor(recs,prefer,r.result,f);
  };
  r.readAsDataURL(f);
 };
 inp.click();
}

/* ================= PPDB daring ================= */
function fmtTglPPDB(iso){
 const m=String(iso||'').match(/^(\d{4})-(\d{2})-(\d{2})/);
 return m?m[3]+'-'+m[2]+'-'+m[1]:'—';
}
function serapPpdbInbox(){
 let box=[];
 try{box=JSON.parse(localStorage.getItem('prima-ppdb-inbox')||'[]');}catch(e){return;}
 if(!Array.isArray(box)||!box.length) return;
 let n=0;
 for(const e of box){
  if(!e||!e.reg||state.ppdb.some(x=>x.reg===e.reg)) continue;
  e.sp='pp'+Date.now()+'_'+n; e.status=e.status||'Baru'; e.ta=e.ta||state.ta; n++;
  state.ppdb.push(e);
 }
 if(n){
  try{
   const pub=JSON.parse(localStorage.getItem('prima-ppdb-pub')||'{}');
   for(const x of state.ppdb){ if(!pub[x.reg]) pub[x.reg]={reg:x.reg,n:x.n,jk:x.jk,tlahir:x.tlahir,tgl:x.tgl,asal:x.asal,ib:x.ib,im:x.im,hp:x.hp,tglDaftar:x.tglDaftar,berkas:x.berkas?{akte:{name:x.berkas.akte&&x.berkas.akte.name},kk:{name:x.berkas.kk&&x.berkas.kk.name}}:null}; }
   localStorage.setItem('prima-ppdb-pub',JSON.stringify(pub));
  }catch(e){}
  try{localStorage.removeItem('prima-ppdb-inbox');}catch(e){} requestSave();
 }
}
function tulisStatusPublik(reg,s){
 try{
  const m=JSON.parse(localStorage.getItem('prima-ppdb-status')||'{}');
  m[reg]={s,ket:'diperbarui '+tglIndo()};
  localStorage.setItem('prima-ppdb-status',JSON.stringify(m));
 }catch(e){}
}
function tampilRecovery(kode){
 const o=document.getElementById('recOvl'); if(!o) return;
 document.getElementById('rec-key').textContent=kode;
 o.classList.add('show'); lucide.createIcons();
 const cp=document.getElementById('rec-copy');
 if(cp&&!cp.__w){cp.__w=true;cp.addEventListener('click',()=>{try{navigator.clipboard&&navigator.clipboard.writeText(kode);}catch(e){} const r=document.createRange();r.selectNode(document.getElementById('rec-key'));const s=getSelection();s.removeAllRanges();s.addRange(r);toast('Kode pemulihan disalin / diblok — salin dengan Ctrl+C.','copy');});}
 const pr=document.getElementById('rec-print');
 if(pr&&!pr.__w){pr.__w=true;pr.addEventListener('click',()=>{
  const ps=document.getElementById('printSheet');
  ps.innerHTML=paper(kop()+`
   <div style="text-align:center;margin:16px 0 4px"><b style="font-size:16px;text-decoration:underline;letter-spacing:.5px">KARTU PEMULIHAN DATA PRIMA</b><div style="font-size:11px;margin-top:3px;color:#555">Dokumen rahasia — berlaku sebagai kunci cadangan pembuka data terenkripsi</div></div>
   <p style="font-size:12.5px;line-height:1.7;margin-top:12px">Kartu ini diterbitkan pada <b>${tglIndo()}</b> bersamaan dengan diaktifkannya enkripsi data aplikasi PRIMA sekolah ini. Apabila frasa sandi terlupa, kode berikut merupakan <b>satu-satunya pintu lain</b> pembuka data (berlaku di komputer mana pun):</p>
   <div style="border:2px dashed #0d2b4e;border-radius:10px;padding:14px 8px;text-align:center;font-family:Consolas,monospace;font-size:21px;letter-spacing:1.5px;margin:14px 0;color:#0d2b4e;background:#f7f9ff">${esc2(kode)}</div>
   <p style="font-size:11.5px;line-height:1.7;color:#333">Simpan kartu ini sebagaimana dokumen penting sekolah (map brankas / arsip pimpinan). Jangan bagikan kepada siapa pun. Bila diduga bocor: nonaktifkan enkripsi lalu aktifkan kembali untuk menerbitkan kode baru.</p>
   `+ttdKepsek());
  window.print(); setTimeout(()=>{ps.innerHTML='';},800);
 });}
 const dn=document.getElementById('rec-done');
 if(dn&&!dn.__w){dn.__w=true;dn.addEventListener('click',()=>o.classList.remove('show'));}
}
function aktifEnkripsi(){
 if(!(window.primaFS&&window.primaFS.setEnc)){toast('Enkripsi tersedia pada aplikasi desktop (.exe).','info');return;}
 const p1=(document.getElementById('enc-pass').value||'').trim(),p2=(document.getElementById('enc-pass2').value||'').trim();
 if(p1.length<6){toast('Frasa sandi minimal 6 karakter.','info');return;}
 if(p1!==p2){toast('Konfirmasi frasa sandi tidak sama.','info');return;}
 const rem=(document.getElementById('enc-remember')||{}).checked||false;
 const json=JSON.stringify(Object.assign(collectSave(),{t:Date.now()}));
 window.primaFS.setEnc(true,p1,rem,json).then(res=>{
  if(res&&res.ok){ window.__PRIMA_FS_INFO=Object.assign(window.__PRIMA_FS_INFO||{},{encrypted:true});
   catatLog('Enkripsi data DIAKTIFKAN'+(res.recovery?' + kunci pemulihan diterbitkan':''));
   toast('Enkripsi aktif — berkas data kini tersamar AES-256.','shield-check'); navigate('backup');
   if(res.recovery) tampilRecovery(res.recovery); }
  else toast((res&&res.error)||'Gagal mengaktifkan enkripsi.','alert-triangle');
 });
}
function matiEnkripsi(){
 if(!(window.primaFS&&window.primaFS.setEnc)){toast('Enkripsi tersedia pada aplikasi desktop (.exe).','info');return;}
 const p1=(document.getElementById('enc-pass').value||'').trim();
 const json=JSON.stringify(Object.assign(collectSave(),{t:Date.now()}));
 window.primaFS.setEnc(false,p1,false,json).then(res=>{
  if(res&&res.ok){ window.__PRIMA_FS_INFO=Object.assign(window.__PRIMA_FS_INFO||{},{encrypted:false});
   catatLog('Enkripsi data DINONAKTIFKAN'); toast('Enkripsi dimatikan — berkas kembali terbaca biasa.','lock-open'); navigate('backup'); }
  else toast((res&&res.error)||'Gagal mematikan enkripsi.','alert-triangle');
 });
}
function waPendaftar(sp){
 const p=state.ppdb.find(x=>x.sp===sp); if(!p) return;
 let hp=String(p.hp||'').replace(/\D/g,'');
 if(hp.startsWith('0')) hp='62'+hp.slice(1); else if(hp.startsWith('8')) hp='62'+hp;
 if(!hp||hp.length<10){toast('Nomor HP pendaftar tidak lengkap — periksa detailnya.','info');return;}
 const sek=state.sekolah.nama||'sekolah kami';
 const msg='Yth. Bapak/Ibu wali dari '+p.n+' — kabar dari panitia PPDB '+sek+': status pendaftaran No. '+p.reg+' saat ini adalah *'+p.status+'*. Terima kasih telah mendaftar.';
 window.open('https://wa.me/'+hp+'?text='+encodeURIComponent(msg),'_blank');
 catatLog('Kirim WA status '+p.status+' untuk '+p.n);
}
function setStatusPpdb(sp,s){
 const p=state.ppdb.find(x=>x.sp===sp); if(!p) return;
 p.status=s; tulisStatusPublik(p.reg,s); kirimStatusServer(p.reg,s); kirimStatusGas(p.reg,s);
 requestSave(); navigate('ppdb');
 toast('Status '+p.n+' → '+s+'.','clipboard-check');
}
/* ---- PPDB mode jaringan lokal (server.js) ---- */
function ppdbServerBase(){
 const v=(state.ppdbServer||'').trim();
 if(v) return v.replace(/\/+$/,'');
 return location.protocol.startsWith('http')?location.origin:'';
}
async function kirimStatusServer(reg,s){
 const base=ppdbServerBase(); if(!base) return;
 try{await fetch(base+'/ppdb-status',{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({reg,s})});}catch(e){}
}
let _ppdbPulling=false;
async function netPullPpdb(silent){
 const base=ppdbServerBase();
 if(!base){if(!silent)toast('Isi dulu alamat server PPDB di bilah halaman ini (contoh: http://192.168.1.10:8080).','info');return;}
 if(_ppdbPulling)return; _ppdbPulling=true;
 try{
  const r=await fetch(base+'/ppdb-queue?x='+Date.now(),{cache:'no-store'}); if(!r.ok)throw new Error('http');
  const arr=await r.json(); if(!Array.isArray(arr))throw new Error('format');
  let n=0; const regs=[];
  for(const e of arr){
   if(!e||!e.reg)continue; regs.push(e.reg);
   if(state.ppdb.some(x=>x.reg===e.reg))continue;
   e.sp='pp'+Date.now()+'_'+n; e.status=e.status||'Baru'; e.ta=e.ta||state.ta; n++;
   state.ppdb.push(e);
  }
  if(regs.length){try{await fetch(base+'/ppdb-ack',{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({regs})});}catch(e){}}
  /* sinkronkan semua status agar bisa dicek pendaftar dari perangkatnya */
  for(const p of state.ppdb){kirimStatusServer(p.reg,p.status);}
  if(n){requestSave();navigate('ppdb');toast(n+' pendaftaran baru ditarik dari server jaringan.','inbox');}
  else if(!silent)toast('Tidak ada pendaftaran baru di server.','info');
 }catch(e){ if(!silent)toast('Gagal terhubung ke server PPDB — periksa alamatnya dan pastikan komputer ini satu jaringan dengan server.','alert-triangle'); }
 finally{_ppdbPulling=false;}
}
/* ---- PPDB mode internet (Google Apps Script) ---- */
async function kirimStatusGas(reg,s){
 const base=(state.gasUrl||'').trim(); if(!base) return;
 try{await fetch(base,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action:'status',reg,s})});}catch(e){}
}
let _gasPulling=false;
async function netPullGas(silent){
 const base=(state.gasUrl||'').trim();
 if(!base){if(!silent)toast('Isi dulu alamat Google Apps Script di kolom sebelahnya.','info');return;}
 if(_gasPulling)return; _gasPulling=true;
 try{
  const r=await fetch(base+(base.includes('?')?'&':'?')+'action=queue&x='+Date.now(),{cache:'no-store'}); if(!r.ok)throw new Error('http');
  const arr=await r.json(); if(!Array.isArray(arr))throw new Error('format');
  let n=0; const regs=[];
  for(const e of arr){
   if(!e||!e.reg)continue; regs.push(e.reg);
   if(state.ppdb.some(x=>x.reg===e.reg))continue;
   e.sp='pp'+Date.now()+'_'+n; e.status=e.status||'Baru'; e.ta=e.ta||state.ta; n++;
   state.ppdb.push(e);
  }
  if(regs.length){try{await fetch(base,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action:'ack',regs})});}catch(e){}}
  if(n){requestSave();navigate('ppdb');toast(n+' pendaftaran baru ditarik dari cloud (Google).','inbox');}
  else if(!silent)toast('Tidak ada pendaftaran baru di cloud.','info');
 }catch(e){ if(!silent)toast('Gagal terhubung ke Google Apps Script ('+(e&&e.message?e.message:e)+'). Coba klik “Tes Koneksi” di sebelahnya, dan pastikan komputer ini bisa membuka Google.','alert-triangle'); }
 finally{_gasPulling=false;}
}
async function tesKoneksiGas(){
 const base=(state.gasUrl||'').trim();
 if(!base){toast('Isi dulu alamat Google Apps Script di kolom sebelahnya.','info');return;}
 toast('Menguji koneksi ke Google Apps Script…','cloud');
 try{
  const r=await fetch(base+(base.includes('?')?'&':'?')+'action=status&x='+Date.now(),{cache:'no-store'});
  const t=await r.text();
  let keterangan='';
  try{const j=JSON.parse(t);keterangan=Array.isArray(j)?'daftar status diterima':(j&&j.app?j.app:'balasan JSON valid');}catch(e){}
  if(r.ok&&keterangan)toast('TERHUBUNG ✅ (HTTP '+r.status+') '+keterangan+' — sekarang klik “Tarik dari Cloud”.','cloud');
  else toast('Server membalas tapi tidak wajar: HTTP '+r.status+' — '+(t.slice(0,80)||'balasan kosong'),'alert-triangle');
 }catch(e){
  toast('TIDAK TERHUBUNG ❌ '+(e&&e.message?e.message:e)+' — periksa internet komputer ini; coba juga buka URL Google itu di browser komputer ini.','alert-triangle');
 }
}
function terimaPpdb(sp){
 const p=state.ppdb.find(x=>x.sp===sp); if(!p) return;
 if(p.status!=='Lulus'){toast('Tetapkan status “Lulus” dahulu sebelum diterima ke Data Siswa.','info');return;}
 if(SISWA.some(s=>normNama(s.n)&&normNama(s.n)===normNama(p.n))){toast('Nama ini sudah ada di Data Siswa.','info');return;}
 const rec={n:p.n,nis:'—',nisn:p.nisn||'—',k:'1A',jk:p.jk||'L',ttl:(p.tlahir||'—')+', '+fmtTglPPDB(p.tgl),
  ag:p.ag||'—',ak:+p.ak||0,ib:p.ib||'—',im:p.im||'—',kr:p.kr||'—',
  al:(p.al||'—')+(p.kota?', '+p.kota:''),tl:p.hp||'',em:p.em||'',asal:p.asal||'—',masuk:state.ta,sp:'s'+Date.now()};
 SISWA.push(rec); state.spp[rec.sp]=state.spp[rec.sp]||{l:false};
 const U=state.uploads.siswa[rec.sp]=state.uploads.siswa[rec.sp]||{};
 if(p.berkas&&p.berkas.akte&&p.berkas.akte.data) U.akte={name:p.berkas.akte.name,size:p.berkas.akte.size,data:'data:'+(p.berkas.akte.type||'application/pdf')+';base64,'+p.berkas.akte.data,img:String(p.berkas.akte.type||'').startsWith('image')};
 if(p.berkas&&p.berkas.kk&&p.berkas.kk.data) U.kk={name:p.berkas.kk.name,size:p.berkas.kk.size,data:'data:'+(p.berkas.kk.type||'application/pdf')+';base64,'+p.berkas.kk.data,img:String(p.berkas.kk.type||'').startsWith('image')};
 p.diterima=rec.sp;
 requestSave(); closeDrawer(); navigate('ppdb');
 toast(p.n+' diterima & tercatat di Data Siswa — kelas 1A, angkatan '+state.ta+'. Akte & KK ikut terlampir.','user-plus');
}
function hapusPpdb(sp){
 const p=state.ppdb.find(x=>x.sp===sp); if(!p) return;
 if(!confirm('Hapus pendaftaran '+p.n+' ('+p.reg+')?')) return;
 state.ppdb=state.ppdb.filter(x=>x.sp!==sp);
 requestSave(); closeDrawer(); navigate('ppdb');
 toast('Pendaftaran dihapus.','trash-2');
}
function ppdbDrawer(p){
 const berkasLink=(b,label)=>b?(b.data?`<a href="data:${b.type||'application/pdf'};base64,${b.data}" target="_blank" rel="noopener" style="color:var(--accent);font-weight:600">${label}: ${esc2(b.name)}</a>`:`<span>${label}: ${esc2(b.name)} (isi berkas tidak tersimpan lokal)</span>`):`<span style="color:var(--tx3)">${label}: —</span>`;
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.teal}1c;color:${C.teal};border:1px solid ${C.teal}3d"><i data-lucide="clipboard-list"></i></span>
   <div><b>${esc2(p.n)}</b><span class="sub">${esc2(p.reg)} · daftar ${esc2(String(p.tglDaftar||'').slice(0,10))}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   <div class="kvlist">${kvlist([
    ['Jenis Kelamin',p.jk==='P'?'Perempuan':'Laki-laki'],['Tempat, Tgl Lahir',esc2(p.tlahir||'—')+', '+fmtTglPPDB(p.tgl)],
    ['Agama',esc2(p.ag||'—')],['Anak ke-',esc2(p.ak||'—')],['Asal TK',esc2(p.asal||'—')],
    ['Alamat',esc2((p.al||'—')+(p.kota?', '+p.kota:'')+(p.pos?' '+p.pos:''))],
    ['Nama Ayah',esc2(p.ib||'—')],['Nama Ibu',esc2(p.im||'—')],['Pekerjaan',esc2(p.kr||'—')],
    ['HP / WA','<span class="mono">'+esc2(p.hp||'—')+'</span>'],['Email',esc2(p.em||'—')]])}</div>
   <div class="kvlist" style="margin-top:8px">${kvlist([['Berkas',berkasLink(p.berkas&&p.berkas.akte,'Akte')+'<br>'+berkasLink(p.berkas&&p.berkas.kk,'KK')]])}</div>
   <div class="frow2" style="margin-top:12px">
    <div class="fld"><label>Status Seleksi</label><select data-ppst="${p.sp}">${['Baru','Lulus','Cadangan','Ditolak'].map(s=>`<option ${p.status===s?'selected':''}>${s}</option>`).join('')}</select></div>
   </div>
   <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:12px">
    <button class="btn pri" data-ppterima="${p.sp}"><i data-lucide="user-plus"></i>Terima ke Data Siswa</button>
    ${canEdit()?`<button class="btn ghost rapwipe" data-ppdel="${p.sp}"><i data-lucide="trash-2"></i>Hapus Pendaftaran</button>`:''}
   </div>
   <p style="font-size:11.5px;color:var(--tx3);margin-top:10px">“Terima ke Data Siswa” membuatkan siswa kelas 1A angkatan ${state.ta} lengkap dengan lampiran Akte & KK; status juga terbaca di halaman cek status milik orang tua.</p>
  </div>`,()=>ppdbDrawer(p));
}

/* ================= Ijazah Kelas 6 / Lulusan ================= */
function extractIjazahNama(text){
 const t=String(text); const out=[]; let m;
 const re=/(?:^|\n)[^\n]{0,40}?(?:NAMA|Nama)\s*[:]\s*([A-Z][A-Z .'’,\-]{3,60})/g;
 while((m=re.exec(t))) out.push(m[1].trim());
 if(!out.length){const re2=/Nama\s*:\s*([A-Z][A-Z .'’,\-]{3,60})/gi; while((m=re2.exec(t))) out.push(m[1].trim());}
 const seen={}; const ded=[];
 for(const o of out){const k=normNama(o); if(k&&!seen[k]){seen[k]=1;ded.push(o);}}
 return ded.length?ded:null;
}
function bersihIjazahBerkas(){
 const dipakai=new Set();
 for(const sp in state.ijazah){const b=state.ijazah[sp]&&state.ijazah[sp].berkas; if(b) dipakai.add(b);}
 for(const key of Object.keys(state.ijazahBerkas)) if(!dipakai.has(key)) delete state.ijazahBerkas[key];
}
function simpanIjazah(s,f,berkasKey){
 const rec={file:f.name,tgl:tglIndo(),ta:state.ta};
 if(berkasKey) rec.berkas=berkasKey;
 state.ijazah[s.sp]=rec;
}
function distributeIjazah(namaList,preferSp,dataUrl,f){
 let berkasKey=null;
 if(dataUrl&&f.size<=3145728){berkasKey='b'+Date.now()+Math.floor(Math.random()*999);state.ijazahBerkas[berkasKey]=dataUrl;}
 const pool=siswaTA().concat(SISWA.filter(x=>!enrolledIn(x,state.ta)));
 const cari=nm=>pool.find(x=>normNama(x.n)===normNama(nm))||pool.find(x=>{const a=normNama(x.n),b=normNama(nm);return a.length>5&&b.length>5&&(a.includes(b)||b.includes(a));});
 let n=0; const gagal=[];
 if(preferSp&&namaList&&namaList.length===1){
  const s=SISWA.find(x=>x.sp===preferSp); if(s){simpanIjazah(s,f,berkasKey);n++;}
 }else{
  (namaList||[]).forEach(nm=>{const s=cari(nm); if(s){simpanIjazah(s,f,berkasKey);n++;} else gagal.push(nm);});
  if(preferSp&&n===0){const s=SISWA.find(x=>x.sp===preferSp); if(s){simpanIjazah(s,f,berkasKey);n++;}}
 }
 requestSave(); if(state.page==='induk') navigate('induk'); if(drawerRedraw) drawerRedraw();
 const nb=berkasKey?'':' (PDF terlalu besar untuk disimpan utuh — cetak asli dinonaktifkan)';
 if(n>0) toast(n+' ijazah tersimpan'+(namaList&&namaList.length>1?' — dibagi per nama siswa':'')+nb+(gagal.length?'. Nama tak cocok: '+gagal.slice(0,3).join(', ')+(gagal.length>3?'…':''):'.'),'graduation-cap');
 else if(!namaList||!namaList.length) toast('Nama pada PDF ijazah tidak terbaca — unggah lewat tombol di lembar siswa agar jatuh ke siswa yang benar.','info');
 else toast('Tidak ada nama pada PDF yang cocok dengan data siswa.','info');
}
async function parseIjazahPDF(dataUrl){
 const bin=atob(dataUrl.split(',')[1]); const arr=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);
 const doc=await pdfjsLib.getDocument({data:arr}).promise; let text='';
 for(let p=1;p<=Math.min(doc.numPages,10);p++){const pg=await doc.getPage(p); const tc=await pg.getTextContent(); text+=tc.items.map(i=>i.str).join('\n')+'\n';}
 return extractIjazahNama(text);
}
function bacaFileDataURL(f){return new Promise(res=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>res(null);r.readAsDataURL(f);});}
function pickIjazahGlobal(){
 if(!SISWA.length){toast('Belum ada data siswa — isi Data Siswa dulu.','info');return;}
 const inp=document.createElement('input'); inp.type='file'; inp.accept='application/pdf'; inp.multiple=true;
 inp.onchange=async()=>{
  const files=[...inp.files]; if(!files.length) return;
  for(const f of files){
   const dataUrl=await bacaFileDataURL(f);
   let nama=null;
   if(dataUrl&&window.pdfjsLib){try{nama=await parseIjazahPDF(dataUrl);}catch(e){}}
   const selEl=document.getElementById('ij-sub'); const sv=selEl?selEl.value:'auto';
   distributeIjazah(nama,(sv&&sv!=='auto')?sv:null,dataUrl,f);
  }
 };
 inp.click();
}
function pickIjazahSp(sp){
 const inp=document.createElement('input'); inp.type='file'; inp.accept='application/pdf';
 inp.onchange=async()=>{
  const f=inp.files[0]; if(!f) return;
  const dataUrl=await bacaFileDataURL(f);
  let nama=null;
  if(dataUrl&&window.pdfjsLib){try{nama=await parseIjazahPDF(dataUrl);}catch(e){}}
  distributeIjazah(nama,sp,dataUrl,f);
  const s=SISWA.find(x=>x.sp===sp); if(s&&drawerRedraw) drawerRedraw();
 };
 inp.click();
}
function printIjazahAsli(sp){
 const rec=state.ijazah[sp];
 const data=rec&&(rec.data||(rec.berkas?state.ijazahBerkas[rec.berkas]:null));
 if(!data){toast('Berkas ijazah asli tidak tersimpan (PDF terlalu besar / data lama).','info');return;}
 try{
  const bin=atob(data.split(',')[1]);
  const arr=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);
  const url=URL.createObjectURL(new Blob([arr],{type:'application/pdf'}));
  const w=window.open(url,'_blank');
  toast('Ijazah asli dibuka di jendela baru — cetak langsung (Ctrl+P). Identik dengan PDF yang diunggah.','printer');
  if(w&&w.addEventListener) w.addEventListener('afterprint',()=>setTimeout(()=>URL.revokeObjectURL(url),2000));
 }catch(e){toast('Gagal membuka PDF ijazah.','alert-triangle');}
}
function ijazahDel(sp){
 if(!state.ijazah[sp]){toast('Siswa ini belum punya ijazah tersimpan.','info');return;}
 if(!confirm('Hapus rekaman ijazah siswa ini? Berkas asli tetap bisa diunggah ulang.')) return;
 delete state.ijazah[sp]; bersihIjazahBerkas(); requestSave();
 if(state.page==='induk') navigate('induk');
 const s=SISWA.find(x=>x.sp===sp); if(s) indukDrawer(s);
 toast('Ijazah dihapus.','trash-2');
}
const isK6=s=>/^6/.test(String(classForYear(s,state.ta)))||String(s.k).toUpperCase()==='LULUS';

/* ================= Navigasi ================= */
const contentEl=document.getElementById('content'), crumbEl=document.getElementById('crumb');
function navigate(id){
 const leaf=LEAF[id]; if(!leaf) return;
 state.page=id;
 if(leaf.parent) state.open=leaf.parent;
 document.documentElement.style.setProperty('--accent',leaf.c);
 document.querySelectorAll('.nav-group').forEach(g=>{
  g.classList.toggle('open',g.dataset.g===state.open);
  g.classList.toggle('has-active',leaf.parent===g.dataset.g);
 });
 crumbEl.innerHTML=leaf.parent
  ?`<span>${NAVMAP[leaf.parent].label}</span><span class="csep"><i data-lucide="chevron-right"></i></span><span class="cur">${leaf.label}</span>`
  :`<span class="cur">${leaf.label}</span>`;
 contentEl.innerHTML=PAGES[id]();
 lucide.createIcons();
 countUp(contentEl);
 if(id==='roadmap') updateDeliv(true);
 if(id==='penomoran'){renderKpick(state.naskah.kode);updateNaskah();renderAgenda();}
 if(id==='klasifikasi') applyRows('tb-klas');
 if(id==='aguru'&&GURU.length){const cnt={Hadir:0,Izin:0,Sakit:0,Alfa:0};GURU.forEach((g,i)=>cnt[state.abs[i]||'Hadir']++);for(const k in cnt){const el=document.getElementById('ac-'+k);if(el)el.textContent=cnt[k];}}
 if(id==='ppdb'){netPullPpdb(true);if((state.gasUrl||'').trim())netPullGas(true);}
 if(id==='profil'||id==='backup'){try{
  const kb=(JSON.stringify(collectSave()).length/1024).toFixed(0)+' KB dari ±5.000 KB';
  const a=document.getElementById('store-kb'); if(a)a.textContent=kb;
  const b=document.getElementById('bk-size'); if(b)b.textContent=kb;
 }catch(e){}}
 contentEl.scrollTop=0;
 document.body.classList.remove('sbopen');
}
function buildNav(){
 document.getElementById('snav').innerHTML=NAV.map(n=>{
  if(n.children) return `<div class="nav-group" data-g="${n.id}">
   <button class="nav-item" data-group="${n.id}"><span class="ni-ic" style="background:${n.c||'#8fa3d8'}26;color:${n.c||'#8fa3d8'}"><i data-lucide="${n.icon}"></i></span><span>${n.label}</span><i data-lucide="chevron-down" class="chev"></i></button>
   <div class="submenu">${n.children.map(c=>`<button class="sub-item" data-go="${c.id}"><span class="si-ic" style="color:${c.c}"><i data-lucide="${c.icon}"></i></span><span>${c.label}</span></button>`).join('')}</div>
  </div>`;
  return `<button class="nav-item ${n.push?'push':''}" data-go="${n.id}"><span class="ni-ic" style="background:${n.c||'#8fa3d8'}26;color:${n.c||'#8fa3d8'}"><i data-lucide="${n.icon}"></i></span><span>${n.label}</span></button>`;
 }).join('');
}
function toggleGroup(k){
 state.open=state.open===k?null:k;
 document.querySelectorAll('.nav-group').forEach(g=>g.classList.toggle('open',g.dataset.g===state.open));
}
function buildTaSel(){
 const sel=document.getElementById('ta-sel'); if(!sel) return;
 const opts=taList(); if(!opts.includes(state.ta)) opts.push(state.ta);
 sel.innerHTML=opts.map(t=>`<option ${t===state.ta?'selected':''}>${t}</option>`).join('');
}

/* ================= Filter, ekspor, cetak ================= */
function applyRows(scope){
 const root=document.getElementById(scope); if(!root) return;
 const q=(root.dataset.q||'').toLowerCase(), f=root.dataset.fval||'';
 let vis=0,total=0;
 root.querySelectorAll('.frow').forEach(r=>{
  const okQ=!q||r.textContent.toLowerCase().includes(q);
  const okF=!f||r.dataset.fval===f;
  r.style.display=okQ&&okF?'':'none';
  total++; if(okQ&&okF) vis++;
 });
 const cEl=document.getElementById(scope+'-cnt');
 if(cEl) cEl.textContent=(q||f)?`${vis} / ${total} kode ditampilkan`:`${total} kode`;
}
function arsipFilter(){
 const root=document.getElementById('tb-surat'); if(!root) return;
 const q=(root.dataset.q||'').toLowerCase();
 const f=root.dataset.fval||'';
 const taSel=document.getElementById('arsip-ta'); const ta=taSel?taSel.value:'';
 root.querySelectorAll('.frow').forEach(r=>{
  const okQ=!q||r.textContent.toLowerCase().includes(q);
  const okF=!f||r.dataset.jenis===f;
  const okT=!ta||r.dataset.ta===ta;
  r.style.display=okQ&&okF&&okT?'':'none';
 });
 root.querySelectorAll('.tahead').forEach(h=>{
  const grupTa=h.dataset.ta||'';
  if(ta&&grupTa!==ta){h.style.display='none';return;}
  const adaVis=[...root.querySelectorAll('.frow')].some(r=>(r.dataset.ta||'')===grupTa&&r.style.display!=='none');
  h.style.display=adaVis?'':'none';
 });
}
function printDoc(html){
 const ps=document.getElementById('printSheet');
 ps.innerHTML='<div class="psheet">'+html+'</div>';
 const done=()=>{ps.innerHTML='';window.removeEventListener('afterprint',done);};
 window.addEventListener('afterprint',done);
 window.print();
}

/* ================= Interaksi halaman ================= */
function cycleAbs(i){
 const nx=ABS_ORDER[(ABS_ORDER.indexOf(state.abs[i]||'Hadir')+1)%4];
 state.abs[i]=nx;
 document.querySelector('[data-cycle="'+i+'"]').outerHTML=badgeBtn(nx,i);
 const cnt={Hadir:0,Izin:0,Sakit:0,Alfa:0};
 GURU.forEach((g,ix)=>cnt[state.abs[ix]||'Hadir']++);
 for(const k in cnt){const el=document.getElementById('ac-'+k); if(el) el.textContent=cnt[k];}
 toast('Kehadiran '+GURU[i].n.split(',')[0].replace('Drs. ','')+' → '+nx,'user-check');
 requestSave();
}
function paySpp(key){
 state.spp[key]=state.spp[key]||{l:false};
 const s=state.spp[key]; if(s.l) return;
 s.l=true;
 document.getElementById('sb-'+key).innerHTML=badge('Lunas',C.green);
 document.getElementById('sa-'+key).innerHTML='<span style="color:var(--tx3);font-size:12px;display:inline-flex;align-items:center;gap:6px"><i data-lucide="check" style="width:13px;height:13px"></i>Lunas</span>';
 lucide.createIcons();
 const tt=document.getElementById('sp-total'); if(tt) tt.textContent=rp(sppTerkumpul());
 const left=document.getElementById('sp-left'); if(left) left.textContent=Math.max(0,siswaTA().filter(x=>!(state.spp[x.sp]&&state.spp[x.sp].l)).length);
 const sn=SISWA.find(x=>x.sp===key);
 toast('Pembayaran '+(sn?sn.n:'siswa')+' dicatat — '+rp(sppAmount()),'receipt');
 requestSave();
}
function updateDeliv(silent){
 document.querySelectorAll('.phase').forEach(p=>{
  const cks=[...p.querySelectorAll('[data-deliv]')]; if(!cks.length) return;
  const done=cks.filter(c=>c.checked).length, id=p.querySelector('.ph-count').id.slice(3);
  document.getElementById('pc-'+id).textContent=done+'/'+cks.length;
  document.getElementById('pg-'+id).style.width=(done/cks.length*100)+'%';
  document.getElementById('pp-'+id).textContent=Math.round(done/cks.length*100)+'%';
 });
 const all=[...document.querySelectorAll('[data-deliv]')];
 const pct=all.length?Math.round(all.filter(c=>c.checked).length/all.length*100):0;
 const ob=document.getElementById('ov-bar'); if(ob) ob.style.width=pct+'%';
 const op=document.getElementById('ov-pct'); if(op) op.textContent=pct+'%';
 if(!silent) toast('Kemajuan peta jalan diperbarui.','flag');
 requestSave();
}

/* ================= Count-up & toast ================= */
function countUp(root){
 root.querySelectorAll('[data-count]').forEach(el=>{
  const target=parseFloat(el.dataset.count), dec=+(el.dataset.dec||0);
  const pre=el.dataset.pre||'', suf=el.dataset.suf||'', t0=performance.now(), dur=900;
  (function f(t){
   const p=Math.min(1,(t-t0)/dur), v=target*(1-Math.pow(1-p,3));
   el.textContent=pre+v.toLocaleString('id-ID',{minimumFractionDigits:dec,maximumFractionDigits:dec})+suf;
   if(p<1&&typeof requestAnimationFrame==='function') requestAnimationFrame(f);
  })(t0);
 });
}
function toast(msg,icon='check'){
 const el=document.createElement('div'); el.className='toast';
 el.innerHTML='<i data-lucide="'+icon+'"></i><span>'+msg+'</span>';
 document.getElementById('toasts').appendChild(el);
 lucide.createIcons();
 if(typeof requestAnimationFrame==='function') requestAnimationFrame(()=>el.classList.add('in')); else el.classList.add('in');
 setTimeout(()=>{el.classList.remove('in'); setTimeout(()=>el.remove(),320)},2800);
}

/* ================= Palet perintah ================= */
const povl=document.getElementById('povl'), pin=document.getElementById('pal-in'), plist=document.getElementById('pal-list');
const CMDS=Object.values(LEAF).map(l=>({id:l.id,label:l.label,group:l.parent?NAVMAP[l.parent].label:'Utama',icon:l.icon}));
let palItems=[], palSel=0;
function renderPal(q){
 const ql=q.toLowerCase();
 const base=CMDS.filter(c=>(c.label+' '+c.group).toLowerCase().includes(ql)).map(c=>Object.assign({},c));
 const extra=[];
 if(ql.length>=2){
  SISWA.forEach(s=>{if((s.n+' '+s.nis+' '+s.k).toLowerCase().includes(ql))extra.push({id:'dsiswa',label:s.n+' · '+s.k+' · NIS '+s.nis,group:'Siswa',icon:'graduation-cap',scope:'tb-sis',pq:s.n});});
  GURU.forEach(g=>{if((g.n+' '+g.m).toLowerCase().includes(ql))extra.push({id:'dguru',label:g.n+' · '+g.m,group:'Guru',icon:'users',scope:'tb-guru',pq:g.n});});
  KLASIFIKASI.forEach(([k,u])=>{if(extra.length<46&&(k+' '+u).toLowerCase().includes(ql))extra.push({id:'penomoran',label:k+' — '+u.slice(0,64),group:'Klasifikasi',icon:'folder-tree',pk:k});});
  state.suratAgenda.forEach(a=>{if((a.a+' '+a.p+' '+a.d).toLowerCase().includes(ql))extra.push({id:'arsip',label:a.a+' · '+a.p,group:'Agenda',icon:'mail'});});
 }
 palItems=[...base,...extra].slice(0,60);
 palSel=0;
 plist.innerHTML=palItems.length
  ?palItems.map((c,i)=>`<div class="pal-item ${i===0?'sel':''}" data-pgo="${c.id}"${c.pq?` data-pq="${attq(c.pq)}" data-scope="${c.scope}"`:''}${c.pk?` data-pk="${c.pk}"`:''}><i data-lucide="${c.icon}"></i><span>${esc2(c.label)}</span><span class="pg">${c.group}</span></div>`).join('')
  :'<div class="pal-empty">Tidak ada halaman yang cocok.</div>';
 lucide.createIcons();
}
function openPal(){povl.classList.add('show'); pin.value=''; renderPal(''); setTimeout(()=>pin.focus(),30);}
function closePal(){povl.classList.remove('show');}
function palMove(d){
 if(!palItems.length) return;
 palSel=(palSel+d+palItems.length)%palItems.length;
 plist.querySelectorAll('.pal-item').forEach((el,i)=>el.classList.toggle('sel',i===palSel));
 plist.querySelector('.pal-item.sel').scrollIntoView({block:'nearest'});
}
pin.addEventListener('input',()=>renderPal(pin.value));
pin.addEventListener('keydown',e=>{
 if(e.key==='ArrowDown'){e.preventDefault();palMove(1);}
 else if(e.key==='ArrowUp'){e.preventDefault();palMove(-1);}
 else if(e.key==='Enter'&&palItems[palSel]){navigate(palItems[palSel].id);closePal();}
});

/* ================= Notifikasi & jam ================= */
function buildPop(){
 const items=[];
 if(!state.sekolah.nama) items.push({i:'school',c:C.amber,t:'Lengkapi Profil Sekolah — dipakai di semua kop surat',d:'langkah 1',go:'profil'});
 if(!GURU.length) items.push({i:'users',c:C.sky,t:'Data guru masih kosong — unduh template Excel',d:'langkah 2',go:'dguru'});
 if(!SISWA.length) items.push({i:'graduation-cap',c:C.rose,t:'Data siswa masih kosong — unduh template Excel',d:'langkah 2',go:'dsiswa'});
 if(!state.recovery) items.push({i:'key-round',c:C.lilac,t:'Kode pemulihan belum dibuat',d:'keamanan akun',go:'profil'});
 document.getElementById('pop').innerHTML=items.length
  ?items.map(n=>`<div class="pop-item" data-pgo="${n.go}">
    <span class="pop-ic" style="background:${n.c}1c;color:${n.c}"><i data-lucide="${n.i}"></i></span>
    <div><p>${n.t}</p><span>${n.d}</span></div></div>`).join('')
  :'<div class="pop-item"><span class="pop-ic" style="background:'+C.green+'1c;color:'+C.green+'"><i data-lucide="check"></i></span><div><p>Semua beres — tidak ada pengingat.</p><span>&nbsp;</span></div></div>';
}
function tick(){
 const d=new Date();
 document.getElementById('tclock').textContent=d.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).replace(/\./g,':');
 document.getElementById('tdate').textContent=d.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'short'});
}

/* ================= Delegasi event ================= */
document.addEventListener('click',e=>{
 const t=e.target;
 if(t.closest('[data-refresh]')){navigate(state.page);toast('Tampilan dimuat ulang sesuai TA '+state.ta+'.','refresh-cw');return;}
 /* gerbang peran: Guru hanya lihat (kecuali unggah rapor) */
 if(state.user&&!canEdit()){
  const up0=t.closest('[data-up]');
  const ru0=t.closest('[data-rapup]');
  if(ru0||(up0&&up0.dataset.up.split('|')[2]==='rapor')){/* peran Guru diizinkan mengunggah rapor */}
  else{
   const g=t.closest('[data-up],[data-pegsave],[data-mousave],[data-catatno],[data-pay],[data-cycle],[data-sgen],[data-sprint],[data-tgprint],[data-jilid],[data-indukprint],[data-transkrip],[data-rapprint],[data-ajsave],[data-logodel],[data-surat],[data-pegform],[data-pegedit],[data-pegdel],[data-mouform],[data-mouedit],[data-moudel],[data-tagihan],[data-ajukan],[data-dispo],[data-smform],[data-smsave],[data-smedit],[data-smdel],[data-export-x],[data-export-p],[data-xltpl],[data-xlup],[data-backup],[data-restore],[data-reset],[data-profsave],[data-pinset],[data-regen],[data-prof],[data-prof-ta],[data-siswaform],[data-siswasave],[data-siswaedit],[data-siswadel],[data-guruform],[data-gurusave],[data-guruedit],[data-gurudel],[data-naskahdel],[data-naikkan],[data-naikproses],[data-naikauto],[data-profsave],[data-pinssave],[data-rapdel],[data-rapwipes],[data-ijup],[data-ijups],[data-ijdel],[data-ppdel],[data-ppterima],[data-ppst],[data-ppwa],[data-encon],[data-encoff],[data-spmb],[data-spmbclose],[data-spmbopt],[data-spmbyes],[data-spmbtpl],[data-erup],[data-eruptpl],[data-eropt],[data-eryes],[data-erclose],[data-erview],[data-erxl],[data-erdel],[data-erviewclose]');
   if(g){toast('Peran '+state.user.role+' hanya dapat melihat data (kecuali unggah rapor).','lock-keyhole');return;}
  }
 }
 /* layar masuk */
 const lsel=t.closest('[data-lsel]'); if(lsel){
  state.loginSel=lsel.dataset.lsel;renderLoginList();
  const pinV=(document.getElementById('login-pin').value||'').trim();
  if(pinV){tryLogin();}else{toast('Peran '+lsel.dataset.lsel.toUpperCase()+' dipilih — ketik PIN lalu tekan Masuk.','log-in');}
  return;
 }
 if(t.closest('[data-login]')){tryLogin();return;}
 if(t.closest('[data-forgot]')){forgotPin();return;}
 if(t.closest('[data-fgtsave]')){saveForgot();return;}
 if(t.closest('[data-fgtclose]')){closeForgot();return;}
 if(t.closest('[data-logout]')){state.user=null;requestSave();showLogin();return;}
 const pgo=t.closest('[data-pgo]'); if(pgo){
  navigate(pgo.dataset.pgo);closePal();document.getElementById('pop').classList.remove('show');
  if(pgo.dataset.pq&&pgo.dataset.scope){
   const scope=pgo.dataset.scope, root=document.getElementById(scope);
   if(root){root.dataset.q=pgo.dataset.pq;const inp=document.querySelector('[data-search="'+scope+'"]');if(inp)inp.value=pgo.dataset.pq;applyRows(scope);}
  }
  if(pgo.dataset.pk){
   state.naskah.kode=pgo.dataset.pk;
   const si=document.getElementById('f-kode-search'); if(si)si.value=pgo.dataset.pk;
   if(state.page==='penomoran'){renderKpick(state.naskah.kode);updateNaskah();}
  }
  return;}
 const w=t.closest('[data-w]');
 if(w){const k=w.dataset.w;
  if(k==='max')document.body.classList.toggle('max');
  else if(k==='min')toast('Gunakan tombol perbesar untuk mode penuh.','info');
  else toast('Tetap di sini — masih banyak yang bisa dijelajahi.','compass');
  return;}
 const up=t.closest('[data-up]'); if(up){const[a,b,c2,acc]=up.dataset.up.split('|');pickUp(a,b,c2,acc);return;}
 const uv=t.closest('[data-upview]'); if(uv){const[a,b,c2]=uv.dataset.upview.split('|');const u=getUp(a,b,c2);
  if(u&&u.img){document.getElementById('lbimg').src=u.data;document.getElementById('lightbox').classList.add('show');}
  else toast('Pratinjau PDF tidak tersedia — berkas tersimpan.','file-text');
  return;}
 const kp=t.closest('[data-kpick]'); if(kp){const e2=KLASIFIKASI[+kp.dataset.kpick];
  if(e2){state.naskah.kode=e2[0];const si=document.getElementById('f-kode-search');if(si)si.value=e2[0];renderKpick(si?si.value:'');updateNaskah();}
  return;}
 const kc=t.closest('[data-kcopy]'); if(kc){copyText(kc.dataset.kcopy);return;}
 const cpn=t.closest('[data-copyno]'); if(cpn){copyText(nomorNaskah());return;}
 const ct=t.closest('[data-catatno]'); if(ct){catatNaskah();return;}
 const nd=t.closest('[data-naskahdel]'); if(nd){state.naskah.agenda.splice(+nd.dataset.naskahdel,1);renderAgenda();requestSave();lucide.createIcons();toast('Baris agenda dihapus.','trash-2');return;}
 if(t.closest('[data-pegform]')){pegawaiForm();return;}
 const pe=t.closest('[data-pegedit]'); if(pe){pegawaiForm(PEGAWAI[+pe.dataset.pegedit]);return;}
 const pd=t.closest('[data-pegdel]'); if(pd){if(confirm('Hapus pegawai ini?')){const p=PEGAWAI.splice(+pd.dataset.pegdel,1)[0];navigate('pegawai');requestSave();toast('Pegawai dihapus: '+(p?p.n:''),'trash-2');}return;}
 const psv=t.closest('[data-pegsave]'); if(psv){savePegawai();return;}
 if(t.closest('[data-guruform]')){guruForm();return;}
 const ge=t.closest('[data-guruedit]'); if(ge){const g=GURU.find(x=>x.nip===ge.dataset.guruedit);guruForm(g||GURU[+ge.dataset.guruedit]);return;}
 const gd=t.closest('[data-gurudel]'); if(gd){if(confirm('Hapus guru ini?')){const i=GURU.findIndex(x=>x.nip===gd.dataset.gurudel);if(i>=0){const g=GURU.splice(i,1)[0];navigate(state.page);requestSave();toast('Guru dihapus: '+g.n,'trash-2');}}return;}
 const gsv=t.closest('[data-gurusave]'); if(gsv){saveGuru();return;}
 if(t.closest('[data-siswaform]')){siswaForm();return;}
 const se=t.closest('[data-siswaedit]'); if(se){const s=SISWA.find(x=>x.sp===se.dataset.siswaedit);siswaForm(s);return;}
 const sdel=t.closest('[data-siswadel]'); if(sdel){if(confirm('Hapus siswa ini beserta rapor & dokumennya?')){const i=SISWA.findIndex(x=>x.sp===sdel.dataset.siswadel);if(i>=0){const s=SISWA.splice(i,1)[0];delete state.spp[s.sp];delete state.rapor[s.sp];delete state.uploads.siswa[s.sp];navigate(state.page);requestSave();toast('Siswa dihapus: '+s.n,'trash-2');}}return;}
 if(t.closest('[data-delkelas]')){delKelasForm();return;}
 if(t.closest('[data-delkelasgo]')){delKelasGo();return;}
 const aup=t.closest('[data-arsipup]'); if(aup){pickArsip(aup.dataset.arsipup);return;}
 if(t.closest('[data-netpull]')){netPullPpdb(false);return;}
 if(t.closest('[data-gaspull]')){netPullGas(false);return;}
 if(t.closest('[data-gastest]')){tesKoneksiGas();return;}
 const avw=t.closest('[data-arsipview]'); if(avw){viewArsip(avw.dataset.arsipview);return;}
 const adl=t.closest('[data-arsipdl]'); if(adl){dlArsip(adl.dataset.arsipdl);return;}
 const adel=t.closest('[data-arsipdel]'); if(adel){delArsip(adel.dataset.arsipdel);return;}
 const ssv=t.closest('[data-siswasave]'); if(ssv){saveSiswa();return;}
 if(t.closest('[data-mouform]')){mouForm();return;}
 const me=t.closest('[data-mouedit]'); if(me){const m=MOUD.find(x=>x.id===me.dataset.mouedit);if(m)mouForm(m);return;}
 const md=t.closest('[data-moudel]'); if(md){if(confirm('Hapus MOU ini?')){const i=MOUD.findIndex(x=>x.id===md.dataset.moudel);if(i>=0){const m=MOUD.splice(i,1)[0];navigate('mou');requestSave();toast('MOU dihapus: '+m.mitra,'trash-2');}}return;}
 const msv=t.closest('[data-mousave]'); if(msv){saveMou();return;}
 if(t.closest('[data-tagihan]')){tagihanDrawer();return;}
 const tgp=t.closest('[data-tgprint]'); if(tgp){printDoc(tagihanDoc());return;}
 if(t.closest('[data-ajukan]')){ajukanDrawer();return;}
 const asv=t.closest('[data-ajsave]'); if(asv){saveAjukan();return;}
 if(t.closest('[data-jilid]')){cetakJilid();return;}
 if(t.closest('[data-rapup]')){pickRaporGlobal();return;}
 if(t.closest('[data-ppdbform]')){window.open('ppdb.html','_blank');return;}
 const ppd=t.closest('[data-ppdet]'); if(ppd){const p=state.ppdb.find(x=>x.sp===ppd.dataset.ppdet);if(p)ppdbDrawer(p);return;}
 const pph=t.closest('[data-ppdel]'); if(pph){hapusPpdb(pph.dataset.ppdel);return;}
 const ppt=t.closest('[data-ppterima]'); if(ppt){terimaPpdb(ppt.dataset.ppterima);return;}
 if(t.closest('[data-ijup]')){pickIjazahGlobal();return;}
 const ijs=t.closest('[data-ijups]'); if(ijs){pickIjazahSp(ijs.dataset.ijups);return;}
 const ijp=t.closest('[data-ijprint]'); if(ijp){printIjazahAsli(ijp.dataset.ijprint);return;}
 const ijd=t.closest('[data-ijdel]'); if(ijd){ijazahDel(ijd.dataset.ijdel);return;}
 if(t.closest('[data-naikkan]')){naikkanKelas();return;}
 if(t.closest('[data-naikproses]')){prosesNaik();return;}
 if(t.closest('[data-naikauto]')){naikAutoIsi();return;}
 if(t.closest('[data-profsave]')){requestSave();toast('Profil sekolah tersimpan (TA '+state.ta+') — langsung dipakai pada kop & dokumen.','save');return;}
 if(t.closest('[data-pinssave]')){requestSave();toast('PIN pengguna tersimpan & langsung berlaku.','save');return;}
 const rpd=t.closest('[data-rapdel]'); if(rpd){rapDel(...rpd.dataset.rapdel.split('|'));return;}
 const rpw=t.closest('[data-rapwipes]'); if(rpw){rapWipes(rpw.dataset.rapwipes);return;}
 const kpg=t.closest('[data-kp]'); if(kpg){const parts=kpg.dataset.kp.split('|');const e2=KLASIFIKASI[+parts[1]];if(e2&&KPICK[parts[0]])KPICK[parts[0]](e2);return;}
 if(t.closest('[data-smform]')){suratMasukDrawer();return;}
 const sme=t.closest('[data-smedit]'); if(sme){suratMasukDrawer(state.suratAgenda[+sme.dataset.smedit]);return;}
 const smd=t.closest('[data-smdel]'); if(smd){if(confirm('Hapus catatan surat ini dari agenda?')){state.suratAgenda.splice(+smd.dataset.smdel,1);navigate('arsip');requestSave();toast('Catatan surat dihapus.','trash-2');}return;}
 if(t.closest('[data-smsave]')){saveSuratMasuk();return;}
 const dp=t.closest('[data-dispo]'); if(dp){const en=state.suratAgenda[+dp.dataset.dispo];if(en){state.docHtml=dispoDoc(en);printDoc(state.docHtml);}return;}
 if(t.closest('[data-backup]')){exportBackup();return;}
 if(t.closest('[data-restore]')){importBackup();return;}
 const rg=t.closest('[data-regen]'); if(rg){if(confirm('Buat kode pemulihan baru? Kode lama tidak berlaku lagi.')){state.recovery=genRecovery();requestSave();navigate('profil');toast('Kode pemulihan baru: '+state.recovery+' — simpan di tempat aman!','key-round');}return;}
 const tpl=t.closest('[data-xltpl]'); if(tpl){downloadTemplate(tpl.dataset.xltpl);return;}
 const xup=t.closest('[data-xlup]'); if(xup){pickXlsx(xup.dataset.xlup);return;}
 const spb=t.closest('[data-spmb]'); if(spb){bukaSpmb();return;}
 const spc=t.closest('[data-spmbclose]'); if(spc){tutupSpmb();return;}
 const spo=t.closest('[data-spmbopt]'); if(spo){pilihBerkasSpmb();return;}
 const spy=t.closest('[data-spmbyes]'); if(spy){jalankanSpmb();return;}
 const ppw=t.closest('[data-ppwa]'); if(ppw){waPendaftar(ppw.dataset.ppwa);return;}
 const encon=t.closest('[data-encon]'); if(encon){aktifEnkripsi();return;}
 const encoff=t.closest('[data-encoff]'); if(encoff){matiEnkripsi();return;}
 const spt=t.closest('[data-spmbtpl]'); if(spt){contohSpmb();return;}
 const eru=t.closest('[data-erup]'); if(eru){bukaER();return;}
 const ercl=t.closest('[data-erclose]'); if(ercl){tutupER();return;}
 const erop=t.closest('[data-eropt]'); if(erop){pilihBerkasER();return;}
 const ery=t.closest('[data-eryes]'); if(ery){jalankanER();return;}
 const ert=t.closest('[data-eruptpl]'); if(ert){contohER();return;}
 const erv=t.closest('[data-erview]'); if(erv){lihatRekap(erv.dataset.erview);return;}
 const erx=t.closest('[data-erxl]'); if(erx){eksporRekap(erx.dataset.erxl);return;}
 const erd=t.closest('[data-erdel]'); if(erd){hapusRekap(erd.dataset.erdel);return;}
 const ervc=t.closest('[data-erviewclose]'); if(ervc){document.getElementById('erViewOvl').classList.remove('show');return;}
 const xx=t.closest('[data-export-x]'); if(xx){exportXLSX(xx.dataset.exportX);return;}
 const xp=t.closest('[data-export-p]'); if(xp){const [sc,ti]=xp.dataset.exportP.split('|');exportTablePDF(sc,ti||'Laporan');return;}
 const ld=t.closest('[data-logodel]'); if(ld){state.uploads.logo=null;toast('Logo sekolah dihapus.','trash-2');navigate(state.page);requestSave();return;}
 const rs=t.closest('[data-reset]'); if(rs){
  if(confirm('Hapus semua data tersimpan di browser ini dan kembali kosong? Buat cadangan .prima dulu bila perlu!')){try{localStorage.removeItem(LS_KEY);}catch(e){}location.reload();}
  return;}
 const rd=t.closest('[data-rapdet]'); if(rd){const [sp,k]=rd.dataset.rapdet.split('|');renderRapDet(sp,+k);return;}
 const rp2=t.closest('[data-rapprint]'); if(rp2){const [sp,k,sem]=rp2.dataset.rapprint.split('|');printRaporAsli(sp,+k,+sem);return;}
 const sd=t.closest('[data-sdet]'); if(sd){const s=SISWA.find(x=>x.sp===sd.dataset.sdet);if(s)indukDrawer(s);return;}
 const gs=t.closest('[data-gshow]'); if(gs){const g=GURU.find(x=>x.nip===gs.dataset.gshow);if(g)guruDrawer(g);return;}
 const su=t.closest('[data-surat]'); if(su){suratDrawer(su.dataset.surat);return;}
 const sg=t.closest('[data-sgen]'); if(sg){generateSurat(sg.dataset.sgen);return;}
 const sp2=t.closest('[data-sprint]'); if(sp2){if(state.docHtml)printDoc(state.docHtml);return;}
 const skc=t.closest('[data-sk]'); if(skc){const sk=SKD.find(x=>x.id===skc.dataset.sk);if(sk)skDrawer(sk);return;}
 const mo=t.closest('[data-mou]'); if(mo){const m=MOUD.find(x=>x.id===mo.dataset.mou);if(m)mouDrawer(m);return;}
 const ip=t.closest('[data-indukprint]'); if(ip){const s=SISWA.find(x=>x.sp===ip.dataset.indukprint);if(s)printInduk(s);return;}
 const tr=t.closest('[data-transkrip]'); if(tr){const s=SISWA.find(x=>x.sp===tr.dataset.transkrip);if(s){state.docHtml=transkripDoc(s);printDoc(state.docHtml);}return;}
 const go=t.closest('[data-go]'); if(go){navigate(go.dataset.go);return;}
 const gr=t.closest('[data-group]'); if(gr){toggleGroup(gr.dataset.group);return;}
 const chip=t.closest('[data-chip]');
 if(chip){const scope=chip.dataset.chip;
  document.getElementById(scope).dataset.fval=chip.dataset.val;
  chip.parentElement.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c===chip));
  if(scope==='tb-surat') arsipFilter(); else applyRows(scope);return;}
 const cyc=t.closest('[data-cycle]'); if(cyc){cycleAbs(+cyc.dataset.cycle);return;}
 const pay=t.closest('[data-pay]'); if(pay){paySpp(pay.dataset.pay);return;}
 const ph=t.closest('[data-ph]'); if(ph){ph.closest('.phase').classList.toggle('open');return;}
 const dc=t.closest('[data-drclose]'); if(dc){closeDrawer();return;}
 if(t.closest('[data-pal]')){openPal();return;}
 if(t.closest('[data-bell]')){document.getElementById('pop').classList.toggle('show');return;}
 if(t.closest('[data-hamb]')){document.body.classList.toggle('sbopen');return;}
 if(!t.closest('.pop-wrap')) document.getElementById('pop').classList.remove('show');
});
document.getElementById('lightbox').addEventListener('click',()=>document.getElementById('lightbox').classList.remove('show'));
document.addEventListener('input',e=>{
 if(e.target.id==='login-pin'){
  if(lockSisa()>0){renderLockHint();return;}
  const u=USERS.find(x=>x.id===state.loginSel)||USERS[0];
  const val=(e.target.value||'').trim();
  if(val.length>=4&&val===(state.pins[u.id]||'')){tryLogin();return;}
 }
 if(e.target.id==='thn-q'){tahunFilter();return;}
 if(e.target.dataset.search){
  const scope=e.target.dataset.search, root=document.getElementById(scope);
  root.dataset.q=e.target.value; if(scope==='tb-surat') arsipFilter(); else applyRows(scope);
 }
 const prof=e.target.dataset.prof;
 if(prof){
  state.sekolah[prof]=prof==='spp'?(+e.target.value||0):e.target.value;
  requestSave();
  const kp=document.getElementById('kop-prev'); if(kp)kp.innerHTML=kop();
  return;
 }
 if(e.target.dataset.pinset){
  state.pins[e.target.dataset.pinset]=e.target.value.replace(/\D/g,'').slice(0,8);
  requestSave(); return;
 }
 const id=e.target.id;
 const pidm=id&&id.match(/^(.+)-in$/); if(pidm&&KPICK[pidm[1]]){renderKlasPicker(pidm[1],KPSEL[pidm[1]]);return;}
 if(id==='f-kode-search'){const v=e.target.value.trim();if(cariKlas(v))state.naskah.kode=v;renderKpick(v);updateNaskah();return;}
 if(id==='f-urut'){state.naskah.urut=Math.max(1,Math.min(9999,parseInt(e.target.value)||1));renderNomorPrev();requestSave();return;}
 if(id==='f-tahun'){const v=e.target.value.replace(/\D/g,'');state.naskah.tahun=parseInt(v)||new Date().getFullYear();renderNomorPrev();requestSave();return;}
 if(id==='f-aman'){state.naskah.aman=e.target.value;updateNaskah();return;}
 if(id==='f-bulan'){state.naskah.bulan=Math.max(0,Math.min(11,+e.target.value||0));renderNomorPrev();return;}
 if(id==='tg-tempo'){renderTagihan();return;}
 if(id==='nk-dari'){const ke=document.getElementById('nk-ke');if(ke)ke.value=nextKelas(e.target.value);return;}
});
document.addEventListener('change',e=>{
 const tid=e.target.id;
 if(tid==='ppdb-url'){state.ppdbServer=e.target.value.trim();requestSave();toast(state.ppdbServer?'Alamat server PPDB disimpan: '+state.ppdbServer:'Alamat server dikosongkan — memakai server halaman ini (otomatis).','inbox');return;}
 if(tid==='ppdb-gas'){state.gasUrl=e.target.value.trim();requestSave();toast(state.gasUrl?'Alamat Google Apps Script disimpan — pendaftaran dari internet bisa ditarik kapan saja.':'Alamat Google Apps Script dikosongkan.','cloud');return;}
 if(tid==='tg-gel'||tid==='tg-nunggak'){renderTagihan();return;}
 if(tid==='sr-use'){if(SR_ID)srPrev(SR_ID);return;}
 if(tid==='arsip-ta'){arsipFilter();return;}
 if(tid==='nk-dari'){const ke=document.getElementById('nk-ke');if(ke)ke.value=nextKelas(e.target.value);return;}
 const ppst=e.target.closest('[data-ppst]'); if(ppst){setStatusPpdb(ppst.dataset.ppst,e.target.value);return;}
 if(tid==='ta-sel'){state.ta=e.target.value;requestSave();buildPop();navigate(state.page);toast('Tahun ajaran aktif: '+state.ta+' — tampilan dimuat ulang; tahun yang belum diisi tampil kosong.','calendar-days');return;}
 if(e.target.dataset.profTa!==undefined&&e.target.hasAttribute('data-prof-ta')){state.ta=e.target.value;buildTaSel();requestSave();navigate(state.page);toast('Tahun ajaran aktif: '+state.ta+' — tampilan dimuat ulang.','calendar-days');return;}
});
document.addEventListener('change',e=>{
 const c0=e.target.closest('[data-deliv]');
 if(c0&&state.user&&!canEdit()){toast('Peran '+state.user.role+' hanya dapat melihat data.','lock-keyhole');c0.checked=!c0.checked;return;}
 const c=e.target.closest('[data-deliv]'); if(!c) return;
 const ph=c.closest('.phase');
 updateDeliv(true);
 const cks=[...ph.querySelectorAll('[data-deliv]')];
 if(cks.every(k=>k.checked)) toast(ph.querySelector('h3').textContent.trim()+' — tuntas!','flag');
});
document.addEventListener('keydown',e=>{
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();povl.classList.contains('show')?closePal():openPal();}
 else if(e.key==='Enter'&&document.getElementById('loginOvl').classList.contains('show')){e.preventDefault();tryLogin();}
 else if(e.key==='Escape'){closeForgot();closePal();closeDrawer();document.getElementById('lightbox').classList.remove('show');document.getElementById('pop').classList.remove('show');}
});

/* ================= Login, PIN & pemulihan ================= */
const canEdit=()=>!!state.user&&state.user.role!=='Guru';
function renderLoginList(){
 const el=document.getElementById('login-list'); if(!el) return;
 el.innerHTML=USERS.map(u=>{const s=u.id===state.loginSel;
  return `<div class="login-card ${s?'sel':''}" data-lsel="${u.id}" style="--lc:${u.c}">
  <span class="ava" style="background:${u.c}1f;color:${u.c};border:1px solid ${u.c}3d">${u.ini}</span>
  <div class="lc-mid"><b>${u.name}</b><span class="lc-role">${u.role}</span></div>
  <div class="lc-right"><span class="login-pin">PIN ${state.pins[u.id]}</span><span class="login-sel">${s?'✓ Terpilih':'Pilih'}</span></div></div>`;}).join('');
 const sel=USERS.find(x=>x.id===state.loginSel)||USERS[0];
 const h=document.getElementById('login-selhint');
 if(h) h.innerHTML='Peran dipilih: <b>'+esc2(sel.role)+'</b> · '+esc2(sel.name);
 const ls=document.getElementById('lg-school');
 if(ls) ls.textContent=(state.sekolah.nama||'Satuan Pendidikan')+(state.sekolah.alamat?' · '+state.sekolah.alamat:'');
}
/* ---- Keamanan: kunci PIN 3x gagal (5 menit) + log aktivitas ---- */
function lockGet(){ try{return JSON.parse(localStorage.getItem('prima-lock')||'{"n":0,"until":0}');}catch(e){return {n:0,until:0};} }
function lockSet(v){ try{localStorage.setItem('prima-lock',JSON.stringify(v));}catch(e){} }
function lockSisa(){ const l=lockGet(); const s=Math.ceil((l.until-Date.now())/1000); return s>0?s:0; }
function renderLockHint(){
 const h=document.getElementById('login-selhint'); if(!h) return;
 const s=lockSisa();
 if(s>0){ const m=Math.floor(s/60),d=s%60; h.innerHTML='<span style="color:var(--red)">3 kali salah — terkunci, coba lagi dalam '+m+':'+String(d).padStart(2,'0')+'</span>'; }
}
setInterval(()=>{ if(document.getElementById('loginOvl')&&document.getElementById('loginOvl').classList.contains('show')) renderLockHint(); },1000);
function catatLog(act){
 if(!Array.isArray(state.log)) state.log=[];
 state.log.unshift({t:Date.now(),u:state.user?state.user.name:'—',a:act});
 if(state.log.length>300) state.log.length=300;
}
/* ---- Cadangan harian otomatis (mode aplikasi desktop) ---- */
function cekBackupHarian(){
 if(!(window.primaFS&&window.primaFS.saveAs&&window.__PRIMA_FS_INFO&&window.__PRIMA_FS_INFO.dir)) return;
 const today=new Date().toISOString().slice(0,10);
 if(state.lastAutoBackup===today) return;
 try{
  const json=JSON.stringify(Object.assign(collectSave(),{t:Date.now()}));
  const pr=window.primaFS.saveAs('cadangan/prima-'+today+'.prima',json);
  if(pr&&pr.then) pr.then(res=>{ if(res&&res.ok){ state.lastAutoBackup=today; catatLog('Cadangan harian otomatis tersimpan (cadangan/prima-'+today+'.prima)'); requestSave(); toast('Cadangan harian otomatis tersimpan: D:\\PRIMA\\cadangan\\prima-'+today+'.prima','archive'); } });
 }catch(e){}
}
function fmtLogT(t){ const d=new Date(t); return String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0')+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0'); }

function showLogin(){
 const o=document.getElementById('loginOvl'); o.classList.add('show');
 const p=document.getElementById('login-pin'); if(p) p.value='';
 renderLoginList(); lucide.createIcons(); setTimeout(()=>p&&p.focus(),60);
}
function tryLogin(){
 const u=USERS.find(x=>x.id===state.loginSel)||USERS[0];
 const sisa=lockSisa();
 if(sisa>0){toast('Terlalu banyak percobaan salah — terkunci '+(Math.floor(sisa/60))+' menit '+(sisa%60)+' detik lagi.','lock-keyhole');renderLockHint();return;}
 const pinV=(document.getElementById('login-pin').value||'').trim();
 if(pinV!==(state.pins[u.id]||'')){
  const l=lockGet(); l.n=(l.n||0)+1;
  if(l.n>=3){ l.until=Date.now()+5*60*1000; l.n=0; catatLog('PIN salah 3x — akun '+u.role+' dikunci 5 menit'); toast('PIN salah 3 kali — login dikunci 5 menit demi keamanan.','lock-keyhole'); }
  else { toast('PIN salah untuk peran '+u.role+' (percobaan '+l.n+'/3).','lock-keyhole'); }
  lockSet(l); renderLockHint(); return;
 }
 lockSet({n:0,until:0});
 state.user={id:u.id,name:state.user&&state.user.id===u.id?state.user.name:u.name,role:u.role};
 document.getElementById('loginOvl').classList.remove('show');
 catatLog('Masuk sebagai '+u.role); applyUser(); requestSave(); navigate(state.page||'beranda'); buildPop(); cekBackupHarian();
 toast('Selamat bekerja, '+u.name.split(',')[0]+' — peran '+u.role+'.','log-in');
}
function applyUser(){
 const u=state.user?USERS.find(x=>x.id===state.user.id):null; if(!u) return;
 const b=document.querySelector('.ucard .uinfo');
 if(b) b.innerHTML=`<b>${u.name}</b><span>${u.role}</span>`;
 const av=document.querySelector('.ucard .ava');
 if(av){av.textContent=u.ini;av.style.background=u.c+'1f';av.style.color=u.c;av.style.border='1px solid '+u.c+'3d';}
}
function forgotPin(){
 const o=document.getElementById('forgotOvl');
 document.getElementById('forgot-body').innerHTML=`
  <p style="font-size:12.5px;color:var(--tx2);line-height:1.6;margin-bottom:12px">Masukkan <b>Kode Pemulihan</b> sekolah — kode ini dibuat otomatis dan dapat dilihat oleh Tata Usaha / Kepala Sekolah di menu <b>Profil Sekolah</b>. Pilih akun lalu tetapkan PIN baru. Data sekolah tidak berubah sama sekali.</p>
  ${fld('fgt-kode','Kode Pemulihan','cth: AB12-CD34')}
  <div class="fld"><label>Akun yang dipulihkan</label><select id="fgt-user">${USERS.map(u=>`<option value="${u.id}">${u.name} — ${u.role}</option>`).join('')}</select></div>
  ${fld('fgt-pin','PIN Baru (4–8 angka)','cth: 1234')}
  <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:4px">
   <button class="btn pri" data-fgtsave><i data-lucide="key-round"></i>Setel PIN Baru</button>
   <button class="btn ghost" data-fgtclose>Batal</button>
  </div>`;
 o.classList.add('show'); lucide.createIcons();
 const f=document.getElementById('fgt-kode'); if(f)f.focus();
}
function closeForgot(){document.getElementById('forgotOvl').classList.remove('show');}
function saveForgot(){
 const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
 if(!state.recovery){toast('Kode pemulihan belum tersedia. Masuk sebagai TU/Kepsek lalu buka Profil Sekolah.','info');return;}
 if(v('fgt-kode').toUpperCase()!==state.recovery){toast('Kode pemulihan salah.','lock-keyhole');return;}
 const p=v('fgt-pin').replace(/\D/g,'');
 if(p.length<4){toast('PIN baru minimal 4 angka.','info');return;}
 const uid=v('fgt-user'); state.pins[uid]=p; requestSave();
 closeForgot(); renderLoginList();
 toast('PIN berhasil disetel ulang — silakan masuk dengan PIN baru.','key-round');
}

/* ================= Cadangan (.prima) ================= */
function exportBackup(){
 catatLog('Ekspor cadangan .prima manual');
 const blob=new Blob([JSON.stringify({app:'PRIMA',v:2,t:Date.now(),data:collectSave()})],{type:'application/octet-stream'});
 const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
 a.download='prima-cadangan-'+new Date().toISOString().slice(0,10)+'.prima';
 a.click(); URL.revokeObjectURL(a.href);
 state.lastBackup=Date.now(); requestSave();
 toast('Cadangan .prima diunduh — simpan di flashdisk / Google Drive sekolah.','download');
 if(state.page==='backup') navigate('backup');
}
function importBackup(){
 const inp=document.createElement('input'); inp.type='file'; inp.accept='.prima,application/json';
 inp.onchange=()=>{const f=inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{try{
    const j=JSON.parse(r.result);
    if(!j||j.app!=='PRIMA'||!j.data) throw 0;
    localStorage.setItem(LS_KEY,JSON.stringify(j.data));
    toast('Cadangan valid — memuat ulang aplikasi…','database');
    setTimeout(()=>location.reload(),900);
   }catch(e){toast('Berkas cadangan tidak valid.','alert-triangle');}};
  r.readAsText(f);};
 inp.click();
}

/* ================= Pemilih kode klasifikasi (generik) ================= */
const KPICK={},KPSEL={};
function bindKlasPicker(pid,initial,onPick){
 KPSEL[pid]=initial||'';
 KPICK[pid]=e=>{KPSEL[pid]=e[0];const inp=document.getElementById(pid+'-in');if(inp)inp.value=e[0];renderKlasPicker(pid,KPSEL[pid]);if(onPick)onPick(e);};
}
const klasPickerHTML=(pid,val)=>`<input id="${pid}-in" placeholder="Ketik kata kunci… cth: kearsipan, pendidikan" value="${attq(val||'')}"><div class="kpick-list" id="${pid}-list"></div><div class="ksel" id="${pid}-sel"></div>`;
function renderKlasPicker(pid,selected){
 const inp=document.getElementById(pid+'-in');
 const q=inp?inp.value.trim().toLowerCase():'';
 const list=document.getElementById(pid+'-list'); if(!list) return;
 const rows=KLASIFIKASI.map((x,i)=>({x,i})).filter(o=>!q||o.x[0].includes(q)||o.x[1].toLowerCase().includes(q)).slice(0,120);
 list.innerHTML=rows.length
  ?rows.map(o=>`<button class="kpick ${o.x[0]===selected?'sel':''}" data-kp="${pid}|${o.i}"><span class="kno">${o.x[0]}</span><span>${esc2(o.x[1])}</span></button>`).join('')
  :'<div class="pal-empty">Tidak ada kode yang cocok.</div>';
 const sel=document.getElementById(pid+'-sel');
 if(sel){const e=cariKlas(selected);sel.innerHTML=e?`<b>${e[0]}</b><span>${esc2(e[1])}</span>`:`<b>—</b><span>Belum ada kode terpilih.</span>`;}
}

/* ================= Agenda surat & disposisi ================= */
let SM_EDIT=null;
function suratMasukDrawer(en){
 SM_EDIT=en?state.suratAgenda.indexOf(en):null;
 const sug=en?en.a:'AG.'+(state.suratAgenda.length+1)+'/'+new Date().getFullYear();
 openDrawer(`
  <div class="dr-h"><span class="cic" style="background:${C.pink}1c;color:${C.pink};border:1px solid ${C.pink}3d"><i data-lucide="mail-plus"></i></span>
   <div><b>${en?'Edit Surat':'Catat Surat'}</b><span class="sub">masuk ke agenda & bisa cetak disposisi · TA ${state.ta}</span></div>
   <button class="ibtn" data-drclose><i data-lucide="x"></i></button></div>
  <div class="dr-b">
   <div class="frow2">
    <div class="fld"><label>Jenis</label><select id="sm-jenis"><option ${en&&en.t==='Masuk'?'selected':''}>Masuk</option><option ${en&&en.t==='Keluar'?'selected':''}>Keluar</option></select></div>
    ${fld('sm-agenda','No. Agenda','',sug)}
   </div>
   ${fld('sm-asal','Asal / Tujuan','cth: Dinas Pendidikan',en?en.d:'')}
   ${fld('sm-perihal','Perihal','cth: undangan sosialisasi kurikulum',en?en.p:'')}
   <div class="fld"><label>Kode Klasifikasi (Perbup 8/2023)</label>${klasPickerHTML('sm',en?en.kode:'')}</div>
   <div class="frow2">
    <div class="fld"><label>Status</label><select id="sm-status">${['Tindak Lanjut','Selesai','Terkirim'].map(x=>`<option ${en&&en.s===x?'selected':''}>${x}</option>`).join('')}</select></div>
    ${fld('sm-tgl','Tanggal','',en?en.tgl:tglIndo())}
   </div>
   <div style="display:flex;gap:9px;margin-top:6px;flex-wrap:wrap">
    <button class="btn pri" data-smsave><i data-lucide="save"></i>${en?'Simpan Perubahan':'Simpan ke Agenda'}</button>
    <button class="btn ghost" data-drclose>Batal</button>
   </div>
  </div>`);
 bindKlasPicker('sm',en?en.kode:'',null); renderKlasPicker('sm',en?en.kode:'');
}
function saveSuratMasuk(){
 const v=id=>{const el=document.getElementById(id);return el?el.value.trim():'';};
 const p=v('sm-perihal'), dd=v('sm-asal');
 if(!p||!dd){toast('Lengkapi dulu: Asal/Tujuan, Perihal','info');return;}
 const rec={a:v('sm-agenda')||('AG.'+(state.suratAgenda.length+1)),p,d:dd,t:v('sm-jenis'),s:v('sm-status'),kode:KPSEL['sm']||'',tgl:v('sm-tgl')||tglIndo(),ta:state.ta};
 if(SM_EDIT!==null&&state.suratAgenda[SM_EDIT]){rec.id=state.suratAgenda[SM_EDIT].id;state.suratAgenda[SM_EDIT]=rec;toast('Catatan surat diperbarui.','pencil');}
 else{rec.id=state.suratAgenda.length;state.suratAgenda.push(rec);toast('Surat tercatat di agenda (TA '+state.ta+').','mail-plus');}
 closeDrawer(); navigate('arsip'); requestSave();
}
function dispoDoc(e){
 const k=cariKlas(e.kode);
 return paper(kop()+`
  <div class="doc-t">LEMBAR DISPOSISI<br><span class="small">Agenda ${esc2(e.a)} · ${esc2(e.t)}</span></div>
  ${drow('Asal / Tujuan',esc2(e.d))}
  ${drow('Perihal',esc2(e.p))}
  ${drow('Tanggal Agenda',esc2(e.tgl||'—'))}
  ${drow('Kode Klasifikasi',(e.kode||'—')+(k?' — '+esc2(k[1]):''))}
  <table class="dt"><thead><tr><th style="width:34px">No</th><th>Instruksi / Arahan Pimpinan</th><th style="width:90px">Paraf</th></tr></thead>
  <tbody>${[1,2,3,4].map(i=>`<tr><td>${i}</td><td style="height:28px"></td><td></td></tr>`).join('')}</tbody></table>`+
  `<div class="ttd">Diterima tanggal,<div class="sp"></div><b>(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)</b></div>`);
}

/* ================= Template & impor Excel ================= */
const XL_TPL={
 guru:{name:'template-data-guru.xlsx',head:['Nama Lengkap & Gelar','NIP / NUPTK','Mata Pelajaran','Status (PNS/PPPK/Honorer)','Skor SKP'],contoh:['Budi Santoso, S.Pd.','19850217 200903 2 010','Matematika','PNS','88']},
 siswa:{name:'template-data-siswa.xlsx',head:['Nama Lengkap','NIS','NISN','Kelas','L/P','Tempat, Tanggal Lahir','Agama','Anak ke-','Nama Ayah','Nama Ibu','Pekerjaan Orang Tua','Alamat','Telepon','Asal Sekolah'],contoh:['Ananda Putra','26.0001','0123456789','1A','L','Ungaran, 12 Mei 2019','Islam','1','Budi Santoso','Sari Wulandari','Wiraswasta','Jl. Kenanga No. 12, Ungaran','0812-3456-7890','TK Pertiwi']},
 pegawai:{name:'template-data-pegawai.xlsx',head:['Nama Lengkap','Jabatan','Unit','Status (PNS/PTT/Honorer)','Masa Kerja'],contoh:['Rina Kartika','Kepala Tata Usaha','Administrasi','PNS','12 th']},
};
function downloadTemplate(kind){
 const t=XL_TPL[kind]; if(!t) return;
 downloadXLSX(t.name,[t.head,t.contoh]);
 toast('Template Excel diunduh — isi lalu unggah lewat tombol “Impor Excel”.','file-down');
}
function importGuruRows(m){
 let n=0;
 m.forEach(r=>{
  const nm=String(r[0]||'').trim();
  if(!nm||/nama/i.test(nm)&&/gelar/i.test(nm)) return;
  const nip=String(r[1]||'').trim()||('G'+Date.now()+n);
  const ex=GURU.find(g=>g.nip===nip);
  const rec={n:nm,nip,m:String(r[2]||'—').trim()||'—',s:String(r[3]||'Honorer').trim()||'Honorer',skp:+String(r[4]||'').replace(/\D/g,'')||0};
  if(ex) Object.assign(ex,rec); else GURU.push(rec);
  n++;
 });
 return n;
}
function importSiswaRows(m){
 let n=0;
 m.forEach(r=>{
  const nm=String(r[0]||'').trim();
  if(!nm||/nama/i.test(nm)&&/lengkap/i.test(nm)) return;
  const sp='s'+Date.now()+'_'+n;
  SISWA.push({n:nm,nis:String(r[1]||'—').trim()||'—',nisn:String(r[2]||'—').trim()||'—',k:String(r[3]||'—').trim()||'—',
   jk:/^p/i.test(String(r[4]||'').trim())?'P':'L',ttl:String(r[5]||'—').trim()||'—',ag:String(r[6]||'—').trim()||'—',
   ak:+String(r[7]||'').replace(/\D/g,'')||0,ib:String(r[8]||'—').trim()||'—',im:String(r[9]||'—').trim()||'—',
   kr:String(r[10]||'—').trim()||'—',al:String(r[11]||'—').trim()||'—',tl:String(r[12]||'').trim(),asal:String(r[13]||'—').trim()||'—',masuk:state.ta,sp});
  state.spp[sp]=state.spp[sp]||{l:false};
  n++;
 });
 return n;
}
function importPegawaiRows(m){
 let n=0;
 m.forEach(r=>{
  const nm=String(r[0]||'').trim();
  if(!nm||/nama/i.test(nm)&&/lengkap/i.test(nm)) return;
  PEGAWAI.push({n:nm,j:String(r[1]||'—').trim()||'—',u:String(r[2]||'Administrasi').trim()||'Administrasi',s:String(r[3]||'Honorer').trim()||'Honorer',mk:String(r[4]||'—').trim()||'—'});
  n++;
 });
 return n;
}
function applyImport(kind,matrix){
 let n=0;
 try{
  if(kind==='guru') n=importGuruRows(matrix);
  else if(kind==='siswa') n=importSiswaRows(matrix);
  else if(kind==='pegawai') n=importPegawaiRows(matrix);
 }catch(e){toast('Isi berkas tidak dapat dibaca: '+e.message,'alert-triangle');return;}
 if(!n){toast('Tidak ada baris data baru pada berkas.','info');return;}
 requestSave(); buildPop();
 const label={guru:'guru',siswa:'siswa',pegawai:'pegawai'}[kind];
 toast(n+' data '+label+' berhasil diimpor dari Excel.','file-up');
 navigate(kind==='guru'?'dguru':kind==='siswa'?'dsiswa':'pegawai');
}
function pickXlsx(kind){
 const inp=document.createElement('input');
 inp.type='file'; inp.accept='.xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv';
 inp.onchange=()=>{
  const f=inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
   try{
    let matrix;
    if(/\.csv$/i.test(f.name)) matrix=parseCSVText(r.result);
    else matrix=readXLSX(r.result);
    applyImport(kind,matrix);
   }catch(e){toast('Gagal membaca berkas: '+e.message+' — gunakan template dari aplikasi.','alert-triangle');}
  };
  if(/\.csv$/i.test(f.name)) r.readAsText(f); else r.readAsArrayBuffer(f);
 };
 inp.click();
}

/* ================= Impor Cerdas SPMB =================
   Mengenali kolom berkas murid baru dari SPMB kabupaten
   (atau sistem lain) secara otomatis lewat alias judul kolom. */
const SPMB_ALI={
 im:['nama ibu','ibu kandung','nama ibu kandung','nama ortu ibu','ibu'],
 ib:['nama ayah','ayah kandung','nama ayah kandung','nama ortu ayah','ayah','nama wali','wali'],
 n:['nama lengkap','nama siswa','nama peserta','nama calon','nama murid','nama peserta didik','nama calon peserta didik','nama anak','nama'],
 jk:['jenis kelamin','jk','l/p','lp','gender'],
 ttl:['tempat tanggal lahir','tempat, tanggal lahir','tempat/tanggal lahir','tempat & tanggal lahir','tempat dan tanggal lahir','ttl'],
 tgl:['tanggal lahir','tgl lahir','tgl. lahir','tanggal lahir (dd/mm/yyyy)','lahir tanggal','tanggal'],
 tlahir:['tempat lahir','kota lahir','tempat'],
 ag:['agama'],
 nisn:['nisn'],
 asal:['asal sekolah','sekolah asal','asal tk','asal paud','asal satuan pendidikan','asal'],
 al:['alamat lengkap','alamat rumah','alamat tempat tinggal','alamat'],
 kota:['kota/kabupaten','kabupaten','kota','kecamatan','desa/kelurahan','kelurahan'],
 pos:['kode pos','kodepos','kode pos rumah'],
 kr:['pekerjaan orang tua','pekerjaan ortu','pekerjaan','pekerjaan ayah','pekerjaan wali'],
 hp:['no hp','no. hp','nomor hp','no handphone','hp/wa','hp / wa','whatsapp','wa','no wa','telepon','nomor telepon','kontak','handphone'],
 em:['email','e-mail','surel'],
 noDaftar:['nomor pendaftaran','no pendaftaran','no. pendaftaran','nomor peserta','no peserta','nomor formulir','no formulir'],
 nik:['nik anak','nik siswa','nik peserta','nik'],
};
function normH(s){return String(s||'').toLowerCase().replace(/[^a-z0-9/ &,.-]/g,'').replace(/\s+/g,' ').trim();}
function cariHeaderSPMB(m){
 let best=null;
 for(let r=0;r<Math.min(m.length,15);r++){
  const row=m[r]||[]; const map={}; const used=new Set(); let hits=0;
  for(let c=0;c<row.length;c++){
   const h=normH(row[c]); if(!h||used.has(c)) continue;
   for(const key in SPMB_ALI){
    if(map[key]!=null) continue;
    if(SPMB_ALI[key].some(a=>h===a||h.startsWith(a+' ')||h.startsWith(a+'(')||h===a+' (dd/mm/yyyy)'||h.includes(a)&&a.length>=5)){ map[key]=c; used.add(c); hits++; break; }
   }
  }
  if(hits>=2&&(!best||hits>best.hits)) best={r,map,hits};
  if(hits>=6) break;
 }
 return best;
}
function normJK(v){const s=String(v||'').trim().toLowerCase(); if(!s)return ''; return /^l|laki|male|m$/.test(s)||s.includes('laki')||s==='l'?'L':'P';}
function splitTTL(v){const s=String(v||'').trim(); if(!s) return ['','']; const i=s.indexOf(','); return i>-1?[s.slice(0,i).trim(),s.slice(i+1).trim()]:['',s];}
let _spmbMatrix=null,_spmbDet=null;
function spmbOut(html){const o=document.getElementById('spmb-out'); if(o) o.innerHTML=html;}
function bukaSpmb(){const o=document.getElementById('spmbOvl'); if(!o) return; _spmbMatrix=null;_spmbDet=null; spmbOut(''); o.classList.add('show'); lucide.createIcons();}
function tutupSpmb(){const o=document.getElementById('spmbOvl'); if(o) o.classList.remove('show');}
function pilihBerkasSpmb(){
 const inp=document.createElement('input');
 inp.type='file'; inp.accept='.xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv';
 inp.onchange=()=>{
  const f=inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
   try{
    const matrix=/\.csv$/i.test(f.name)?parseCSVText(r.result):readXLSX(r.result);
    const det=cariHeaderSPMB(matrix);
    if(!det){spmbOut('<div style="background:#fdecec;color:#b42323;border:1px solid #f5c6c6;border-radius:10px;padding:10px 12px;font-size:12.5px">Kolom tidak dikenali. Pastikan ada baris judul berisi minimal <b>Nama</b> dan <b>Jenis Kelamin</b>, atau unduh “Contoh Format” lalu ikuti bentuknya.</div>');return;}
    _spmbMatrix=matrix; _spmbDet=det;
    const g=(row,k)=>det.map[k]!=null?String(row[det.map[k]]||'').trim():'';
    let total=0; for(let i=det.r+1;i<matrix.length;i++){ if(g(matrix[i],'n')) total++; }
    const dikenal=Object.keys(det.map).map(k=>({k,c:det.map[k]})).sort((a,b)=>a.c-b.c);
    const contoh=[]; for(let i=det.r+1;i<matrix.length&&contoh.length<3;i++){ const nm=g(matrix[i],'n'); if(!nm) continue; const [tl,t]=det.map.ttl!=null?splitTTL(g(matrix[i],'ttl')):[g(matrix[i],'tlahir'),g(matrix[i],'tgl')];
     contoh.push('<tr><td style="padding:5px 10px;border-bottom:1px solid var(--line)">'+esc2(nm)+'</td><td style="padding:5px 10px;border-bottom:1px solid var(--line)">'+esc2(normJK(g(matrix[i],'jk'))||'—')+'</td><td style="padding:5px 10px;border-bottom:1px solid var(--line)">'+esc2((tl?tl+', ':'')+(t||'—'))+'</td></tr>');}
    spmbOut('<div style="background:#eafaf1;border:1px solid #bfe8d2;border-radius:10px;padding:10px 12px;font-size:12.5px;color:#14683f">'
     +'<b>Terdeteksi '+total+' baris calon siswa</b> — '+dikenal.length+' kolom dikenali otomatis ('+dikenal.map(x=>x.k).join(', ')+').'
     +'<table style="margin-top:8px;font-size:12px;border-collapse:collapse"><tr><th style="text-align:left;padding:4px 10px;border-bottom:1px solid #bfe8d2">Nama</th><th style="text-align:left;padding:4px 10px;border-bottom:1px solid #bfe8d2">L/P</th><th style="text-align:left;padding:4px 10px;border-bottom:1px solid #bfe8d2">TTL</th></tr>'+contoh.join('')+'</table></div>'
     +'<button class="btn pri" data-spmbyes style="margin-top:12px"><i data-lucide="check-circle"></i>Impor '+total+' Siswa Sekarang</button>');
    lucide.createIcons();
   }catch(e){spmbOut('<div style="background:#fdecec;color:#b42323;border:1px solid #f5c6c6;border-radius:10px;padding:10px 12px;font-size:12.5px">Berkas tidak dapat dibaca: '+esc2(e.message)+'</div>');}
  };
  if(/\.csv$/i.test(f.name)) r.readAsText(f); else r.readAsArrayBuffer(f);
 };
 inp.click();
}
function jalankanSpmb(){
 if(!_spmbMatrix||!_spmbDet) return;
 const det=_spmbDet; const sel=document.getElementById('spmb-status');
 const st=sel?sel.value:'Diterima'; const g=(row,k)=>det.map[k]!=null?String(row[det.map[k]]||'').trim():'';
 let n=0,dup=0;
 for(let i=det.r+1;i<_spmbMatrix.length;i++){
  const row=_spmbMatrix[i]; const nama=g(row,'n'); if(!nama) continue;
  let tgl=g(row,'tgl'),tlahir=g(row,'tlahir');
  if(det.map.ttl!=null){const s=splitTTL(g(row,'ttl')); tlahir=s[0]; tgl=s[1];}
  if(state.ppdb.some(x=>normNama(x.n)===normNama(nama)&&String(x.tgl||'')===String(tgl||''))){dup++;continue;}
  const rec={reg:'REG-'+new Date().getFullYear()+'-'+Math.floor(100000+Math.random()*900000),
   n:nama,jk:normJK(g(row,'jk')),tgl,tlahir,ag:g(row,'ag')||'—',asal:g(row,'asal')||'—',nisn:g(row,'nisn'),
   al:g(row,'al'),kota:g(row,'kota'),pos:g(row,'pos'),ib:g(row,'ib'),im:g(row,'im'),kr:g(row,'kr'),
   hp:g(row,'hp'),em:g(row,'em'),nik:g(row,'nik'),noDaftar:g(row,'noDaftar'),
   tglDaftar:new Date().toISOString(),ta:state.ta,status:st,sp:'pp'+Date.now()+'_'+i,impor:'SPMB'};
  state.ppdb.push(rec); n++;
 }
 tutupSpmb(); requestSave(); navigate('ppdb');
 catatLog('Impor SPMB: '+n+' siswa'+(dup?', '+dup+' ganda dilewati':''));
 toast(n+' siswa baru diimpor dari berkas SPMB'+(dup?' ('+dup+' ganda dilewati)':'')+'.','sparkles');
}
function contohSpmb(){
 downloadXLSX('contoh-format-impor-spmb.xlsx',[
  ['No Pendaftaran','Nama Lengkap','Jenis Kelamin','Tempat, Tanggal Lahir','Agama','NISN','Asal TK/PAUD','Alamat','Kecamatan','Nama Ayah','Nama Ibu','Pekerjaan Orang Tua','No HP'],
  ['SPMB-0001','Ananda Putri','P','Brebes, 12 Mei 2019','Islam','0123456789','TK Pertiwi','Jl. Melati No. 3, Jatibarang','Jatibarang','Budi Santoso','Sari Wulandari','Wiraswasta','0812-3456-7890'],
 ]);
 toast('Contoh format diunduh — samakan judul kolom dengan berkas SPMB Anda.','file-down');
}

/* ================= Impor Rekap e-Rapor =================
   Arsip rekap nilai dari ekspor e-Rapor/Excel: kolom bebas,
   baris judul dikenali otomatis, nama dicocokkan ke Data Siswa. */
function rekapTA(){ if(!state.rekap[state.ta]) state.rekap[state.ta]=[]; return state.rekap[state.ta]; }
function cariHeaderRekap(m){
 for(let r=0;r<Math.min(m.length,15);r++){
  const row=(m[r]||[]).map(x=>String(x||'').trim()); const isi=row.filter(Boolean).length;
  if(isi<3) continue;
  const adaNama=row.some(c=>{const h=normH(c); return h&&(SPMB_ALI.n.some(a=>h===a||h.startsWith(a+' '))||h==='nama');});
  if(adaNama) return r;
 }
 return -1;
}
let _erMatrix=null,_erHead=-1,_erCocok=0;
function panelRekap(){
 const list=rekapTA();
 const btns='<div style="padding:0 16px 6px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn pri" data-erup><i data-lucide="file-up"></i>Impor Rekap e-Rapor</button><button class="btn ghost" data-eruptpl><i data-lucide="file-down"></i>Contoh Format</button></div>';
 if(!list.length) return btns+'<div style="padding:0 16px 16px;font-size:12.5px;color:var(--tx3)">Belum ada rekap terimpor untuk TA ini.</div>';
 const rows=list.map(k=>`<tr class="frow"><td><span class="strong">${esc2(k.judul)}</span><div style="font-size:11px;color:var(--tx3)">${esc2(k.file)} · ${esc2(k.tgl)}</div></td>
  <td>${badge(k.smt,k.smt==='Genap'?C.sky:C.amber)}</td>
  <td class="num">${k.rows.length} siswa · ${k.head.length} kolom</td>
  <td class="num">${k.cocok!=null?k.cocok+'/'+k.rows.length+' cocok':'—'}</td>
  <td style="text-align:right"><button class="ibtn" data-erview="${k.id}" title="Lihat"><i data-lucide="eye"></i></button><button class="ibtn" data-erxl="${k.id}" title="Ekspor Excel"><i data-lucide="file-spreadsheet"></i></button><button class="ibtn" data-erdel="${k.id}" title="Hapus"><i data-lucide="trash-2"></i></button></td></tr>`).join('');
 return btns+'<div class="twrap" style="margin:0 16px 16px"><table class="tbl"><thead><tr><th>Rekap</th><th>Semester</th><th style="text-align:right">Isi</th><th style="text-align:right">Cocok Data Siswa</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div>';
}
function bukaER(){const o=document.getElementById('erOvl'); if(!o) return; _erMatrix=null;_erHead=-1;
 const eo=document.getElementById('er-out'); if(eo) eo.innerHTML='';
 const fh=document.getElementById('er-filehint'); if(fh) fh.textContent='';
 const yb=document.getElementById('er-yes'); if(yb) yb.style.display='none';
 o.classList.add('show'); lucide.createIcons();}
function tutupER(){const o=document.getElementById('erOvl'); if(o) o.classList.remove('show');}
function pilihBerkasER(){
 const inp=document.createElement('input');
 inp.type='file'; inp.accept='.xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv';
 inp.onchange=()=>{
  const f=inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
   const eo=document.getElementById('er-out');
   const yb0=document.getElementById('er-yes'); if(yb0) yb0.style.display='none';
   try{
    const matrix=/\.csv$/i.test(f.name)?parseCSVText(r.result):readXLSX(r.result);
    const hr=cariHeaderRekap(matrix);
    if(hr<0){ if(eo) eo.innerHTML='<div style="background:#fdecec;color:#b42323;border:1px solid #f5c6c6;border-radius:10px;padding:10px 12px;font-size:12.5px">Baris judul tidak ditemukan — pastikan ada baris berisi kolom <b>Nama</b> (mis. "Nama Lengkap", "Nama Peserta Didik").</div>'; return; }
    let baris=0,cocok=0; const head=matrix[hr].map(x=>String(x||'').trim());
    let colN=-1; for(let c=0;c<head.length;c++){const h=normH(head[c]); if(h&&SPMB_ALI.n.some(a=>h===a||h.startsWith(a+' '))){colN=c;break;}}
    if(colN<0) colN=0;
    for(let i=hr+1;i<matrix.length;i++){ const nm=String((matrix[i]||[])[colN]||'').trim(); if(!nm) continue; baris++; if(matchSiswaByName(nm)) cocok++; }
    if(!baris){ if(eo) eo.innerHTML='<div style="background:#fdecec;color:#b42323;border:1px solid #f5c6c6;border-radius:10px;padding:10px 12px;font-size:12.5px">Judul ditemukan tapi tidak ada baris nilai di bawahnya.</div>'; return; }
    _erMatrix=matrix; _erHead=hr; _erCocok=cocok;
    if(/genap|semester\s*2|smt\s*2|genap\.xlsx/i.test(f.name)){const s=document.getElementById('er-smt'); if(s) s.value='Genap';}
    const fh=document.getElementById('er-filehint'); if(fh) fh.textContent=f.name;
    const yb=document.getElementById('er-yes'); if(yb) yb.style.display='';
    if(eo) eo.innerHTML='<div style="background:#eafaf1;border:1px solid #bfe8d2;border-radius:10px;padding:10px 12px;font-size:12.5px;color:#14683f"><b>'+baris+' siswa · '+head.length+' kolom terdeteksi</b> — '+cocok+' nama cocok dengan Data Siswa sekolah ini. Klik “Simpan sebagai Arsip” untuk TA '+esc2(state.ta)+'.</div>';
   }catch(e){ if(eo) eo.innerHTML='<div style="background:#fdecec;color:#b42323;border:1px solid #f5c6c6;border-radius:10px;padding:10px 12px;font-size:12.5px">Berkas tidak dapat dibaca: '+esc2(e.message)+'</div>'; }
  };
  if(/\.csv$/i.test(f.name)) r.readAsText(f); else r.readAsArrayBuffer(f);
 };
 inp.click();
}
function jalankanER(){
 if(!_erMatrix||_erHead<0) return;
 const smtEl=document.getElementById('er-smt'); const smt=smtEl?smtEl.value:'Ganjil';
 const fh=document.getElementById('er-filehint'); const file=(fh&&fh.textContent)||'rekap-erapor';
 const head=_erMatrix[_erHead].map(x=>String(x||'').trim());
 let colN=-1; for(let c=0;c<head.length;c++){const h=normH(head[c]); if(h&&SPMB_ALI.n.some(a=>h===a||h.startsWith(a+' '))){colN=c;break;}}
 if(colN<0) colN=0;
 const rows=[]; for(let i=_erHead+1;i<_erMatrix.length&&rows.length<1500;i++){ const row=(_erMatrix[i]||[]).map(x=>String(x==null?'':x).trim()); if(!String(row[colN]||'').trim()) continue; rows.push(row); }
 if(!rows.length){toast('Tidak ada baris data pada berkas.','info');return;}
 const list=rekapTA();
 const sid=file+'|'+smt+'|'+JSON.stringify(head)+'|'+JSON.stringify(rows[0]);
 if(list.some(k=>k.sid===sid)){toast('Rekap yang sama sudah pernah diimpor untuk TA ini.','info');return;}
 const rec={id:'rk'+Date.now()+Math.floor(Math.random()*999),sid,smt,file,judul:'Rekap Nilai '+smt+' — '+file.replace(/\.(xlsx|csv)$/i,''),head,rows,cocok:_erCocok,tgl:tglIndo()};
 list.push(rec); tutupER(); requestSave(); navigate('nilai');
 catatLog('Impor rekap e-Rapor: '+rows.length+' siswa ('+_erCocok+' cocok)');
 toast('Rekap e-Rapor tersimpan: '+rows.length+' siswa ('+_erCocok+' cocok Data Siswa).','sparkles');
}
function lihatRekap(id){
 const k=rekapTA().find(x=>x.id===id); if(!k) return;
 let colN=0; for(let c=0;c<k.head.length;c++){const h=normH(k.head[c]); if(h&&SPMB_ALI.n.some(a=>h===a||h.startsWith(a+' '))){colN=c;break;}}
 const body=k.rows.map(r=>'<tr>'+r.map((c,ci)=>{const coc=ci===colN&&matchSiswaByName(c); return '<td style="padding:6px 10px;border-bottom:1px solid var(--line);white-space:nowrap">'+esc2(c)+(coc?' <span title="Cocok dengan Data Siswa" style="color:#14683f">✓</span>':'')+'</td>';}).join('')+'</tr>').join('');
 document.getElementById('erView-body').innerHTML='<div style="overflow:auto;max-height:60vh"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><thead><tr>'+k.head.map(h=>'<th style="text-align:left;padding:7px 10px;background:#f4f6fb;border-bottom:2px solid var(--line);white-space:nowrap">'+esc2(h)+'</th>').join('')+'</tr></thead><tbody>'+body+'</tbody></table></div>';
 document.getElementById('erView-title').textContent=k.judul+' · TA '+state.ta;
 document.getElementById('erViewOvl').classList.add('show'); lucide.createIcons();
}
function eksporRekap(id){ const k=rekapTA().find(x=>x.id===id); if(!k) return; downloadXLSX('rekap-'+k.smt.toLowerCase()+'-'+state.ta.replace('/','-')+'.xlsx',[k.head].concat(k.rows)); toast('Rekap diekspor ke Excel.','file-spreadsheet'); }
function hapusRekap(id){ if(!confirm('Hapus rekap ini dari arsip TA '+state.ta+'?')) return; state.rekap[state.ta]=rekapTA().filter(x=>x.id!==id); requestSave(); navigate('nilai'); toast('Rekap dihapus.','trash-2'); }
function contohER(){
 downloadXLSX('contoh-rekap-erapor.xlsx',[
  ['Nama Lengkap','NISN','Pendidikan Agama','Pancasila','Bahasa Indonesia','Matematika','IPAS','Seni Budaya','PJOK','Rata-rata'],
  ['Ananda Putri','0123456789','92','88','90','85','87','91','89','89'],
  ['Budi Prakoso','0123456788','88','85','82','78','80','84','86','83'],
 ]);
 toast('Contoh rekap diunduh — bentuknya mirip hasil ekspor e-Rapor.','file-down');
}

/* ================= Ekspor Excel (.xlsx) & PDF ================= */
const CRC_T=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c;}return t;})();
const crc32=b=>{let c=0xFFFFFFFF;for(let i=0;i<b.length;i++)c=CRC_T[(c^b[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;};
function zipStore(files){
 const enc=new TextEncoder(); const chunks=[]; let off=0; const cen=[];
 const push=a=>{chunks.push(a);off+=a.length;};
 for(const [name,dataStr] of files){
  const nb=enc.encode(name), db=enc.encode(dataStr), crc=crc32(db);
  const h=new Uint8Array(30), dv=new DataView(h.buffer);
  dv.setUint32(0,0x04034b50,true);dv.setUint16(4,20,true);dv.setUint32(14,crc,true);
  dv.setUint32(18,db.length,true);dv.setUint32(22,db.length,true);dv.setUint16(26,nb.length,true);
  cen.push({nb,crc,size:db.length,off}); push(h);push(nb);push(db);
 }
 const cenStart=off; let cenSize=0;
 for(const c of cen){
  const h=new Uint8Array(46), dv=new DataView(h.buffer);
  dv.setUint32(0,0x02014b50,true);dv.setUint16(4,20,true);dv.setUint16(6,20,true);
  dv.setUint32(16,c.crc,true);dv.setUint32(20,c.size,true);dv.setUint32(24,c.size,true);
  dv.setUint16(28,c.nb.length,true);dv.setUint32(42,c.off,true);
  push(h);push(c.nb);cenSize+=46+c.nb.length;
 }
 const e=new Uint8Array(22), ev=new DataView(e.buffer);
 ev.setUint32(0,0x06054b50,true);ev.setUint16(8,cen.length,true);ev.setUint16(10,cen.length,true);
 ev.setUint32(12,cenSize,true);ev.setUint32(16,cenStart,true); push(e);
 const total=new Uint8Array(off); let p=0; for(const c of chunks){total.set(c,p);p+=c.length;}
 return new Blob([total],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
const colL=i=>{let s='';i++;while(i>0){const m=(i-1)%26;s=String.fromCharCode(65+m)+s;i=Math.floor((i-1)/26);}return s;};
const escX=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function sheetXML(m){
 return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+
  m.map((r,ri)=>'<row r="'+(ri+1)+'">'+r.map((c,ci)=>'<c r="'+colL(ci)+(ri+1)+'" t="inlineStr"><is><t xml:space="preserve">'+escX(c)+'</t></is></c>').join('')+'</row>').join('')+
  '</sheetData></worksheet>';
}
function downloadXLSX(name,m){
 const blob=zipStore([
  ['[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'],
  ['_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
  ['xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets></workbook>'],
  ['xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'],
  ['xl/worksheets/sheet1.xml',sheetXML(m)],
 ]);
 const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
 a.download=name; a.click(); URL.revokeObjectURL(a.href);
}
function tableMatrix(id){
 const tb=document.getElementById(id); if(!tb) return null;
 const table=tb.closest('table'); if(!table) return null;
 const m=[...table.querySelectorAll('thead th')].map(th=>th.textContent.trim()).filter(h=>h);
 return [m,...[...tb.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('td')].map(td=>td.textContent.trim()))];
}
function exportXLSX(scope){
 const m=tableMatrix(scope); if(!m){toast('Tabel tidak ditemukan.','info');return;}
 downloadXLSX(scope+'-'+new Date().toISOString().slice(0,10)+'.xlsx',m);
 toast('Berkas Excel diunduh: '+scope+'.xlsx','file-spreadsheet');
}
function exportTablePDF(scope,title){
 const m=tableMatrix(scope); if(!m){toast('Tabel tidak ditemukan.','info');return;}
 const [hd,...rows]=m;
 printDoc(paper(kop()+`<div class="doc-t">${escX(title).toUpperCase()}<br><span class="small">${esc2(state.sekolah.nama||'Sekolah')} · dicetak ${tglIndo()}</span></div>
  <table class="dt"><thead><tr>${hd.map(h=>'<th>'+escX(h)+'</th>').join('')}</tr></thead>
  <tbody>${rows.map(r=>'<tr>'+r.map(c=>'<td>'+escX(c)+'</td>').join('')+'</tr>').join('')}</tbody></table>`));
}

/* ================= Mulai ================= */
function startApp(){
 const RESTORED=muat();
 if(!state.recovery) state.recovery=genRecovery();
 buildNav(); buildPop(); buildTaSel();
 navigate('beranda');
 tick(); setInterval(tick,1000);
 lucide.createIcons();
 applyUser();
 /* layar masuk selalu tampil lengkap dengan kartu peran (default: peran sesi terakhir / TU) */
 if(state.user) state.loginSel=state.user.id;
 showLogin();
 if(RESTORED&&state.user) toast('Data tersimpan dipulihkan — silakan masuk sebagai '+state.user.role+'.','database');
 if(window.__PRIMA_FS_INFO&&window.__PRIMA_FS_INFO.dir) toast('Penyimpanan data: '+window.__PRIMA_FS_INFO.dir+' (tersimpan otomatis setiap perubahan).','hard-drive');
}
let __bootMulai=false;
function bootStart(){
 if(__bootMulai) return; __bootMulai=true;
 startApp();
}
if(window.primaFS&&window.primaFS.onInit){
 /* mode aplikasi desktop: tunggu data dari folder D:\PRIMA */
 window.primaFS.onInit(p=>{
  window.__PRIMA_FS_INFO=p||null;
  if(p&&p.encrypted&&!p.data){
   const o=document.getElementById('unlockOvl');
   if(o){ o.classList.add('show'); lucide.createIcons();
    const b=document.getElementById('unlock-btn');
    if(b&&!b.__wired){ b.__wired=true; b.addEventListener('click',async()=>{
     const pass=(document.getElementById('unlock-pass').value||'').trim();
     const err=document.getElementById('unlock-err');
     if(!pass){ if(err){err.style.display='';err.textContent='Ketik frasa sandi dulu.';} return; }
     const rem=document.getElementById('unlock-remember').checked;
     const res=await window.primaFS.unlock(pass,rem);
     if(res&&res.ok){
      window.__PRIMA_FS_INFO=Object.assign(window.__PRIMA_FS_INFO||{},{encrypted:false});
      try{localStorage.setItem(LS_KEY,JSON.stringify(res.data));}catch(e2){}
      o.classList.remove('show'); bootStart();
     }else if(err){ err.style.display=''; err.textContent=(res&&res.error)||'Gagal membuka data.'; }
    }); }
    const ip=document.getElementById('unlock-pass');
    if(ip) ip.addEventListener('keydown',e=>{ if(e.key==='Enter') b&&b.click(); });
   }
   return;
  }
  if(p&&p.data){ try{localStorage.setItem(LS_KEY,JSON.stringify(p.data));}catch(e){} }
  bootStart();
 });
 setTimeout(()=>{ const o=document.getElementById('unlockOvl'); if(!__bootMulai&&!(o&&o.classList.contains('show'))) bootStart(); },1500);
}else{
 startApp();
}
