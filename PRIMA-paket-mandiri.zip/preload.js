/* Jembatan aman renderer <-> proses utama untuk penyimpanan file di folder PRIMA. */
const {contextBridge, ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('primaFS',{
 save:json=>ipcRenderer.invoke('prima-save',json),
 saveAs:(rel,json)=>ipcRenderer.invoke('prima-save-as',rel,json),
 unlock:(pass,remember)=>ipcRenderer.invoke('prima-unlock',pass,remember),
 setEnc:(on,pass,remember,json)=>ipcRenderer.invoke('prima-setenc',on,pass,remember,json),
 info:()=>ipcRenderer.invoke('prima-info'),
 onInit:cb=>ipcRenderer.on('prima-data',(e,p)=>cb(p)),
});
