#!/bin/bash
# PRIMA — kemas paket macOS (jalankan di MacBook/Mac, satu perintah).
# Hasil: folder PRIMA.app siap pakai (tanpa tanda tangan Apple — lihat README).
set -e
cd "$(dirname "$0")"
V=31.7.7
rm -rf dist/PRIMA-mac PRIMA-mac.zip
mkdir -p dist/PRIMA-mac
echo "Mengunduh Electron macOS…"
curl -sL -o /tmp/electron-mac.zip "https://github.com/electron/electron/releases/download/v$V/electron-v$V-darwin-x64.zip"
unzip -qo /tmp/electron-mac.zip -d dist/PRIMA-mac
mv "dist/PRIMA-mac/Electron.app" "dist/PRIMA-mac/PRIMA.app"
APP=dist/PRIMA-mac/PRIMA.app/Contents/Resources/app
mkdir -p "$APP/data"
cp index.html ppdb.html style.css app.js main.js preload.js server.js cryptolib.js google-apps-script.js package.json README.md "$APP/"
cp data/klasifikasi.js data/sekolah.js "$APP/data/"
cd dist && zip -qr9 ../PRIMA-mac.zip PRIMA-mac
echo "SELESAI: PRIMA-mac.zip — ekstrak, lalu di Mac jalankan: xattr -cr PRIMA.app && buka lewat klik-kanan > Open"
